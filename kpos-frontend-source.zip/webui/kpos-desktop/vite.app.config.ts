import { defineConfig, loadEnv } from 'vite';
import react from '@vitejs/plugin-react';

// 员工端：kpos.com。打包到 dist/app，和总后台分开部署
export default defineConfig(({ mode }) => {
  const env = loadEnv(mode, process.cwd(), '');
  return {
    root: 'app',
    envDir: '..',
    plugins: [react()],
    define: { __MOCK__: JSON.stringify(mode === 'mock' || env.VITE_MOCK === '1') },
    server: { port: 5173, proxy: { '/api': env.VITE_API_PROXY || 'http://localhost:8000' } },
    build: { outDir: '../dist/app', emptyOutDir: true },
  };
});
