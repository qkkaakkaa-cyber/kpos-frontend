// 工作台：一篇文章在这里做视频（快讯 / 深度，可写提示）或做图文（来龙去脉、找图、分享文案）
import { useState } from 'react';
import { Icon } from '../../shared/icons';
import { go, Link } from '../../shared/router';
import { copyText, ErrorBox, Loading, Modal, Seg, Thumb, useAsync, useToast } from '../../shared/ui';
import { api } from '../api';
import { ArticleCard, ProdOptions, usePrefs } from '../components';
import { WorkspaceSwitch } from '../layout/Shell';
import { useSession } from '../session';
import type { Article, JobKind, Story } from '../types';

const HINTS = ['讲清楚时间线', '对华人、游客有什么影响', '各方怎么说', '和以前类似的事对比', '多用官方数字', '接下来会怎样'];

export function Workbench({ id, mode, kind: kind0 }: { id: string; mode: 'video' | 'text'; kind: JobKind }) {
  const { data: a, error, loading, reload } = useAsync(() => api.article(id), [id]);
  return (
    <>
      <header className="top">
        <Link to="/news" className="back"><Icon name="left" />新闻</Link>
        <h1>工作台</h1><span className="sub">一篇文章在这里做视频、做图文</span>
        <div className="right">{a?.url && <a className="btn ghost" href={a.url} target="_blank" rel="noreferrer noopener"><Icon name="out" size={16} color="#6A55A0" />原网页</a>}<WorkspaceSwitch /></div>
      </header>
      {loading ? <Loading rows={6} /> : error ? <div className="body"><ErrorBox error={error} retry={reload} /></div> : (
        <div className="body">
          <ArticleCard a={a!} />
          <aside className="card col" style={{ flex: '0 0 440px', gap: 0 }}>
            <div className="pad col" style={{ gap: 12, paddingBottom: 0 }}>
              <span className="h2">制作区</span>
              <div className="seg" style={{ display: 'flex' }}>
                <button style={{ flex: 1 }} className={mode === 'video' ? 'on' : ''} onClick={() => go(`/work/${id}`)}>做视频</button>
                <button style={{ flex: 1 }} className={mode === 'text' ? 'on' : ''} onClick={() => go(`/work/${id}?mode=text`)}>做图文</button>
              </div>
            </div>
            {mode === 'video' ? <MakeVideo a={a!} kind0={kind0} /> : <MakeText a={a!} />}
          </aside>
        </div>
      )}
    </>
  );
}

function MakeVideo({ a, kind0 }: { a: Article; kind0: JobKind }) {
  const { queue, refreshQueue, me } = useSession();
  const toast = useToast();
  const [kind, setKind] = useState<JobKind>(kind0);
  const [hint, setHint] = useState('');
  const [prefs, setPrefs] = usePrefs();
  const [busy, setBusy] = useState(false);
  const qq = queue?.quota;
  const left = (k: 'quick' | 'deep') => !qq ? '' : qq[k].limit === null ? '今天不限' : `今天 ${qq[k].used}/${qq[k].limit}`;
  const noDeep = qq?.deep.limit === 0;
  const full = !!queue && queue.running.length + queue.queued.length >= queue.limit;
  const tooFew = a.images.length < 2;

  async function submit() {
    setBusy(true);
    try {
      const j = await api.createJob({ kind, articleId: a.id, hint: kind === 'deep' ? hint.trim() : undefined, prefs });
      refreshQueue();
      go('/progress/' + j.id);
    } catch (e: any) { toast(e.message); } finally { setBusy(false); }
  }

  return (
    <div className="pad col" style={{ gap: 16 }}>
      <div className="col" style={{ gap: 10 }} role="radiogroup" aria-label="做成哪种视频">
        <button type="button" className={'opt' + (kind === 'quick' ? ' on' : '')} onClick={() => setKind('quick')} role="radio" aria-checked={kind === 'quick'}>
          <span className="radio" /><span className="col grow" style={{ gap: 0 }}><b style={{ fontSize: 16 }}>快讯</b><span className="small muted">1 分钟内，按原文改写 · 约 3 分钟做好</span></span><span className="small muted">{left('quick')}</span>
        </button>
        <button type="button" className={'opt' + (kind === 'deep' ? ' on' : '')} disabled={noDeep} onClick={() => setKind('deep')} role="radio" aria-checked={kind === 'deep'} style={noDeep ? { opacity: .55 } : undefined}>
          <span className="radio" /><span className="col grow" style={{ gap: 0 }}><b style={{ fontSize: 16, color: kind === 'deep' ? 'var(--p-deep)' : undefined }}>深度解析</b><span className="small muted">2 到 3 分钟，自动查来龙去脉、配现场画面 · 约 9 分钟做好</span></span><span className="small muted">{noDeep ? `${me?.roleName}不能做` : left('deep')}</span>
        </button>
      </div>

      {kind === 'deep' && (
        <div className="col" style={{ gap: 8 }}>
          <label className="lab">给深度的提示 <span className="small muted" style={{ fontWeight: 500 }}>（可选）想让这条深度重点讲什么</span>
            <textarea className="in" rows={3} value={hint} maxLength={300} onChange={e => setHint(e.target.value)} placeholder="比如：重点讲对清莱华人和游客的影响，交代清楚污染从哪来" style={{ fontSize: 14, lineHeight: '22px' }} />
          </label>
          <span className="small muted">点一下加到提示里：</span>
          <span className="row wrap" style={{ gap: 6 }}>
            {HINTS.map(h => <button key={h} type="button" className="chip c-p" style={{ border: 0, padding: '3px 10px', fontSize: 12 }} onClick={() => setHint(t => (t ? t.replace(/[，。\s]*$/, '，') : '') + h)}>＋ {h}</button>)}
          </span>
          <span className="small muted">提示只决定讲哪些角度；资料里查不到的不会编进文案。</span>
        </div>
      )}

      <ProdOptions value={prefs} onChange={setPrefs} lengths={kind === 'quick' ? [30, 45, 60] : null} lengthNote="深度解析自动 2–3 分钟" />

      {kind === 'deep' && <div className="tip small">深度解析会自动做这些：查{me?.workspace.name}之前的相关报道 → 理出来龙去脉 → 写口播 → 稿子写好后等你确认 → 找现场视频 → 配音剪辑。</div>}
      {tooFew && <div className="note">原图不够 2 张，剪不了视频。切到「做图文」用一键找图补图。</div>}
      {full && <div className="note">同时最多 {queue!.limit} 条在做，等前面做完一条再提交。</div>}

      <button className="btn lg" style={{ height: 54, fontSize: 16 }} disabled={busy || tooFew || full || (kind === 'deep' && noDeep)} onClick={submit}>
        {busy ? '提交中…' : kind === 'deep' ? '一键生成深度视频' : '一键生成快讯'}
      </button>
      <span className="small muted" style={{ textAlign: 'center' }}>提交后可以先做别的，做好了在「生成记录」里</span>
    </div>
  );
}

function MakeText({ a }: { a: Article }) {
  const toast = useToast();
  const { data: s, error, loading, reload } = useAsync(() => api.story(a.id), [a.id]);
  const [tab, setTab] = useState<'story' | 'images' | 'copy'>('story');
  const [edit, setEdit] = useState<string | null>(null);
  if (loading) return <Loading rows={5} />;
  if (error) return <div className="pad"><ErrorBox error={error} retry={reload} /></div>;
  const story = s as Story;
  const text = [story.headline, story.summary, '', ...story.timeline.map(t => `${t.d}　${t.t}`), '', '最新进展：' + story.latest].join('\n');
  const picked = story.images.filter(x => x.picked);

  return (
    <div className="pad col" style={{ gap: 16 }}>
      <Seg value={tab} onChange={setTab} options={[{ v: 'story', label: '来龙去脉' }, { v: 'images', label: <>一键找图 <span className="num">{story.images.length}</span></> }, { v: 'copy', label: '分享文案' }]} />
      {tab === 'story' && <>
        <div className="col" style={{ gap: 6 }}><b style={{ fontSize: 17, lineHeight: '25px' }}>{story.headline}</b><span className="muted" style={{ fontSize: 13, lineHeight: '21px' }}>{story.summary}</span></div>
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, minmax(0,1fr))', gap: 8 }}>
          {story.stats.map(x => <div key={x.l} style={{ padding: '10px 12px', borderRadius: 10, background: 'var(--p-sel)' }}><div className="num b" style={{ fontSize: 20, color: 'var(--p-deep)' }}>{x.v}</div><div className="small muted">{x.l}</div></div>)}
        </div>
        <div className="col" style={{ gap: 4 }}>
          <div className="row"><span className="h2" style={{ fontSize: 14 }}>时间线</span><button className="btn ghost sm" style={{ marginLeft: 'auto' }} onClick={async () => toast((await copyText(story.timeline.map(t => `${t.d}　${t.t}`).join('\n'))) ? '时间线已复制' : '复制不了，请手动选中复制')}><Icon name="copy" size={14} />复制</button></div>
          {story.timeline.map((t, i) => (
            <div key={i} className="row" style={{ alignItems: 'flex-start', gap: 12 }}>
              <span className="col" style={{ alignItems: 'center', gap: 0, alignSelf: 'stretch' }}><span className="dot" style={{ width: 10, height: 10, marginTop: 6, background: i === story.timeline.length - 1 ? 'var(--m)' : 'var(--input)' }} />{i < story.timeline.length - 1 && <span style={{ flex: 1, width: 2, background: 'var(--line2)' }} />}</span>
              <span className="col" style={{ gap: 0, paddingBottom: 10 }}><span className="small num b" style={{ color: 'var(--m-deep)' }}>{t.d}</span><span style={{ fontSize: 13, lineHeight: '20px' }}>{t.t}</span></span>
            </div>
          ))}
        </div>
        <div className="col" style={{ gap: 4 }}><span className="small b">最新进展</span><span style={{ fontSize: 13 }}>{story.latest}</span></div>
        <div className="col" style={{ gap: 4 }}><span className="small muted">根据之前的报道</span>{story.refs.map((r, i) => <a key={i} className="small" href={r.url} target="_blank" rel="noreferrer noopener">{r.date} {r.title} ↗</a>)}</div>
      </>}
      {tab === 'images' && <ImagePicker story={story} />}
      {tab === 'copy' && <>
        <span className="small muted">分享用的配图 · 已选 {picked.length} 张</span>
        <div className="row wrap" style={{ gap: 8 }}>{picked.map((im, i) => <Thumb key={im.id} w={84} h={84} i={i} src={im.src} />)}</div>
        <textarea className="in" rows={10} defaultValue={text} style={{ fontSize: 13, lineHeight: '21px' }} aria-label="分享文案" id="share-text" />
      </>}
      <div className="row" style={{ gap: 8 }}>
        <button className="btn ghost grow" onClick={async () => toast((await copyText(text)) ? '来龙去脉已复制' : '复制不了，请手动选中复制')}><Icon name="copy" size={16} />复制来龙去脉</button>
        <button className="btn grow" onClick={() => setEdit(text)}><Icon name="share" size={16} />编辑后分享图文</button>
      </div>
      {edit !== null && (
        <Modal title="编辑后分享图文" onClose={() => setEdit(null)} actions={<>
          <button className="btn ghost" onClick={() => setEdit(null)}>关闭</button>
          <button className="btn" onClick={async () => { toast((await copyText(edit)) ? '文案已复制，配图在「一键找图」里下载' : '复制不了，请手动选中复制'); setEdit(null); }}>复制文案</button>
        </>}>
          <textarea className="in" rows={12} value={edit} onChange={e => setEdit(e.target.value)} style={{ fontSize: 13, lineHeight: '21px' }} aria-label="分享文案" />
          <span className="small muted">复制后到小红书、抖音图文、Facebook 发布，配 {picked.length} 张图。</span>
        </Modal>
      )}
    </div>
  );
}

function ImagePicker({ story }: { story: Story }) {
  const toast = useToast();
  const [sel, setSel] = useState(() => new Set(story.images.filter(x => x.picked).map(x => x.id)));
  return (
    <div className="col" style={{ gap: 10 }}>
      <span className="small muted">原文、旧报道、泰媒、Facebook 都找过了；点图片选中或取消</span>
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, minmax(0,1fr))', gap: 8 }}>
        {story.images.map((im, i) => {
          const on = sel.has(im.id);
          return (
            <button key={im.id} type="button" aria-pressed={on} onClick={() => { const n = new Set(sel); on ? n.delete(im.id) : n.add(im.id); setSel(n); }}
              className="col" style={{ gap: 4, border: 0, background: 'none', padding: 0, textAlign: 'left' }}>
              <Thumb w="100%" h={78} i={i} src={im.src} style={{ outline: on ? '3px solid var(--p)' : 'none', outlineOffset: -3 }}
                label={on ? <span style={{ position: 'absolute', right: 6, top: 6, width: 20, height: 20, borderRadius: 6, background: 'var(--p)', display: 'flex', alignItems: 'center', justifyContent: 'center' }}><Icon name="check" size={12} color="#fff" sw={3} /></span> : undefined} />
              <span className="small muted">{im.from}</span>
            </button>
          );
        })}
      </div>
      <button className="btn soft" onClick={() => toast(`开始下载 ${sel.size} 张图`)}><Icon name="dl" size={16} />下载选中的 {sel.size} 张</button>
    </div>
  );
}
