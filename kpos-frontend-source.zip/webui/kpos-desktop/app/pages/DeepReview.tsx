// 深度稿审阅：出片前改稿、看时间线和来源、发链接给同事
import { useEffect, useState } from 'react';
import { Icon } from '../../shared/icons';
import { go, Link } from '../../shared/router';
import { copyText, ErrorBox, Loading, Seg, Thumb, Toggle, useAsync, useToast } from '../../shared/ui';
import { api } from '../api';
import { WorkspaceSwitch } from '../layout/Shell';
import { useSession } from '../session';
import type { DeepDraft } from '../types';

export function DeepReview({ id }: { id: string }) {
  const toast = useToast();
  const { refreshQueue } = useSession();
  const { data, error, loading, reload, setData } = useAsync(() => api.draft(id), [id]);
  const [text, setText] = useState<Record<string, string>>({});
  const [view, setView] = useState<'edit' | 'diff'>('edit');
  const [focus, setFocus] = useState('');
  const [comment, setComment] = useState('');
  const [busy, setBusy] = useState(false);

  useEffect(() => { if (data) setText(Object.fromEntries(data.paras.map(p => [p.key, p.text]))); }, [data]);
  if (loading) return <Loading rows={6} />;
  if (error) return <div className="body"><ErrorBox error={error} retry={reload} /></div>;
  const d = data as DeepDraft;
  const locked = d.job.status !== 'review';
  const dirty = d.paras.some(p => text[p.key] !== undefined && text[p.key] !== p.text);
  const chars = Object.values(text).reduce((s, t) => s + t.length, 0);

  async function save() {
    setBusy(true);
    try { setData(await api.saveDraft(id, { paras: text })); toast('已保存'); } catch (e: any) { toast(e.message); } finally { setBusy(false); }
  }
  async function confirm() {
    setBusy(true);
    try {
      if (dirty) await api.saveDraft(id, { paras: text });
      await api.confirm(id); refreshQueue(); toast('已确认，开始配音和剪辑'); go('/progress/' + id);
    } catch (e: any) { toast(e.message); } finally { setBusy(false); }
  }

  return (
    <>
      <header className="top"><Link to="/jobs" className="back"><Icon name="left" />生成记录</Link><div className="right"><WorkspaceSwitch /></div></header>
      <div className="col" style={{ padding: '24px 28px', gap: 20 }}>
        <div className="row wrap" style={{ alignItems: 'flex-end', gap: 20 }}>
          <div className="col grow" style={{ minWidth: 320, gap: 8 }}>
            <span className="row" style={{ gap: 6 }}><span className="chip c-p">深度解析</span>{locked ? <span className="chip c-g">已确认出片 · 稿子锁定</span> : <span className="chip c-y">等你确认 · 还没出片</span>}</span>
            <h1 style={{ margin: 0, fontSize: 24, lineHeight: '33px', fontWeight: 700 }}>{d.job.title}</h1>
            <span className="muted">{locked ? '出片后还想改，在「生成记录」里点「口播文案」改了重新配音。' : '资料已查完，稿子已写好。改完点「确认出片」才开始配音和剪辑；也可以先把审阅链接发给主编看。'}</span>
          </div>
          {!locked && <div className="row"><button className="btn ghost" disabled={!dirty || busy} onClick={save}>存为草稿</button><button className="btn lg" disabled={busy} onClick={confirm}>确认出片</button></div>}
        </div>

        <div className="body" style={{ padding: 0 }}>
          <section className="col" style={{ flex: '1 1 0' }}>
            <div className="card">
              <div className="row wrap" style={{ padding: '16px 20px', borderBottom: '1px solid var(--line2)' }}>
                <Icon name="doc" color="#6A55A0" /><span className="h2">口播稿</span>
                <span className="small muted">约 {Math.floor(chars / 3.9 / 60)} 分 {Math.round(chars / 3.9) % 60} 秒 · {chars} / 上限 {d.maxChars} 字</span>
                <span style={{ marginLeft: 'auto' }}><Seg value={view} onChange={setView} options={[{ v: 'edit', label: '编辑' }, { v: 'diff', label: '和原稿对比' }]} /></span>
              </div>
              <div className="col" style={{ padding: '18px 20px', gap: 16 }}>
                {d.paras.map(p => {
                  const orig = d.original.find(o => o.key === p.key)?.text || '';
                  const cur = text[p.key] ?? p.text;
                  const edited = cur !== orig;
                  return (
                    <label key={p.key} className="col" style={{ gap: 6 }}>
                      <span className="row small b muted" style={{ gap: 8 }}>{p.label}
                        {p.locked && <span className="chip c-g">自动加，不能改</span>}
                        {!p.locked && p.editedBy && <span className="chip c-p">已改 · {p.editedBy} {p.editedAt}</span>}
                      </span>
                      {view === 'diff' && edited ? (
                        <div className="col" style={{ gap: 4 }}>
                          <div className="small" style={{ padding: '8px 12px', borderRadius: 8, background: 'var(--r-soft)', textDecoration: 'line-through', color: 'var(--grey)' }}>{orig}</div>
                          <div style={{ padding: '8px 12px', borderRadius: 8, background: 'var(--m-soft)', fontSize: 15, lineHeight: '26px' }}>{cur}</div>
                        </div>
                      ) : (
                        <textarea className={'in' + (edited ? ' edited' : '')} rows={Math.max(1, Math.ceil(cur.length / 40))} value={cur} readOnly={p.locked || locked}
                          onFocus={() => setFocus(p.key)} onChange={e => setText({ ...text, [p.key]: e.target.value })} />
                      )}
                    </label>
                  );
                })}
              </div>
              <div className="row wrap" style={{ padding: '14px 20px', borderTop: '1px solid var(--line2)', gap: 8 }}>
                <span className="small b">自动检查</span>
                {d.checks.map(c => <span key={c.text} className={'chip ' + (c.ok ? 'c-m' : 'c-w')}>{c.text}</span>)}
                {!locked && <span className="row" style={{ marginLeft: 'auto', gap: 8 }}>
                  <button className="btn ghost sm" disabled={!focus || busy} title={focus ? '' : '先点一段'} onClick={async () => { try { setData(await api.rewritePara(id, focus)); toast('这段重写好了'); } catch (e: any) { toast(e.message); } }}>只重写选中段</button>
                  <button className="btn soft sm" disabled={!dirty || busy} onClick={save}>保存修改</button>
                </span>}
              </div>
            </div>
            <div className="card pad col" style={{ gap: 14 }}>
              <div className="row"><span className="h2">画面和图卡</span><span className="small muted">按口播段落排好，出片后可以在「生成记录」里换</span></div>
              <div style={{ display: 'grid', gridTemplateColumns: 'repeat(6, minmax(0,1fr))', gap: 10 }}>
                {[['原文图 1', '导语'], ['原文图 2', '导语'], ['旧报道图', '背景'], ['时间线图卡', '背景'], ['数字图卡', '经过'], ['原文图 3', '最新进展']].map(([a, b], i) => (
                  <div key={i} className="col" style={{ gap: 4 }}><Thumb w="100%" h={0} i={i} style={{ aspectRatio: '9/16', height: 'auto' }} /><span className="small b">{a}</span><span className="small muted">{b}</span></div>
                ))}
              </div>
            </div>
          </section>

          <aside className="col" style={{ flex: '0 0 380px' }}>
            <section className="card pad col" style={{ gap: 12 }}>
              <span className="h2">分享给同事</span>
              <div className="row"><span className="field grow"><span className="muted ell">{d.share.url.replace(/[^/]+$/, '••••••')}</span></span>
                <button className="btn" onClick={async () => toast((await copyText(d.share.url)) ? '审阅链接已复制' : '复制不了：' + d.share.url)}>复制链接</button></div>
              <div className="row"><span className="grow" style={{ fontSize: 13, fontWeight: 600 }}>打开链接的同事可以直接改稿</span>
                <Toggle on={d.share.canEdit} label="允许同事改稿" onChange={async v => { try { setData(await api.saveDraft(id, { canEdit: v })); } catch (e: any) { toast(e.message); } }} /></div>
              <span className="small muted">只有本工作区的工号能打开；关掉后同事只能看和留言。</span>
              <div className="col" style={{ gap: 10, paddingTop: 4 }}>
                {d.comments.map((c, i) => (
                  <div key={i} className="row" style={{ alignItems: 'flex-start' }}><span className="av m sm">{c.who.slice(0, 1)}</span>
                    <span className="col" style={{ gap: 0, lineHeight: '20px' }}><span className="small"><b>{c.who}</b> <span className="muted">{c.role} · {c.at} · {c.para}</span></span><span style={{ fontSize: 13 }}>{c.text}</span></span></div>
                ))}
                <form className="row" onSubmit={async e => { e.preventDefault(); if (!comment.trim()) return; try { setData(await api.saveDraft(id, { comment: { para: d.paras.find(p => p.key === focus)?.label || '全文', text: comment.trim() } })); setComment(''); } catch (er: any) { toast(er.message); } }}>
                  <span className="field grow"><input value={comment} onChange={e => setComment(e.target.value)} placeholder="写留言…" aria-label="留言" /></span><button className="btn soft sm" disabled={!comment.trim()}>发送</button>
                </form>
              </div>
            </section>
            <section className="card pad col" style={{ gap: 4 }}>
              <div className="row" style={{ paddingBottom: 4 }}><span className="h2">时间线</span><span className="small muted">系统整理，背景段照这个写</span></div>
              {d.timeline.map((t, i) => <div key={i} className="step"><span className="sdot" /><span className="col" style={{ gap: 0 }}><b className="small num">{t.d}</b><span style={{ fontSize: 13 }}>{t.t}</span><span className="small muted">{t.sources} 个来源</span></span></div>)}
            </section>
            <section className="card pad col" style={{ gap: 4 }}>
              <div className="row" style={{ paddingBottom: 4 }}><span className="h2">查到的来源</span><span className="small muted">{d.sources.length} 条</span></div>
              {d.sources.map((s, i) => (
                <div key={i} className="row" style={{ alignItems: 'flex-start', padding: '9px 0', borderBottom: i < d.sources.length - 1 ? '1px solid var(--line2)' : 0 }}>
                  <span className={'chip ' + (s.kind === '一手' ? 'c-m' : 'c-g')}>{s.kind}</span>
                  <span className="col grow" style={{ gap: 0 }}><span style={{ fontSize: 13, fontWeight: 600 }}>{s.title}</span><span className="small muted">{s.at}</span></span>
                  <a className="small sb" href={s.url} target="_blank" rel="noreferrer noopener">打开</a>
                </div>
              ))}
            </section>
            <div className="note">确认出片后稿子锁定；出片后还想改，在「生成记录」里点「口播文案」重新配音。</div>
          </aside>
        </div>
      </div>
    </>
  );
}
