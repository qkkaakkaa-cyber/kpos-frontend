// 智能剪辑：写事件提示 → 查资料找素材 → 改口播 → 剪
import { useState } from 'react';
import { Icon } from '../../shared/icons';
import { go } from '../../shared/router';
import { Seg, Thumb, useToast } from '../../shared/ui';
import { api } from '../api';
import { ProdOptions, usePrefs } from '../components';
import { WorkspaceSwitch } from '../layout/Shell';
import { useSession } from '../session';
import type { SmartResult } from '../types';

export function Smart() {
  const toast = useToast();
  const { refreshQueue } = useSession();
  const [f, setF] = useState({ prompt: '', videos: '', clues: '', date: '' });
  const [res, setRes] = useState<SmartResult | null>(null);
  const [script, setScript] = useState('');
  const [mode, setMode] = useState<'video' | 'mix' | 'image'>('mix');
  const [prefs, setPrefs] = usePrefs();
  const [busy, setBusy] = useState('');
  const videoLines = f.videos.split('\n').filter(x => x.trim()).length;

  async function search() {
    setBusy('search');
    try { const r = await api.smartSearch(f); setRes(r); setScript(r.script); } catch (e: any) { toast(e.message); } finally { setBusy(''); }
  }
  async function make() {
    setBusy('make');
    try { const j = await api.smartJob({ script, mode, prefs }); refreshQueue(); go('/progress/' + j.id); } catch (e: any) { toast(e.message); } finally { setBusy(''); }
  }

  return (
    <>
      <header className="top"><h1>智能剪辑</h1><span className="sub">写一句事件提示或贴文案，系统查资料、核对前因后果、找视频和图片，整理 90 秒内口播</span><div className="right"><WorkspaceSwitch /></div></header>
      <div className="body">
        <section className="col" style={{ flex: '1 1 0' }}>
          <div className="card pad col" style={{ gap: 12 }}>
            <span className="h2">① 写事件提示或贴文案</span>
            <textarea className="in" rows={4} value={f.prompt} onChange={e => setF({ ...f, prompt: e.target.value })} aria-label="事件提示或文案"
              placeholder="例如：拉廊府山洪，祖母与3名儿童遇险，查找事故经过及官方救援进展。也可粘贴完整资料；只提供视频时可留空。" style={{ fontSize: 14, lineHeight: '22px' }} />
            <label className="lab">视频链接（可选）
              <textarea className="in" rows={2} value={f.videos} onChange={e => setF({ ...f, videos: e.target.value })} placeholder="粘贴 X、Facebook、TikTok 具体视频帖子链接，每行一条，最多 3 条" style={{ fontSize: 13, lineHeight: '21px' }} />
              {videoLines > 3 && <span className="small" style={{ color: 'var(--r)' }}>最多 3 条</span>}
            </label>
            <div className="row wrap" style={{ gap: 12, alignItems: 'flex-start' }}>
              <label className="lab grow">补充线索（可选）<input className="in" value={f.clues} onChange={e => setF({ ...f, clues: e.target.value })} placeholder="涉事人姓名、地点、关键词、参考报道链接…" /></label>
              <label className="lab">事件日期（可选）<input className="in" type="date" value={f.date} onChange={e => setF({ ...f, date: e.target.value })} /><span className="small muted" style={{ fontWeight: 500 }}>填了能减少旧闻混入</span></label>
            </div>
            <button className="btn" style={{ alignSelf: 'flex-start' }} disabled={busy === 'search' || videoLines > 3} onClick={search}><Icon name="search" size={16} />{busy === 'search' ? '正在查资料、找素材…' : '查资料、找素材'}</button>
          </div>
          {res && <>
            <div className="card pad col" style={{ gap: 12 }}>
              <span className="h2">② 查到的素材</span>
              <span className="small muted">{res.summary}</span>
              <div style={{ display: 'grid', gridTemplateColumns: 'repeat(6, minmax(0,1fr))', gap: 8 }}>
                {res.materials.map((m, i) => (
                  <div key={m.id} className="col" style={{ gap: 3, opacity: m.ok ? 1 : .45 }}>
                    <Thumb w="100%" h={0} i={i} style={{ aspectRatio: '9/16', height: 'auto' }} label={m.dur ? <span className="imgn">{m.dur}</span> : undefined} />
                    <span className="small b">{m.type === 'video' ? '视频' : '图片'}{!m.ok && <span className="chip c-w" style={{ marginLeft: 4 }}>{m.reason}</span>}</span><span className="small muted">{m.from}</span>
                  </div>
                ))}
              </div>
              <span className="small muted">视频帖子里的说法按发布者说法核对；线索里没经过来源核实的内容不会写成事实。</span>
            </div>
            <div className="card pad col" style={{ gap: 10 }}>
              <div className="row"><span className="h2">③ 口播文案</span><span className="small muted">可以改 · 90 秒以内，资料不够就短一点，不凑时长</span><span className="small muted num" style={{ marginLeft: 'auto' }}>{script.length} / 2000 字</span></div>
              <textarea className="in" rows={8} maxLength={2000} value={script} onChange={e => setScript(e.target.value)} aria-label="口播文案" />
              <span className="small muted">参考来源：{res.refs.map((r, i) => <a key={i} href={r.url} target="_blank" rel="noreferrer noopener" style={{ marginRight: 8 }}>{r.title} ↗</a>)}</span>
            </div>
          </>}
        </section>
        <aside className="card pad col" style={{ flex: '0 0 420px', gap: 16 }}>
          <span className="h2">制作区</span>
          <div className="col" style={{ gap: 8 }}>
            <span className="small sb muted">剪辑方式</span>
            <Seg value={mode} onChange={setMode} options={[{ v: 'video', label: '视频剪辑' }, { v: 'mix', label: '混合剪辑' }, { v: 'image', label: '图文剪辑' }]} />
            <span className="small muted">视频剪辑：只用视频；混合剪辑：视频为主、图片补空；图文剪辑：没有合适视频时只用图片。</span>
          </div>
          <ProdOptions value={prefs} onChange={setPrefs} lengths={null} lengthNote="90 秒以内，按资料多少" defaultOpen />
          <span className="small muted">做之前会再终审一次素材；查找要 1 到 3 分钟，可以先去做别的。</span>
          <button className="btn lg" disabled={!res || !script.trim() || busy === 'make'} onClick={make}>{busy === 'make' ? '提交中…' : '一键生成'}</button>
          <span className="small muted" style={{ textAlign: 'center' }}>{res ? '文案改过的话，生成时会按新内容重新核对' : '先查资料、找素材'}</span>
        </aside>
      </div>
    </>
  );
}
