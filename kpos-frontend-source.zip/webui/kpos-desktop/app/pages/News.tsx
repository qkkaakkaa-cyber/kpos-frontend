// 新闻：列表上直接点快讯 / 深度；点标题进工作台
import { useState } from 'react';
import { Icon } from '../../shared/icons';
import { go, Link } from '../../shared/router';
import { ErrorBox, Loading, Seg, Tabs, Thumb, useAsync, useToast } from '../../shared/ui';
import { api } from '../api';
import { WorkspaceSwitch } from '../layout/Shell';
import { useSession } from '../session';
import type { JobKind, NewsItem, NewsTab } from '../types';

const TABS: { v: NewsTab; label: string }[] = [
  { v: 'recommend', label: '推荐关注' }, { v: 'h24', label: '24小时热门' }, { v: 'week', label: '一周热门' },
  { v: 'huaren', label: '华人' }, { v: 'society', label: '社会' }, { v: 'deep', label: '深度话题' }, { v: 'latest', label: '最新' },
];

export function News({ tab, page, source }: { tab: NewsTab; page: number; source: 'site' | 'foreign' }) {
  const { me, refreshQueue, queue } = useSession();
  const toast = useToast();
  const { data, error, loading, reload } = useAsync(() => api.news(tab, page, source), [tab, page, source, me?.workspace.id]);
  const [url, setUrl] = useState('');
  const [busy, setBusy] = useState('');
  const full = !!queue && queue.running.length + queue.queued.length >= queue.limit;
  const nav = (o: { tab?: string; page?: number; src?: string }) => go(`/news?tab=${o.tab ?? tab}&page=${o.page ?? 1}&src=${o.src ?? source}`);

  async function open() {
    if (!url.trim()) return;
    setBusy('link');
    try { const r = await api.resolve(url.trim()); go('/work/' + r.id); }
    catch (e: any) { toast(e.message); } finally { setBusy(''); }
  }

  async function make(n: NewsItem, kind: JobKind) {
    setBusy(n.id + kind);
    try {
      await api.createJob({ kind, articleId: n.id });
      refreshQueue();
      toast(`已提交${kind === 'deep' ? '深度解析' : '快讯'}，左下角看进度`);
    } catch (e: any) { toast(e.message); } finally { setBusy(''); }
  }

  const site = me?.workspace.site || 'thais.com';
  return (
    <>
      <header className="top">
        <h1>新闻</h1><span className="sub">点「快讯」「深度」直接生成；点标题进工作台，可以改设置、做图文</span>
        <div className="right"><WorkspaceSwitch /><button className="btn ghost" onClick={reload}><Icon name="refresh" size={16} color="#6A55A0" />刷新</button></div>
      </header>
      <div className="center"><div className="inner" style={{ maxWidth: 1040 }}>
        <section className="card pad col" style={{ gap: 12 }}>
          <div className="row wrap" style={{ gap: 12 }}>
            <span className="seg">
              <button className={source === 'site' ? 'on' : ''} onClick={() => nav({ src: 'site' })}>中文社模式</button>
              <button onClick={() => go('/wechat')}>公众号模式</button>
              <button className={source === 'foreign' ? 'on' : ''} onClick={() => nav({ src: 'foreign' })}>外站新闻</button>
              <button onClick={() => go('/smart')}>智能剪辑</button>
              <button onClick={() => go('/upload')}>手动上传</button>
            </span>
          </div>
          <form className="row" onSubmit={e => { e.preventDefault(); open(); }}>
            <span className="field grow" style={{ height: 46 }}><Icon name="link" size={18} color="#9AA2A8" />
              <input value={url} onChange={e => setUrl(e.target.value)} aria-label="新闻链接"
                placeholder={source === 'site' ? `粘贴${me?.workspace.name}新闻链接，如 https://${site}/news-10023/` : '粘贴泰文、英文等网站的新闻链接，先翻译成中文再写口播'} style={{ fontSize: 14 }} />
            </span>
            <button className="btn lg" disabled={!url.trim() || busy === 'link'}>打开</button>
          </form>
          <span className="small muted">「公众号模式」贴 mp.weixin.qq.com 文章链接；「外站新闻」贴泰文、英文等网站链接；「智能剪辑」写一句事件提示，系统查资料、找素材；「手动上传」用自己的图片视频。</span>
        </section>

        <Tabs value={tab} onChange={v => nav({ tab: v })} options={TABS} right={data ? `和上一轮比 · ${data.updatedAt} 更新 · 下一轮 ${data.nextAt}` : ''} />
        {full && <div className="note">同时最多 {queue!.limit} 条在做（剪辑中 + 排队），等前面做完一条再提交。</div>}

        <section className="card" style={{ overflow: 'hidden' }}>
          {loading && !data ? <Loading rows={8} /> : error ? <div className="pad"><ErrorBox error={error} retry={reload} /></div> : data!.items.map((n, i) => {
            const ok = n.images >= 2;
            const mv = n.move.startsWith('▲') ? 'rise' : n.move.startsWith('▼') ? 'fall' : n.move === '新' ? 'b' : 'faint';
            return (
              <div key={n.id} className="newsrow">
                <span className="col" style={{ width: 28, alignItems: 'center', gap: 0, flex: 'none' }}>
                  <span className="num b" style={{ fontSize: 17 }}>{n.rank}</span>
                  <span className={'small ' + mv} style={n.move === '新' ? { color: 'var(--p)' } : undefined}>{n.move}</span>
                </span>
                <Link to={'/work/' + n.id} title="进工作台"><Thumb w={88} h={58} i={i} src={n.thumb} label={<span className="imgn">{n.images}</span>} /></Link>
                <span className="col grow" style={{ gap: 5 }}>
                  <Link to={'/work/' + n.id} className="ttl">{n.title}</Link>
                  <span className="row wrap small muted" style={{ gap: 10 }}>
                    {n.huaren && <span className="chip c-y">华人</span>}
                    {!ok && <span className="chip c-w">{n.images === 0 ? '没有原图，点「图文」去一键找图' : `原图只有 ${n.images} 张，不够剪视频`}</span>}
                    <span className="row" style={{ gap: 6 }}><span className="heat"><i style={{ width: Math.min(100, n.medias * 6) + '%' }} /></span>{n.medias}家媒体</span>
                    <span>{n.cat} · {n.ago}跟进</span>
                  </span>
                </span>
                <span className="row" style={{ gap: 8, flex: 'none' }}>
                  <Link to={`/work/${n.id}?mode=text`} className="btn ghost sm">图文</Link>
                  <button className="btn soft sm" disabled={!ok || full || !!busy} onClick={() => make(n, 'quick')} title={ok ? '直接生成快讯' : '原图不够 2 张'}>快讯</button>
                  <button className="btn sm" disabled={!ok || full || !!busy} onClick={() => make(n, 'deep')} title={ok ? '直接生成深度解析' : '原图不够 2 张'}>深度</button>
                </span>
              </div>
            );
          })}
        </section>
        {data && data.total > data.pageSize && (
          <div className="row" style={{ justifyContent: 'center', gap: 8 }}>
            <span className="small muted">共 {data.total} 条 · 每页 {data.pageSize} 条</span>
            <button className="btn ghost sm" disabled={page <= 1} onClick={() => nav({ page: page - 1 })} aria-label="上一页">‹</button>
            {Array.from({ length: Math.ceil(data.total / data.pageSize) }, (_, i) => (
              <button key={i} className={'btn sm ' + (page === i + 1 ? '' : 'ghost')} onClick={() => nav({ page: i + 1 })}>{i + 1}</button>
            ))}
            <button className="btn ghost sm" disabled={page >= Math.ceil(data.total / data.pageSize)} onClick={() => nav({ page: page + 1 })} aria-label="下一页">›</button>
          </div>
        )}
      </div></div>
    </>
  );
}
