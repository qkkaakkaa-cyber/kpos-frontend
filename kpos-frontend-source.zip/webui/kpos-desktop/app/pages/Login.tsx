// 登录：只用工号（MK + 7 位数字），输入时显示成圆点
import { useState, type FormEvent } from 'react';
import { Icon, KMark } from '../../shared/icons';
import { go } from '../../shared/router';
import { api, http } from '../api';
import { useSession } from '../session';
import loginHero from '../assets/login-hero.jpg';

export function Login() {
  const { setMe } = useSession();
  const [code, setCode] = useState('');
  const [show, setShow] = useState(false);
  const [remember, setRemember] = useState(true);
  const [err, setErr] = useState('');
  const [busy, setBusy] = useState(false);

  async function submit(e: FormEvent) {
    e.preventDefault();
    if (busy || code.length !== 7) return;
    setBusy(true); setErr('');
    try {
      const r = await api.login(code, remember);
      http.setToken(r.token, remember, 7);
      setMe(r.me);
      go('/news');
    } catch (error) {
      setErr(error instanceof Error ? error.message : '登录失败，请重试。');
      setCode('');
    }
    finally { setBusy(false); }
  }

  return (
    <div className="app" style={{ alignItems: 'stretch', height: '100vh', minHeight: 640 }}>
      <section style={{ flex: '1 1 55%', minWidth: 0, position: 'relative', overflow: 'hidden', background: 'var(--p-dark)', color: '#FFFFFF', display: 'flex', flexDirection: 'column', justifyContent: 'space-between', padding: '40px 56px' }} className="login-hero">
        <img className="login-hero-image" src={loginHero} alt="" />
        <div className="row" style={{ position: 'relative', gap: 12 }}>
          <KMark size={46} bg="#FFFFFF" fg="#2E2552" />
          <span className="col" style={{ gap: 0, lineHeight: '24px' }}><span style={{ fontSize: 24, fontWeight: 700, letterSpacing: '.06em' }}>KPOS</span><span className="small" style={{ color: '#C9C0E6' }}>中文社传媒</span></span>
        </div>
        <div className="col" style={{ position: 'relative', gap: 18, maxWidth: 560 }}>
          <h1 style={{ margin: 0, fontSize: 44, lineHeight: '56px', fontWeight: 700, textWrap: 'balance' }}>贴一条新闻链接<br />几分钟后拿到能发的竖屏视频</h1>
          <p style={{ margin: 0, fontSize: 16, lineHeight: '28px', color: '#DCD6EE' }}>自动写口播、配音、找现场画面、加字幕，自动合成成片。快讯 1 分钟内，深度解析 2 到 3 分钟。</p>
          <div style={{ display: 'flex', gap: 28, paddingTop: 8 }}>
            {[['3 个国家', '泰国 · 大马 · 越南 一个入口'], ['3 分钟', '一条快讯平均用时'], ['6 个平台', '视频号 抖音 TikTok 快手 小红书 FB']].map(([a, b]) => (
              <span key={a} className="col" style={{ gap: 0 }}><span className={a === '3 分钟' ? 'num' : undefined} style={{ fontSize: 28, fontWeight: 700 }}>{a}</span><span className="small" style={{ color: '#C9C0E6' }}>{b}</span></span>
            ))}
          </div>
        </div>
        <span className="small" style={{ position: 'relative', display: 'flex', justifyContent: 'space-between' }}><span>kpos.com · 中文社传媒内部系统</span><span style={{ color: '#C9C0E6' }}>只能在公司网络或 VPN 下打开</span></span>
      </section>

      <section style={{ flex: '1 1 45%', boxSizing: 'content-box', minWidth: 0, display: 'flex', alignItems: 'center', justifyContent: 'center', background: '#FFFFFF', padding: 40 }}>
        <form onSubmit={submit} className="col" style={{ width: 380, maxWidth: '100%', gap: 22 }}>
          <div className="col" style={{ gap: 6 }}>
            <span className="chip c-p" style={{ alignSelf: 'flex-start' }}><Icon name="shield" size={12} />内部系统</span>
            <h2 style={{ margin: 0, fontSize: 26, lineHeight: '34px', fontWeight: 700 }}>登录 KPOS</h2>
            <span className="muted">输入你的工号</span>
          </div>
          <label className="col" style={{ gap: 6, fontWeight: 600 }}>工号
            <span style={{ height: 52, border: '2px solid ' + (err ? 'var(--r)' : 'var(--p)'), borderRadius: 10, padding: '0 6px 0 14px', display: 'flex', alignItems: 'center', gap: 10, background: '#FFFFFF' }}>
              <b className="num" style={{ fontSize: 18, color: 'var(--p-deep)', letterSpacing: '.04em' }}>MK</b>
              <span style={{ width: 1, height: 22, background: 'var(--line)' }} />
              <input type={show ? 'text' : 'password'} inputMode="numeric" autoComplete="off" autoFocus maxLength={7} value={code}
                aria-label="工号（MK 后面的 7 位数字）" aria-invalid={!!err}
                onChange={e => { setCode(e.target.value.replace(/\D/g, '').slice(0, 7)); setErr(''); }}
                style={{ flex: 1, minWidth: 0, border: 0, outline: 0, font: 'inherit', color: '#000000', fontSize: 20, letterSpacing: '.35em', background: 'transparent' }} />
              <button type="button" aria-label={show ? '隐藏工号' : '显示工号'} onClick={() => setShow(!show)}
                style={{ width: 40, height: 40, border: 0, borderRadius: 8, background: 'transparent', color: 'var(--grey)', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                <Icon name={show ? 'eyeoff' : 'eye'} />
              </button>
            </span>
            {err ? <span className="small" style={{ color: 'var(--r)', fontWeight: 600 }} role="alert">{err}</span>
              : <span className="small muted" style={{ fontWeight: 500 }}>工号都是 MK 开头，只填后面的 7 位数字；输入时显示成圆点</span>}
          </label>
          <div className="col" style={{ gap: 8, padding: '12px 14px', borderRadius: 12, background: 'var(--p-sel)' }}>
            <span className="small" style={{ fontWeight: 700, color: 'var(--p-deep)' }}>按工号自动进入你所属的工作区</span>
            <span className="row wrap" style={{ gap: 6 }}><span className="chip c-p">泰国中文社</span><span className="chip c-m">大马中文社</span><span className="chip c-y">越南中文社</span></span>
            <span className="small muted">三个国家一个入口，不用再分开登录。同时负责几个国家的编辑，由管理员开多个工作区，登录后在右上角切换。</span>
          </div>
          <label className="small row" style={{ gap: 8 }}><input type="checkbox" checked={remember} onChange={e => setRemember(e.target.checked)} />在这台电脑上保持登录 7 天</label>
          <span className="small" style={{ display: 'flex', gap: 8, alignItems: 'flex-start', color: 'var(--w-deep)' }}><Icon name="shield" size={16} /><span>连续输错 5 次，这台电脑锁定 15 分钟，并通知管理员。</span></span>
          <button className="btn lg" disabled={busy || code.length !== 7}>{busy ? '正在进入…' : '进入'}</button>
          <div style={{ padding: '14px 16px', borderRadius: 12, background: 'var(--bg)', color: 'var(--grey)', fontSize: 13, lineHeight: '21px' }}>
            工号就是你的登录凭证，别告诉别人，也别让旁边的人看到。<br />只能在公司网络或 VPN 下打开；没有工号找管理员开。
          </div>
        </form>
      </section>
    </div>
  );
}
