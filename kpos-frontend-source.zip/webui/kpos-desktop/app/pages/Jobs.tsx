// 生成记录：左边列表（今天 / 昨天），右边大预览、下载、复制标题，改文案、换画面、分享图文
import { useEffect, useRef, useState } from 'react';
import { Icon } from '../../shared/icons';
import { go, Link } from '../../shared/router';
import { copyText, Empty, ErrorBox, fmtClock, fmtDur, KIND, Loading, Modal, Seg, Tabs, Thumb, useAsync, useInterval, useToast } from '../../shared/ui';
import { api } from '../api';
import { useSession } from '../session';
import type { Job, Scene } from '../types';

type F = 'all' | 'active' | 'failed';

export function Jobs({ selected, filter }: { selected?: string; filter: F }) {
  const { refreshQueue, queue } = useSession();
  const toast = useToast();
  const { data, error, loading, reload, setData } = useAsync(() => api.jobs(filter), [filter]);
  const live = !!data?.some(j => ['running', 'queued'].includes(j.status));
  useInterval(() => api.jobs(filter).then(setData).catch(() => {}), live ? 3000 : null);

  const list = data || [];
  const sel = list.find(j => j.id === selected) || list.find(j => j.status === 'done');
  const activeN = queue ? queue.running.length + queue.queued.length : 0;
  const to = (id: string) => go(`/jobs/${id}${filter !== 'all' ? '?f=' + filter : ''}`);

  async function act(e: { stopPropagation: () => void }, j: Job, what: 'cancel' | 'retry') {
    e.stopPropagation();
    try {
      if (what === 'cancel') await api.cancel(j.id); else await api.retry(j.id);
      refreshQueue(); reload(); toast(what === 'cancel' ? '已取消' : '已重新提交');
    } catch (er: any) { toast(er.message); }
  }

  const groups: [string, Job[]][] = [['今天', list.filter(j => j.day === 'today')], ['昨天', list.filter(j => j.day === 'yesterday')], ['更早', list.filter(j => j.day === 'earlier')]];
  return (
    <>
      <header className="top"><h1>生成记录</h1><span className="sub">做好的视频保留 30 天 · 同时最多 {queue?.limit ?? 5} 条（剪辑中 + 排队），满了要等前面做完</span></header>
      <div style={{ padding: '16px 28px 0' }}>
        <Tabs value={filter} onChange={v => go(v === 'all' ? '/jobs' : '/jobs?f=' + v)} options={[{ v: 'all', label: '全部' }, { v: 'active', label: `进行中 ${activeN}` }, { v: 'failed', label: '失败' }]} />
      </div>
      <div className="body">
        <section className="card col" style={{ flex: '1 1 0', gap: 2, padding: 12 }}>
          {loading && !data ? <Loading rows={6} /> : error ? <ErrorBox error={error} retry={reload} /> : !list.length ? <Empty>{filter === 'failed' ? '没有失败的' : filter === 'active' ? '现在没有在做的' : '还没做过视频，去「新闻」挑一条'}</Empty> :
            groups.filter(g => g[1].length).map(([name, js]) => (
              <div key={name} className="col" style={{ gap: 2 }}>
                <span className="small muted b" style={{ padding: '8px 14px 4px' }}>{name}</span>
                {js.map(j => <Row key={j.id} j={j} on={sel?.id === j.id} onClick={() => j.status === 'running' || j.status === 'queued' || j.status === 'review' ? go((j.status === 'review' ? '/review/' : '/progress/') + j.id) : to(j.id)} act={act} />)}
              </div>
            ))}
        </section>
        <aside className="card col" style={{ flex: '0 0 460px', gap: 0, overflow: 'hidden' }}>
          {sel ? <Detail key={sel.id} j={sel} onChanged={() => { reload(); refreshQueue(); }} /> : <Empty>选一条做好的视频</Empty>}
        </aside>
      </div>
    </>
  );
}

function Row({ j, on, onClick, act }: { j: Job; on: boolean; onClick: () => void; act: (e: any, j: Job, w: 'cancel' | 'retry') => void }) {
  const ic = { done: ['check', 'var(--m-deep)', 'var(--m-soft)'], running: ['clock', 'var(--p)', 'var(--p-soft)'], review: ['doc', 'var(--y-deep)', 'var(--y-soft)'], queued: ['clock', 'var(--grey)', 'var(--g-soft)'], failed: ['x', 'var(--r)', 'var(--r-soft)'], cancelled: ['x', 'var(--muted)', 'var(--g-soft)'] }[j.status];
  const sub = j.status === 'done' ? `${KIND[j.kind] === '深度解析' ? '深度' : KIND[j.kind]} · ${fmtDur(j.duration || 0)}`
    : j.status === 'running' ? `剪辑中 · ${j.progress}% · ${j.stage}`
    : j.status === 'review' ? '稿子写好了 · 等你确认'
    : j.status === 'queued' ? `排队 · 第 ${j.queuePos} 位 · ${j.eta}`
    : `${j.status === 'failed' ? '失败' : '已终止'} · ${j.failReason || ''}`;
  return (
    <div role="button" tabIndex={0} onClick={onClick} onKeyDown={e => e.key === 'Enter' && onClick()}
      className="row" style={{ gap: 12, padding: '11px 14px', borderRadius: 12, cursor: 'pointer', ...(on ? { background: 'var(--p-sel)', boxShadow: 'inset 0 0 0 2px var(--p)' } : {}) }}>
      <span style={{ width: 36, height: 36, flex: 'none', borderRadius: 10, background: ic[2], display: 'flex', alignItems: 'center', justifyContent: 'center' }}><Icon name={ic[0]} size={18} color={ic[1]} sw={j.status === 'done' ? 2.5 : 2} /></span>
      <span className="col grow" style={{ gap: 0 }}><span className="sb ell">{j.title}</span><span className="small muted ell">{sub}</span></span>
      {j.status === 'queued' && <button className="btn ghost sm" onClick={e => act(e, j, 'cancel')}>取消</button>}
      {j.status === 'failed' && <button className="btn soft sm" onClick={e => act(e, j, 'retry')}>重试</button>}
      <span className="small muted num">{j.createdAt}</span>
    </div>
  );
}

function Detail({ j, onChanged }: { j: Job; onChanged: () => void }) {
  const toast = useToast();
  const [tab, setTab] = useState<'title' | 'script' | 'scenes' | 'share'>('title');
  const [title, setTitle] = useState(j.publishTitle || '');
  const [script, setScript] = useState((j.script || []).join('\n\n'));
  const [scenes, setScenes] = useState<Scene[]>(j.scenes || []);
  const [pick, setPick] = useState<Scene | null>(null);
  const [playing, setPlaying] = useState(false);
  const file = useRef<HTMLInputElement>(null);
  useEffect(() => { setScenes(j.scenes || []); }, [j.id]);

  if (j.status !== 'done') return (
    <div className="pad col" style={{ gap: 12 }}>
      <span className="h2">{j.title}</span>
      <span className="muted">{j.status === 'failed' ? '失败：' + j.failReason : j.status === 'cancelled' ? '已终止' : '还在做'}</span>
      {['running', 'queued', 'review'].includes(j.status) && <Link to={'/progress/' + j.id} className="btn">看进度</Link>}
    </div>
  );

  const changes = scenes.filter(s => s.changed).length + (script !== (j.script || []).join('\n\n') ? 1 : 0);
  const dur = j.duration || 0;
  return (
    <>
      <div style={{ background: 'var(--p-dark)', padding: '18px 0', display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 8 }}>
        <div style={{ width: 200, aspectRatio: '9/16', borderRadius: 12, overflow: 'hidden', position: 'relative', background: '#3B2E66', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
          {j.videoUrl ? <video src={j.videoUrl} controls poster={j.coverUrl || undefined} style={{ width: '100%', height: '100%' }} /> : (
            <button aria-label="播放" onClick={() => { setPlaying(!playing); toast('演示模式没有真视频'); }} style={{ width: 56, height: 56, borderRadius: 9999, border: 0, background: '#FFFFFF', color: 'var(--p)', display: 'flex', alignItems: 'center', justifyContent: 'center' }}><Icon name="play" size={22} /></button>
          )}
          <span className="num" style={{ position: 'absolute', left: 8, bottom: 8, padding: '1px 6px', borderRadius: 6, background: '#FFFFFF', fontSize: 11, fontWeight: 600 }}>0:00 / {fmtClock(dur)}</span>
        </div>
        <span className="small" style={{ color: '#C9C0E6' }}>竖屏 1080×1920 · 点全屏看清楚字幕</span>
      </div>
      <div className="pad col" style={{ gap: 14 }}>
        <div className="col" style={{ gap: 6 }}>
          <span className="row" style={{ gap: 6 }}><span className="chip c-m"><Icon name="check" size={10} sw={3} />做好了</span><span className="chip c-p">{KIND[j.kind]}</span></span>
          <span style={{ fontSize: 17, lineHeight: '25px', fontWeight: 700 }}>{j.title}</span>
          <span className="small muted">今天 {j.createdAt}{j.sourceUrl && <> · <a href={j.sourceUrl} target="_blank" rel="noreferrer noopener">原文 ↗</a></>}</span>
        </div>
        <div className="row" style={{ gap: 10 }}>
          <a className="btn lg grow" href={j.videoUrl || '#'} download onClick={e => { if (!j.videoUrl) { e.preventDefault(); toast('演示模式没有真视频文件'); } }}><Icon name="dl" size={18} />下载视频</a>
          <button className="btn lg soft grow" onClick={async () => toast((await copyText(title)) ? '标题已复制' : '复制不了，请手动选中复制')}><Icon name="copy" size={18} />复制标题</button>
        </div>
        <Seg value={tab} onChange={setTab} options={[{ v: 'title', label: '发布标题' }, { v: 'script', label: '口播文案' }, { v: 'scenes', label: '换画面' }, { v: 'share', label: '分享图文' }]} />

        {tab === 'title' && <>
          <textarea className="in" rows={3} value={title} onChange={e => setTitle(e.target.value)} aria-label="发布标题" style={{ fontSize: 14, lineHeight: '23px' }} />
          <span className="small muted" style={{ textAlign: 'center' }}>下载好、复制好标题，到抖音、视频号、小红书等直接上传就行</span>
        </>}
        {tab === 'script' && <>
          <textarea className="in" rows={9} value={script} onChange={e => setScript(e.target.value)} aria-label="口播文案" style={{ fontSize: 14, lineHeight: '23px' }} />
          <span className="small muted">改了文案要重新配音和剪辑，画面尽量保留。</span>
        </>}
        {tab === 'scenes' && <>
          <span className="small muted">视频里的 {scenes.length} 个画面。点画面：换成本地图片、换成一键找到的图，或删掉</span>
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, minmax(0,1fr))', gap: 8 }}>
            {scenes.map((s, i) => (
              <button key={s.n} type="button" onClick={() => setPick(s)} className="col" style={{ gap: 3, border: 0, background: 'none', padding: 0, textAlign: 'left' }}>
                <Thumb w="100%" h={0} i={i} src={s.src} style={{ aspectRatio: '9/16', height: 'auto', outline: s.changed ? '3px solid var(--p)' : 'none', outlineOffset: -3 }} />
                <span className="small b">{s.type}{s.changed && <span className="chip c-p" style={{ marginLeft: 4 }}>已换</span>}</span><span className="small muted">{s.sec}秒</span>
              </button>
            ))}
          </div>
        </>}
        {tab === 'share' && <ShareText j={j} />}

        {changes > 0 && (
          <div className="tip row wrap" style={{ gap: 10 }}>
            <span className="grow"><b>{changes} 处改动</b>：{scenes.filter(s => s.changed).map(s => `第 ${s.n} 个画面换了`).join('、')}{script !== (j.script || []).join('\n\n') ? (scenes.some(s => s.changed) ? '，' : '') + '口播改了' : '，口播不变'}。</span>
            <button className="btn ghost sm" onClick={() => { setScenes(j.scenes || []); setScript((j.script || []).join('\n\n')); }}>撤销</button>
            <button className="btn sm" onClick={async () => { try { const n = await api.regenerate(j.id, { script, scenes: scenes.filter(s => s.changed) }); toast('已按改动重新生成'); onChanged(); go('/progress/' + n.id); } catch (e: any) { toast(e.message); } }}>按改动重新生成</button>
          </div>
        )}
      </div>
      <input ref={file} type="file" accept="image/*" hidden onChange={e => {
        const f = e.target.files?.[0]; if (!f || !pick) return;
        setScenes(scenes.map(s => s.n === pick.n ? { ...s, src: URL.createObjectURL(f), changed: true, type: '照片' } : s)); setPick(null); e.target.value = '';
      }} />
      {pick && (
        <Modal title={`第 ${pick.n} 个画面 · ${pick.type} · ${pick.sec}秒`} onClose={() => setPick(null)} actions={<button className="btn ghost" onClick={() => setPick(null)}>关闭</button>}>
          <div className="col" style={{ gap: 8 }}>
            <button className="btn ghost" onClick={() => file.current?.click()}><Icon name="upload" size={16} />换成本地图片</button>
            <button className="btn ghost" onClick={() => { setScenes(scenes.map(s => s.n === pick.n ? { ...s, changed: true } : s)); setPick(null); }}><Icon name="image" size={16} />换成一键找到的图</button>
            <button className="btn warn" disabled={scenes.length <= 2} onClick={() => { setScenes(scenes.filter(s => s.n !== pick.n).concat()); setPick(null); toast('删掉了，时长分给前后画面'); }}>删掉这个画面</button>
          </div>
        </Modal>
      )}
    </>
  );
}

function ShareText({ j }: { j: Job }) {
  const toast = useToast();
  const [t, setT] = useState(`${j.title}\n\n${(j.script || []).slice(0, 2).join('\n')}\n\n#泰国新闻 #泰国中文社`);
  return <>
    <textarea className="in" rows={8} value={t} onChange={e => setT(e.target.value)} aria-label="图文文案" style={{ fontSize: 13, lineHeight: '21px' }} />
    <button className="btn soft" onClick={async () => toast((await copyText(t)) ? '图文文案已复制' : '复制不了，请手动选中复制')}><Icon name="copy" size={16} />复制图文文案</button>
    {j.articleId && <Link to={`/work/${j.articleId}?mode=text`} className="small sb">去工作台选配图 →</Link>}
  </>;
}
