// 公众号剪辑：贴链接提取标题、正文、配图，再做快讯 / 深度 / 图文
import { useState } from 'react';
import { Icon } from '../../shared/icons';
import { go, Link } from '../../shared/router';
import { ErrorBox, Loading, Thumb, useAsync, useToast } from '../../shared/ui';
import { api } from '../api';
import { WorkspaceSwitch } from '../layout/Shell';
import { useSession } from '../session';
import type { WechatItem } from '../types';

export function Wechat() {
  const toast = useToast();
  const { refreshQueue, me } = useSession();
  const [text, setText] = useState('');
  const [busy, setBusy] = useState(false);
  const [fresh, setFresh] = useState<WechatItem[]>([]);
  const recent = useAsync(() => api.wechatRecent(), []);

  async function extract() {
    const urls = text.split(/\s+/).filter(Boolean);
    setBusy(true);
    try { const r = await api.wechatExtract(urls); setFresh(r); setText(''); recent.reload(); toast(`提取了 ${r.length} 篇`); }
    catch (e: any) { toast(e.message); } finally { setBusy(false); }
  }
  async function quick(w: WechatItem) {
    try { await api.createJob({ kind: 'quick', articleId: w.id }); refreshQueue(); toast('已提交快讯，左下角看进度'); } catch (e: any) { toast(e.message); }
  }

  const Item = ({ w, i, big }: { w: WechatItem; i: number; big?: boolean }) => {
    const ok = w.images >= 2;
    return (
      <div className="row" style={{ gap: 14, padding: big ? 0 : '12px 16px', borderTop: big ? 0 : '1px solid var(--line2)' }}>
        <Thumb w={big ? 120 : 88} h={big ? 80 : 58} i={i} label={<span className="imgn">{w.images}</span>} />
        <span className="col grow" style={{ gap: 4 }}>
          {big && <span className="small muted">{w.account} · {w.at} · {w.chars.toLocaleString()} 字 · {w.images} 张原图</span>}
          <Link to={'/work/' + w.id} className="sb" style={{ color: 'var(--ink)', textDecoration: 'none', fontSize: big ? 17 : 15 }}>{w.title}</Link>
          {big ? <span className="small muted">{w.summary}</span> : <span className="row wrap small muted" style={{ gap: 8 }}><span className="chip c-m">公众号</span>{w.account} · {w.at}{w.done && <span className="chip c-g">{w.done}</span>}{!ok && <span className="chip c-w">原图不够 2 张，进工作台用「一键找图」补</span>}</span>}
        </span>
        <span className="row" style={{ gap: 8, flex: 'none' }}>
          <Link to={`/work/${w.id}?mode=text`} className="btn ghost sm">{big ? '做图文' : '图文'}</Link>
          <button className="btn soft sm" disabled={!ok} onClick={() => quick(w)}>快讯</button>
          <button className="btn sm" disabled={!ok} onClick={() => go(`/work/${w.id}?kind=deep`)}>{big ? '深度（可写提示）' : '深度'}</button>
        </span>
      </div>
    );
  };

  return (
    <>
      <header className="top"><h1>公众号剪辑</h1><span className="sub">贴公众号文章链接，取出标题、正文和配图，再做快讯、深度或图文</span><div className="right"><WorkspaceSwitch /></div></header>
      <div className="center"><div className="inner" style={{ maxWidth: 1000 }}>
        <section className="card pad col" style={{ gap: 12 }}>
          <span className="h2">贴公众号文章链接</span>
          <div className="row" style={{ alignItems: 'stretch' }}>
            <textarea className="in grow" rows={Math.min(5, Math.max(2, text.split('\n').length))} value={text} onChange={e => setText(e.target.value)} placeholder="https://mp.weixin.qq.com/s/[文章链接]" aria-label="公众号文章链接，每行一条" style={{ fontSize: 14, lineHeight: '22px' }} />
            <button className="btn lg" disabled={busy || !text.trim()} onClick={extract} style={{ height: 'auto' }}>{busy ? '提取中…' : '提取'}</button>
          </div>
          <span className="small muted">一次可以贴多条，每行一条，最多 5 条（同时最多 5 条在做）。公众号文章已经是中文，按{me?.workspace.name}格式改写口播。</span>
        </section>
        {fresh.map((w, i) => <section key={w.id} className="card pad"><span className="chip c-m" style={{ marginBottom: 8 }}>刚提取</span><Item w={w} i={i} big /></section>)}
        <section className="card" style={{ overflow: 'hidden' }}>
          <div className="row" style={{ padding: '14px 16px' }}><span className="h2">最近提取过的公众号文章</span><span className="small muted">保留 7 天，点标题进工作台</span></div>
          {recent.loading && !recent.data ? <Loading /> : recent.error ? <div className="pad"><ErrorBox error={recent.error} retry={recent.reload} /></div> : recent.data!.map((w, i) => <Item key={w.id} w={w} i={i} />)}
        </section>
      </div></div>
    </>
  );
}
