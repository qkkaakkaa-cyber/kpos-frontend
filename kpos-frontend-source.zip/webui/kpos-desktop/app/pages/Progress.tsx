// 生成中：进度、三个阶段、口播文案。深度解析写好稿子后停下来等确认
import { useState } from 'react';
import { Icon } from '../../shared/icons';
import { go, Link } from '../../shared/router';
import { ErrorBox, KIND, Loading, Modal, useAsync, useInterval, useToast } from '../../shared/ui';
import { api } from '../api';
import { useSession } from '../session';

const PHASES = ['查资料、写文案', '配音、找画面', '剪辑、导出'];

export function Progress({ id }: { id: string }) {
  const toast = useToast();
  const { refreshQueue } = useSession();
  const { data: j, error, loading, reload, setData } = useAsync(() => api.job(id), [id]);
  const [ask, setAsk] = useState(false);
  const live = !!j && ['queued', 'running'].includes(j.status);
  useInterval(() => api.job(id).then(setData).catch(() => {}), live ? 3000 : null);

  async function cancel() {
    setAsk(false);
    try { setData(await api.cancel(id)); refreshQueue(); toast('已终止'); } catch (e: any) { toast(e.message); }
  }
  async function confirm() {
    try { setData(await api.confirm(id)); refreshQueue(); toast('开始配音和剪辑'); } catch (e: any) { toast(e.message); }
  }

  return (
    <>
      <header className="top"><Link to="/jobs" className="back"><Icon name="left" />生成记录</Link></header>
      {loading ? <Loading /> : error ? <div className="body"><ErrorBox error={error} retry={reload} /></div> : (
        <div className="center"><div className="inner" style={{ maxWidth: 760, gap: 20 }}>
          <div className="col" style={{ gap: 8 }}>
            <span className={'chip ' + (j!.kind === 'deep' ? 'c-p' : 'c-g')} style={{ alignSelf: 'flex-start' }}>{KIND[j!.kind]}</span>
            <h2 style={{ margin: 0, fontSize: 24, lineHeight: '33px', fontWeight: 700 }}>{j!.title}</h2>
          </div>

          <section className="card col" style={{ padding: 24, gap: 20 }}>
            {j!.status === 'queued' && <div className="row" style={{ alignItems: 'baseline', gap: 12 }}><span style={{ fontSize: 32, fontWeight: 700 }}>排第 {j!.queuePos} 位</span><span className="muted">{j!.eta}</span></div>}
            {(j!.status === 'running' || j!.status === 'review') && <div className="row" style={{ alignItems: 'baseline', gap: 12 }}><span className="num" style={{ fontSize: 40, lineHeight: '48px', fontWeight: 700 }}>{j!.progress}%</span><span className="muted">{j!.status === 'review' ? '稿子写好了，等你确认' : j!.eta}</span></div>}
            {j!.status === 'done' && <div className="row" style={{ gap: 10 }}><span className="chip c-m" style={{ fontSize: 13, padding: '3px 10px' }}><Icon name="check" size={12} sw={3} />做好了</span><Link to={'/jobs/' + j!.id} className="btn">去下载和发布</Link></div>}
            {(j!.status === 'failed' || j!.status === 'cancelled') && <div className="row" style={{ gap: 10 }}><span className={'chip ' + (j!.status === 'failed' ? 'c-r' : 'c-g')}>{j!.status === 'failed' ? '失败' : '已终止'}</span><span className="muted">{j!.failReason}</span>
              <button className="btn" style={{ marginLeft: 'auto' }} onClick={async () => { try { const n = await api.retry(j!.id); refreshQueue(); go('/progress/' + n.id); } catch (e: any) { toast(e.message); } }}>重新生成</button></div>}

            <div className="row" style={{ gap: 12, alignItems: 'flex-start' }}>
              {PHASES.map((t, i) => {
                const st = j!.status === 'done' || i < j!.phase ? 'done' : i === j!.phase && j!.status === 'running' ? 'now' : j!.status === 'review' && i === 0 ? 'done' : 'todo';
                return (
                  <div key={t} className="col grow" style={{ gap: 8 }}>
                    <div style={{ height: 6, borderRadius: 9999, background: st === 'done' ? 'var(--m)' : st === 'now' ? 'var(--p)' : 'var(--line)' }} />
                    <span style={{ fontSize: 14, fontWeight: st === 'now' ? 700 : 600, color: st === 'todo' ? 'var(--muted)' : 'var(--ink)' }}>{t}</span>
                    <span className="small muted">{st === 'done' ? '完成' : st === 'now' ? j!.stage : ''}</span>
                  </div>
                );
              })}
            </div>
            {j!.status === 'review' && (
              <div className="tip row wrap" style={{ gap: 10 }}>
                <span className="grow">资料查完、稿子写好了。改完点「确认出片」才开始配音和剪辑。</span>
                <Link to={'/review/' + j!.id} className="btn ghost">打开深度稿修改</Link>
                <button className="btn" onClick={confirm}>不改了，直接出片</button>
              </div>
            )}
            {live && <span className="small muted">可以关掉这个页面，做好了在「生成记录」里看。</span>}
          </section>

          {j!.script && j!.phase > 0 && (
            <section className="card" style={{ overflow: 'hidden' }}>
              <div className="row" style={{ padding: '16px 20px', borderBottom: '1px solid var(--line2)' }}>
                <Icon name="doc" color="#6A55A0" /><span className="h2">口播文案</span><span className="small muted">已经写好</span>
                {j!.kind === 'deep' && <Link to={'/review/' + j!.id} className="btn ghost sm" style={{ marginLeft: 'auto' }}>打开深度稿</Link>}
              </div>
              <div className="col" style={{ padding: '16px 20px', gap: 10, fontSize: 15, lineHeight: '26px' }}>
                {j!.script.map((p, i) => <p key={i} className={i ? 'muted' : ''} style={{ margin: 0 }}>{p}</p>)}
              </div>
            </section>
          )}
          {(live || j!.status === 'review') && <button className="btn warn" style={{ alignSelf: 'center' }} onClick={() => setAsk(true)}>不做了</button>}
        </div></div>
      )}
      {ask && <Modal title="不做这条了？" onClose={() => setAsk(false)} actions={<><button className="btn ghost" onClick={() => setAsk(false)}>继续做</button><button className="btn" style={{ background: 'var(--r)' }} onClick={cancel}>不做了</button></>}>
        <span className="muted">已经查到的资料不会保留，今天的额度不退回。</span>
      </Modal>}
    </>
  );
}
