// 手动上传：用自己拍的图片、视频做新闻视频
import { useRef, useState } from 'react';
import { Icon } from '../../shared/icons';
import { go } from '../../shared/router';
import { Seg, useToast } from '../../shared/ui';
import { api } from '../api';
import { ProdOptions, Slider, usePrefs } from '../components';
import { WorkspaceSwitch } from '../layout/Shell';
import { useSession } from '../session';

type F = { id: string; file: File; url: string; video: boolean };
const MAX = 8;

export function Upload() {
  const toast = useToast();
  const { refreshQueue, me } = useSession();
  const [files, setFiles] = useState<F[]>([]);
  const [drag, setDrag] = useState(false);
  const [mode, setMode] = useState<'rewrite' | 'verbatim'>('rewrite');
  const [text, setText] = useState('');
  const [title, setTitle] = useState('');
  const [date, setDate] = useState(() => new Date().toISOString().slice(0, 10));
  const [signoff, setSignoff] = useState(true);
  const [origVol, setOrigVol] = useState(10);
  const [prefs, setPrefs] = usePrefs();
  const [busy, setBusy] = useState(false);
  const input = useRef<HTMLInputElement>(null);
  const [lo, hi] = mode === 'rewrite' ? [40, 6000] : [10, 800];

  function add(list: FileList | null) {
    if (!list) return;
    const ok = Array.from(list).filter(f => /^(image|video)\//.test(f.type));
    if (ok.length < list.length) toast('只能放图片和视频');
    const room = MAX - files.length;
    if (ok.length > room) toast(`最多 ${MAX} 个，多的没加`);
    setFiles(fs => [...fs, ...ok.slice(0, room).map(f => ({ id: Math.random().toString(36).slice(2), file: f, url: URL.createObjectURL(f), video: f.type.startsWith('video/') }))]);
  }

  async function submit() {
    setBusy(true);
    try {
      const j = await api.uploadJob({ files: files.map(f => ({ name: f.file.name, size: f.file.size, type: f.file.type })), mode, text, title, date, signoff, origVol, prefs });
      refreshQueue(); go('/progress/' + j.id);
    } catch (e: any) { toast(e.message); } finally { setBusy(false); }
  }

  return (
    <>
      <header className="top"><h1>手动上传</h1><span className="sub">用自己拍的图片、视频做新闻视频</span><div className="right"><WorkspaceSwitch /></div></header>
      <div className="body">
        <section className="card pad col" style={{ flex: '1 1 0', gap: 14 }}>
          <div className="row"><span className="h2">素材</span><span className="small muted">已选 {files.length} 个 · 最多 {MAX} 个，视频和图片都可以</span></div>
          <div onDragOver={e => { e.preventDefault(); setDrag(true); }} onDragLeave={() => setDrag(false)} onDrop={e => { e.preventDefault(); setDrag(false); add(e.dataTransfer.files); }}
            style={{ border: '2px dashed ' + (drag ? 'var(--p)' : 'var(--input)'), background: drag ? 'var(--p-sel)' : 'var(--bg)', borderRadius: 14, padding: 28, display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 8 }}>
            <Icon name="upload" size={28} color="#6A55A0" />
            <span>把图片、视频拖到这里，或 <button className="back" style={{ display: 'inline' }} onClick={() => input.current?.click()}>选择文件</button></span>
            <span className="small muted">视频超过 200MB 会先自动压缩；至少要 20 秒的素材</span>
            <input ref={input} type="file" multiple accept="image/*,video/*" hidden onChange={e => { add(e.target.files); e.target.value = ''; }} />
          </div>
          {files.length > 0 && (
            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, minmax(0,1fr))', gap: 10 }}>
              {files.map(f => (
                <div key={f.id} className="col" style={{ gap: 4, position: 'relative' }}>
                  <div style={{ aspectRatio: '16/10', borderRadius: 10, overflow: 'hidden', background: 'var(--line)' }}>
                    {f.video ? <video src={f.url} muted style={{ width: '100%', height: '100%', objectFit: 'cover' }} /> : <img src={f.url} alt="" style={{ width: '100%', height: '100%', objectFit: 'cover' }} />}
                  </div>
                  <span className="small muted ell">{f.video ? '视频' : '图片'} · {f.file.name}</span>
                  <button aria-label="移除" onClick={() => setFiles(files.filter(x => x.id !== f.id))} style={{ position: 'absolute', right: 6, top: 6, width: 24, height: 24, borderRadius: 9999, border: 0, background: 'rgba(38,40,51,.7)', color: '#FFFFFF', display: 'flex', alignItems: 'center', justifyContent: 'center' }}><Icon name="x" size={12} sw={3} /></button>
                </div>
              ))}
            </div>
          )}
          <div className="row wrap" style={{ justifyContent: 'space-between' }}><span className="col" style={{ gap: 0 }}><span className="sb" style={{ fontSize: 13 }}>视频原声音量</span><span className="small muted">现场声音小一点，盖不住配音</span></span><Slider v={origVol} max={100} onChange={setOrigVol} /></div>
        </section>
        <aside className="card pad col" style={{ flex: '0 0 440px', gap: 14 }}>
          <span className="h2">制作区</span>
          <div className="col" style={{ gap: 8 }}>
            <span className="small sb muted">文案怎么来</span>
            <Seg value={mode} onChange={setMode} options={[{ v: 'rewrite', label: '按模板改写' }, { v: 'verbatim', label: '原样配音' }]} />
            <span className="small muted">按模板改写：贴新闻资料或文稿（40–6000 字），系统按{me?.workspace.name}格式写口播。原样配音：文案一字不改（10–800 字）。</span>
          </div>
          <label className="lab">{mode === 'rewrite' ? '新闻资料或文稿' : '口播文案（一字不改）'}
            <textarea className="in" rows={6} value={text} maxLength={hi} onChange={e => setText(e.target.value)} placeholder={mode === 'rewrite' ? '把现场情况、警方通报、采访内容贴在这里……' : '这段会原样配音'} style={{ fontSize: 14, lineHeight: '22px' }} />
            <span className="small num" style={{ textAlign: 'right', fontWeight: 500, color: text.length && text.length < lo ? 'var(--r)' : 'var(--grey)' }}>{text.length} / {hi} 字{text.length > 0 && text.length < lo ? `，至少 ${lo} 字` : ''}</span>
          </label>
          <div className="row" style={{ gap: 10 }}>
            <label className="lab grow">标题（可不填）<input className="in" value={title} onChange={e => setTitle(e.target.value)} placeholder="不填就自动起" /></label>
            <label className="lab">报道日期<input className="in" type="date" value={date} onChange={e => setDate(e.target.value)} /></label>
          </div>
          <label className="small row" style={{ gap: 8 }}><input type="checkbox" checked={signoff} onChange={e => setSignoff(e.target.checked)} />结尾加“{me?.workspace.name}X月X日报道”</label>
          <ProdOptions value={prefs} onChange={setPrefs} lengths={[30, 45, 60, 90]} />
          <button className="btn lg" disabled={busy || !files.length || text.length < lo} onClick={submit}>{busy ? '上传中…' : '一键生成视频'}</button>
          <span className="small muted" style={{ textAlign: 'center' }}>先上传素材，再写口播、配音、剪辑</span>
        </aside>
      </div>
    </>
  );
}
