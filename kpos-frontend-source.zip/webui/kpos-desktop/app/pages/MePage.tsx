// 我的：工号、角色、工作区、今天的额度、退出
import { Icon } from '../../shared/icons';
import { useAsync } from '../../shared/ui';
import { api } from '../api';
import { logout, WorkspaceSwitch } from '../layout/Shell';
import { useSession } from '../session';

export function MePage() {
  const { me, setMe, queue } = useSession();
  const prefs = useAsync(() => api.prefs(), []);
  if (!me) return null;
  const q = (k: 'quick' | 'deep') => !queue ? '—' : queue.quota[k].limit === null ? `${queue.quota[k].used} 条 · 不限` : `${queue.quota[k].used} / ${queue.quota[k].limit} 条`;
  return (
    <>
      <header className="top"><h1>我的</h1><div className="right"><WorkspaceSwitch /></div></header>
      <div className="center"><div className="inner" style={{ maxWidth: 720 }}>
        <section className="card pad row" style={{ gap: 16 }}>
          <span className="av" style={{ width: 52, height: 52, fontSize: 20 }}>{me.name.slice(0, 1)}</span>
          <span className="col grow" style={{ gap: 2 }}><b style={{ fontSize: 18 }}>{me.name}</b><span className="muted">{me.roleName} · 工号 {me.codeMask} · {me.workspace.name}</span></span>
          <button className="btn ghost" onClick={() => logout(setMe)}><Icon name="logout" size={16} />退出登录</button>
        </section>
        <section className="card pad col" style={{ gap: 10 }}>
          <span className="h2">今天的额度</span>
          <div className="kv"><span>快讯</span><span className="num">{q('quick')}</span><span>深度解析</span><span className="num">{q('deep')}</span><span>同时在做</span><span className="num">最多 {queue?.limit ?? 5} 条（剪辑中 + 排队）</span></div>
          <span className="small muted">额度不够找主编；额度每天 0 点重置。</span>
        </section>
        <section className="card pad col" style={{ gap: 10 }}>
          <span className="h2">能用的工作区</span>
          <div className="row wrap">{me.workspaces.map(w => <span key={w.id} className={'chip ' + (w.id === me.workspace.id ? 'c-p' : 'c-g')}>{w.short} · {w.name}</span>)}</div>
          <span className="small muted">要负责别的国家，找管理员在后台给你的工号加工作区。</span>
        </section>
        {prefs.data && <section className="card pad col" style={{ gap: 10 }}>
          <span className="h2">记住的制作选项</span>
          <div className="kv"><span>配音</span><span>{prefs.data.voice} · 语速 {prefs.data.speed.toFixed(1)} · 音量 {prefs.data.voiceVol}%</span><span>背景音乐</span><span>{prefs.data.music} · 音量 {prefs.data.musicVol}%</span><span>快讯长度</span><span>{prefs.data.length} 秒</span></div>
          <span className="small muted">在工作台的「制作选项」里改，改了下次默认。</span>
        </section>}
        <div className="note">工号就是登录凭证。不用的时候点「退出登录」，尤其是公用电脑。</div>
      </div></div>
    </>
  );
}
