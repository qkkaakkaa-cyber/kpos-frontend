// 左侧菜单 + 进行中的任务卡片；顶栏右边的工作区切换
import { useState, type ReactNode } from 'react';
import { Icon, KMark } from '../../shared/icons';
import { go, Link } from '../../shared/router';
import { KIND, useToast } from '../../shared/ui';
import { api, http } from '../api';
import { useSession } from '../session';

const NAV = [
  { k: 'news', icon: 'news', label: '新闻', to: '/news' },
  { k: 'wechat', icon: 'wechat', label: '公众号剪辑', to: '/wechat' },
  { k: 'smart', icon: 'pen', label: '智能剪辑', to: '/smart' },
  { k: 'upload', icon: 'upload', label: '手动上传', to: '/upload' },
  { k: 'jobs', icon: 'list', label: '生成记录', to: '/jobs' },
  { k: 'me', icon: 'user', label: '我的', to: '/me' },
];

export function Shell({ nav, children }: { nav: string; children: ReactNode }) {
  const { me, queue } = useSession();
  const activeN = queue ? queue.running.length + queue.queued.length : 0;
  const q = (v: { used: number; limit: number | null }) => v.limit === null ? `${v.used}/不限` : `${v.used}/${v.limit}`;
  return (
    <div className="app">
      <aside className="side" aria-label="主菜单">
        <div className="brand"><KMark /><span>KPOS<small>中文社传媒 · 剪辑工作台</small></span></div>
        {NAV.map(n => (
          <Link key={n.k} to={n.to} className={'nav' + (nav === n.k ? ' on' : '')}>
            <Icon name={n.icon} />{n.label}{n.k === 'jobs' && activeN > 0 && <span className="badge">{activeN}</span>}
          </Link>
        ))}
        {queue && (
          <Link to="/jobs?f=active" className="col" style={{ marginTop: 'auto', padding: 12, borderRadius: 12, background: 'var(--bg)', gap: 8, textDecoration: 'none', color: 'inherit' }}>
            <span className="small row" style={{ fontWeight: 700, gap: 6 }}>
              <span className="dot" style={{ background: activeN ? 'var(--m)' : 'var(--muted)' }} />
              {activeN ? `进行中 ${activeN} 条` : '没有在做的'}
              <span className="muted" style={{ marginLeft: 'auto', fontWeight: 600 }}>上限 {queue.limit} 条</span>
            </span>
            {[...queue.running, ...queue.queued].map(j => (
              <span key={j.id} className="col" style={{ gap: 3 }}>
                <span className="row" style={{ gap: 6 }}>
                  <span className="small grow ell sb">{j.title}</span>
                  {j.status === 'running'
                    ? <span className="small num b" style={{ color: 'var(--m-deep)' }}>{j.progress}%</span>
                    : <span className="small num muted b">#{j.pos}</span>}
                </span>
                <span style={{ fontSize: 11, lineHeight: '14px' }} className="muted">{KIND[j.kind] === '深度解析' ? '深度' : KIND[j.kind]} · {j.stage}</span>
                {j.status === 'running' && <span className="bar" style={{ height: 4 }}><i style={{ width: j.progress + '%', background: 'var(--m)' }} /></span>}
              </span>
            ))}
            <span className="small muted">今天额度：快讯 {q(queue.quota.quick)} · 深度 {q(queue.quota.deep)}</span>
          </Link>
        )}
        <div className="who" style={{ padding: '12px 8px 0', marginTop: queue ? 0 : 'auto' }}>
          <span className="av">{me?.name.slice(0, 1)}</span>
          <span className="col" style={{ gap: 0, lineHeight: '18px' }}>{me?.name}<span className="small muted">{me?.roleName} · {me?.codeMask}</span></span>
        </div>
      </aside>
      <div className="main">{children}</div>
    </div>
  );
}

/** 顶栏右边：工作区切换（只有一个工作区时只显示名字） */
export function WorkspaceSwitch() {
  const { me, setMe, refreshQueue } = useSession();
  const toast = useToast();
  const [open, setOpen] = useState(false);
  if (!me) return null;
  const many = me.workspaces.length > 1;
  return (
    <span style={{ position: 'relative' }}>
      <button className="field" style={{ fontWeight: 600, cursor: many ? 'pointer' : 'default' }} aria-label="切换工作区" aria-expanded={open}
        onClick={() => many && setOpen(!open)}>
        <span className="dot" style={{ background: 'var(--p)' }} />{me.workspace.name}{many && <Icon name="down" size={14} color="#9AA2A8" />}
      </button>
      {open && (
        <span className="card col" style={{ position: 'absolute', right: 0, top: 44, zIndex: 20, padding: 6, gap: 2, minWidth: 180, boxShadow: '0 10px 30px rgba(38,40,51,.12)' }}>
          {me.workspaces.map(w => (
            <button key={w.id} className={'nav' + (w.id === me.workspace.id ? ' on' : '')} onClick={async () => {
              setOpen(false);
              if (w.id === me.workspace.id) return;
              try { setMe(await api.switchWorkspace(w.id)); refreshQueue(); toast('已切到' + w.name); go('/news'); } catch (e: any) { toast(e.message); }
            }}><span className="chip c-p">{w.short}</span>{w.name}</button>
          ))}
        </span>
      )}
    </span>
  );
}

export function logout(setMe: (m: null) => void) {
  api.logout().catch(() => {}).finally(() => { http.setToken(null); setMe(null); go('/login'); });
}
