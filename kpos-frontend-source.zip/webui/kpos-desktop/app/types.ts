// 员工端用到的数据结构。后端按这个格式返回（JSON 字段同名）
// 注意：员工端接口不返回模型名、Token、费用、剪辑机信息，这些只在总后台

export type Role = 'intern' | 'editor' | 'chief' | 'admin';
export type WsId = string; // th / my / vn

export interface Workspace { id: WsId; name: string; short: string; site: string; signoff: string }

export interface Me {
  name: string;
  role: Role;
  roleName: string;          // 实习编辑 / 编辑 / 主编 / 管理员
  codeMask: string;          // MK02••，完整工号前端拿不到
  workspace: Workspace;
  workspaces: Workspace[];   // 能切换的工作区
}

export interface QueueItem { id: string; title: string; kind: JobKind; status: 'running' | 'queued'; progress: number; stage: string; pos?: number }
export interface Quota { used: number; limit: number | null } // null = 不限
export interface QueueInfo { running: QueueItem[]; queued: QueueItem[]; limit: number; quota: { quick: Quota; deep: Quota } }

export type NewsTab = 'recommend' | 'h24' | 'week' | 'huaren' | 'society' | 'deep' | 'latest';
export type NewsSource = 'site' | 'foreign';

export interface NewsItem {
  id: string;
  title: string;
  cat: string;
  huaren: boolean;
  medias: number;        // 几家媒体在报
  ago: string;           // 6分钟前
  rank: number;
  move: string;          // ▲1 / ▼2 / 新 / –
  images: number;        // 原图张数，少于 2 张不能剪视频
  thumb?: string | null;
}
export interface NewsPage { items: NewsItem[]; total: number; page: number; pageSize: number; updatedAt: string; nextAt: string }

export interface Article {
  id: string;
  title: string;
  cat: string;
  source: string;        // 泰国中文社 / 公众号名 / 外站域名
  sourceType: 'site' | 'wechat' | 'foreign' | 'upload' | 'smart';
  date: string;
  medias: number;
  url?: string;
  paras: string[];
  images: { id: string; src?: string | null }[];
}

export interface Story {
  headline: string;
  summary: string;
  stats: { v: string; l: string }[];
  timeline: { d: string; t: string }[];
  latest: string;
  refs: { date: string; title: string; url: string }[];
  images: { id: string; src?: string | null; from: string; picked: boolean }[];
}

export type JobKind = 'quick' | 'deep' | 'upload' | 'smart';
export type JobStatus = 'queued' | 'running' | 'review' | 'done' | 'failed' | 'cancelled';

export interface Prefs { length: number; voice: string; speed: number; voiceVol: number; music: string; musicVol: number }

export interface Scene { n: number; type: '图表卡' | '照片' | '视频片段'; sec: number; src?: string | null; changed?: boolean }

export interface Job {
  id: string;
  kind: JobKind;
  title: string;
  status: JobStatus;
  progress: number;            // 0–100
  stage: string;               // 现在在做什么，给人看的
  phase: 0 | 1 | 2;            // 0 查资料写文案 1 配音找画面 2 剪辑导出
  eta?: string;                // 大约 5 分钟后做好
  queuePos?: number;
  createdAt: string;           // 17:01
  day: 'today' | 'yesterday' | 'earlier';
  duration?: number;           // 成片秒数
  failReason?: string;
  articleId?: string;
  sourceUrl?: string;
  publishTitle?: string;
  script?: string[];
  scenes?: Scene[];
  videoUrl?: string | null;
  coverUrl?: string | null;
}

export interface DraftPara { key: string; label: string; text: string; locked?: boolean; editedBy?: string; editedAt?: string }
export interface DeepDraft {
  job: Job;
  paras: DraftPara[];
  original: DraftPara[];
  checks: { ok: boolean; text: string }[];
  timeline: { d: string; t: string; sources: number }[];
  sources: { kind: '一手' | '媒体'; title: string; at: string; url: string }[];
  share: { url: string; canEdit: boolean };
  comments: { who: string; role: string; at: string; para: string; text: string }[];
  seconds: number;
  chars: number;
  maxChars: number;
}

export interface WechatItem { id: string; title: string; account: string; at: string; images: number; chars: number; done?: string; summary: string }

export interface SmartResult {
  materials: { id: string; type: 'video' | 'image'; from: string; dur?: string; ok: boolean; reason?: string }[];
  summary: string;
  script: string;
  refs: { title: string; url: string }[];
}
