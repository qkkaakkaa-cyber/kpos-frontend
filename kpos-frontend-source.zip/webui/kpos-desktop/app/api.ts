// 员工端接口。地址都在 /api 下；演示模式走 mock.ts
import { createClient } from '../shared/http';
import { go } from '../shared/router';
import { mockApp } from './mock';
import type { Article, DeepDraft, Job, JobKind, Me, NewsPage, NewsTab, Prefs, QueueInfo, SmartResult, Story, WechatItem } from './types';

export const http = createClient({
  base: '/api',
  tokenKey: 'kpos.token',
  mock: __MOCK__ ? mockApp : undefined,
  onUnauthorized: () => { http.setToken(null); if (!location.hash.startsWith('#/login')) go('/login'); },
});

export const api = {
  login: (code: string, remember: boolean) => http.post<{ token: string; me: Me }>('/auth/login', { code, remember }),
  logout: () => http.post('/auth/logout'),
  me: () => http.get<Me>('/me'),
  switchWorkspace: (id: string) => http.post<Me>('/me/workspace', { id }),

  queue: () => http.get<QueueInfo>('/queue'),
  prefs: () => http.get<Prefs>('/prefs'),
  savePrefs: (p: Partial<Prefs>) => http.put<Prefs>('/prefs', p),

  news: (tab: NewsTab, page: number, source: string) => http.get<NewsPage>(`/news?tab=${tab}&page=${page}&source=${source}`),
  resolve: (url: string) => http.post<{ id: string }>('/news/resolve', { url }),
  article: (id: string) => http.get<Article>(`/articles/${encodeURIComponent(id)}`),
  story: (id: string) => http.get<Story>(`/articles/${encodeURIComponent(id)}/story`),

  createJob: (b: { kind: JobKind; articleId?: string; hint?: string; prefs?: Partial<Prefs> }) => http.post<Job>('/jobs', b),
  jobs: (filter: 'all' | 'active' | 'failed') => http.get<Job[]>(`/jobs?filter=${filter}`),
  job: (id: string) => http.get<Job>(`/jobs/${id}`),
  cancel: (id: string) => http.post<Job>(`/jobs/${id}/cancel`),
  retry: (id: string) => http.post<Job>(`/jobs/${id}/retry`),
  regenerate: (id: string, changes: any) => http.post<Job>(`/jobs/${id}/regenerate`, changes),

  draft: (id: string) => http.get<DeepDraft>(`/jobs/${id}/draft`),
  saveDraft: (id: string, b: { paras?: Record<string, string>; canEdit?: boolean; comment?: { para: string; text: string } }) => http.put<DeepDraft>(`/jobs/${id}/draft`, b),
  rewritePara: (id: string, key: string) => http.post<DeepDraft>(`/jobs/${id}/rewrite`, { key }),
  confirm: (id: string) => http.post<Job>(`/jobs/${id}/confirm`),

  wechatExtract: (urls: string[]) => http.post<WechatItem[]>('/wechat/extract', { urls }),
  wechatRecent: () => http.get<WechatItem[]>('/wechat/recent'),

  smartSearch: (b: { prompt: string; videos: string; clues: string; date: string }) => http.post<SmartResult>('/smart/search', b),
  smartJob: (b: { script: string; mode: string; prefs: Prefs }) => http.post<Job>('/smart/jobs', b),

  // 真后端：先 POST /api/uploads（multipart）拿到素材 id，再提交任务
  uploadJob: (b: { files: { name: string; size: number; type: string }[]; mode: 'rewrite' | 'verbatim'; text: string; title: string; date: string; signoff: boolean; origVol: number; prefs: Prefs }) => http.post<Job>('/upload/jobs', b),
};
