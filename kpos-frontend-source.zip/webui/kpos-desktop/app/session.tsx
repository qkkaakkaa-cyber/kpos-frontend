// 登录状态和队列（左下角「进行中」小卡片、提交按钮的额度都用它）
import { createContext, useCallback, useContext, useEffect, useState, type ReactNode } from 'react';
import { useInterval } from '../shared/ui';
import { api, http } from './api';
import type { Me, QueueInfo } from './types';

type Ctx = { me: Me | null; setMe: (m: Me | null) => void; queue: QueueInfo | null; refreshQueue: () => void; ready: boolean };
const C = createContext<Ctx>(null as any);
export const useSession = () => useContext(C);

export function SessionProvider({ children }: { children: ReactNode }) {
  const [me, setMe] = useState<Me | null>(null);
  const [ready, setReady] = useState(false);
  const [queue, setQueue] = useState<QueueInfo | null>(null);

  useEffect(() => {
    if (!http.getToken()) { setReady(true); return; }
    api.me().then(setMe).catch(() => http.setToken(null)).finally(() => setReady(true));
  }, []);

  const refreshQueue = useCallback(() => { if (me) api.queue().then(setQueue).catch(() => {}); }, [me]);
  useEffect(() => { refreshQueue(); }, [refreshQueue]);
  // 有在做的就 3 秒刷一次，没有就 20 秒
  const busy = !!queue && queue.running.length + queue.queued.length > 0;
  useInterval(refreshQueue, me ? (busy ? 3000 : 20000) : null);

  return <C.Provider value={{ me, setMe, queue, refreshQueue, ready }}>{children}</C.Provider>;
}
