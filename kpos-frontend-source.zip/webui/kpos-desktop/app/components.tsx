// 员工端几个页面共用的块：制作选项、文章卡片
import { useEffect, useState, type ReactNode } from 'react';
import { Icon } from '../shared/icons';
import { Seg, Thumb, useToast } from '../shared/ui';
import { api } from './api';
import type { Article, Prefs } from './types';

const VOICES = ['欣怡女声 · 新闻播报', '子豪男声 · 新闻播报', '小雅女声 · 轻松'];
const MUSIC = ['自动选 · 新闻节奏 03', '新闻节奏 01', '轻快 02', '不要背景音乐'];

/** 制作选项：改了会记住，下次默认。lengths 传 null 表示长度自动 */
export function ProdOptions({ value, onChange, lengths, lengthNote, defaultOpen = false }: {
  value: Prefs; onChange: (p: Prefs) => void; lengths: number[] | null; lengthNote?: string; defaultOpen?: boolean;
}) {
  const [open, setOpen] = useState(defaultOpen);
  const toast = useToast();
  const set = (patch: Partial<Prefs>) => {
    const next = { ...value, ...patch };
    onChange(next);
    api.savePrefs(patch).catch(() => toast('选项没存上，下次可能要重新选'));
  };
  const summary = `${value.voice.split(' · ')[0]} · ${value.music.replace('自动选 · ', '')} · 语速 ${value.speed.toFixed(1)}`;
  return (
    <div style={{ border: '1px solid var(--line)', borderRadius: 12 }}>
      <button type="button" onClick={() => setOpen(!open)} aria-expanded={open}
        style={{ width: '100%', minHeight: 48, padding: '0 14px', display: 'flex', alignItems: 'center', gap: 8, border: 0, background: 'none', textAlign: 'left' }}>
        <Icon name={open ? 'down' : 'right'} size={16} color="#6A55A0" />
        <span className="sb" style={{ color: 'var(--p-deep)' }}>制作选项</span>
        <span className="small muted ell" style={{ marginLeft: 'auto' }}>{open ? '改了会记住，下次默认' : summary}</span>
      </button>
      {open && (
        <div className="col" style={{ gap: 14, padding: '4px 14px 16px' }}>
          <Row label="视频长度">
            {lengths ? <Seg value={String(value.length)} onChange={v => set({ length: Number(v) })} options={lengths.map(l => ({ v: String(l), label: l + '秒' }))} />
              : <span className="small muted">{lengthNote || '自动'}</span>}
          </Row>
          <Row label="配音">
            <span className="row" style={{ gap: 6 }}>
              <select className="in" value={value.voice} onChange={e => set({ voice: e.target.value })} style={{ height: 34, fontSize: 13 }}>{VOICES.map(v => <option key={v}>{v}</option>)}</select>
              <button type="button" className="btn ghost sm" onClick={() => toast('试听：' + value.voice)}><Icon name="play" size={12} color="#6A55A0" />试听</button>
            </span>
          </Row>
          <Row label="语速"><Seg value={value.speed.toFixed(1)} onChange={v => set({ speed: Number(v) })} options={['0.9', '1.0', '1.1', '1.2'].map(v => ({ v, label: v }))} /></Row>
          <Row label="配音音量"><Slider v={value.voiceVol} max={150} onChange={v => set({ voiceVol: v })} /></Row>
          <Row label="背景音乐">
            <select className="in" value={value.music} onChange={e => set({ music: e.target.value })} style={{ height: 34, fontSize: 13 }}>{MUSIC.map(v => <option key={v}>{v}</option>)}</select>
          </Row>
          <Row label="音乐音量"><Slider v={value.musicVol} max={60} onChange={v => set({ musicVol: v })} disabled={value.music === '不要背景音乐'} /></Row>
        </div>
      )}
    </div>
  );
}

function Row({ label, children }: { label: string; children: ReactNode }) {
  return <div className="row wrap" style={{ justifyContent: 'space-between', gap: 8 }}><span className="small sb muted">{label}</span>{children}</div>;
}

export function Slider({ v, max, onChange, disabled }: { v: number; max: number; onChange: (v: number) => void; disabled?: boolean }) {
  const [x, setX] = useState(v);
  useEffect(() => setX(v), [v]);
  return (
    <span className="row" style={{ gap: 8 }}>
      <input type="range" min={0} max={max} step={5} value={x} disabled={disabled} aria-label="音量"
        onChange={e => setX(Number(e.target.value))} onPointerUp={() => onChange(x)} onKeyUp={() => onChange(x)} style={{ width: 140, accentColor: '#6A55A0' }} />
      <span className="small num sb" style={{ width: 38, textAlign: 'right' }}>{x}%</span>
    </span>
  );
}

/** 用记住的选项；没拿到前先用默认 */
export function usePrefs() {
  const [p, setP] = useState<Prefs>({ length: 60, voice: VOICES[0], speed: 1, voiceVol: 100, music: MUSIC[0], musicVol: 25 });
  useEffect(() => { api.prefs().then(setP).catch(() => {}); }, []);
  return [p, setP] as const;
}

/** 左边的文章：封面、标题、正文、原图 */
export function ArticleCard({ a }: { a: Article }) {
  return (
    <section className="card col" style={{ gap: 0, overflow: 'hidden', flex: '1 1 0', minWidth: 0 }}>
      <Thumb w="100%" h={220} src={a.images[0]?.src} style={{ borderRadius: 0 }} />
      <div className="col" style={{ padding: '20px 24px', gap: 12 }}>
        <span className="row wrap small muted" style={{ gap: 8 }}>
          <span className="chip c-p">{a.cat}</span>{a.source} · {a.date} · {a.medias}家媒体
          {a.url && <a href={a.url} target="_blank" rel="noreferrer noopener" className="sb">原网页 ↗</a>}
        </span>
        <h2 style={{ margin: 0, fontSize: 22, lineHeight: '31px', fontWeight: 700 }}>{a.title}</h2>
        {a.paras.map((p, i) => <p key={i} className={i > 0 ? 'muted' : ''} style={{ margin: 0, fontSize: 15, lineHeight: '27px' }}>{p}</p>)}
        <div className="col" style={{ gap: 8 }}>
          <span className="small b">文章里的原图 · {a.images.length} 张{a.images.length < 2 && <span className="chip c-w" style={{ marginLeft: 8 }}>不够 2 张，剪视频前先用「一键找图」补</span>}</span>
          <div className="row wrap" style={{ gap: 8 }}>{a.images.map((im, i) => <Thumb key={im.id} w={96} h={64} i={i} src={im.src} />)}</div>
        </div>
      </div>
    </section>
  );
}
