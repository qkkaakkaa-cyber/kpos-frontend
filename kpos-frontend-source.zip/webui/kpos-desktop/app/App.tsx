import { useEffect, type ReactNode } from 'react';
import { go, match, useRoute } from '../shared/router';
import { ToastHost } from '../shared/ui';
import { Shell } from './layout/Shell';
import { SessionProvider, useSession } from './session';
import { Login } from './pages/Login';
import { News } from './pages/News';
import { Workbench } from './pages/Workbench';
import { Progress } from './pages/Progress';
import { DeepReview } from './pages/DeepReview';
import { Jobs } from './pages/Jobs';
import { Wechat } from './pages/Wechat';
import { Smart } from './pages/Smart';
import { Upload } from './pages/Upload';
import { MePage } from './pages/MePage';

export function App() {
  return <ToastHost><SessionProvider><Routes /></SessionProvider></ToastHost>;
}

function Routes() {
  const { path, query } = useRoute();
  const { me, ready } = useSession();

  useEffect(() => {
    if (!ready) return;
    if (!me && path !== '/login') go('/login');
    if (me && (path === '/login' || path === '/')) go('/news');
  }, [ready, me, path]);

  if (!ready) return null;
  if (!me || path === '/login') return <Login />;

  let p: Record<string, string> | null;
  let page: ReactNode;
  let nav = 'news';
  if ((p = match('/work/:id', path))) page = <Workbench id={p.id} mode={query.get('mode') === 'text' ? 'text' : 'video'} kind={query.get('kind') === 'quick' ? 'quick' : 'deep'} />;
  else if ((p = match('/progress/:id', path))) { page = <Progress id={p.id} />; nav = 'jobs'; }
  else if ((p = match('/review/:id', path))) { page = <DeepReview id={p.id} />; nav = 'jobs'; }
  else if (path === '/jobs' || (p = match('/jobs/:id', path))) { page = <Jobs selected={p?.id} filter={(query.get('f') as any) || 'all'} />; nav = 'jobs'; }
  else if (path === '/wechat') { page = <Wechat />; nav = 'wechat'; }
  else if (path === '/smart') { page = <Smart />; nav = 'smart'; }
  else if (path === '/upload') { page = <Upload />; nav = 'upload'; }
  else if (path === '/me') { page = <MePage />; nav = 'me'; }
  else page = <News tab={(query.get('tab') as any) || 'recommend'} page={Number(query.get('page') || 1)} source={(query.get('src') as any) || 'site'} />;

  return <Shell nav={nav}>{page}</Shell>;
}
