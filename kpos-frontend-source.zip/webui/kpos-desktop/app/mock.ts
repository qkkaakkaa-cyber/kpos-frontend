// 演示数据：不连后端时用（npm run dev:mock）。和画布上的示例一致
// 规则照真的来：工号 7 位、输错 5 次锁定、同时最多 5 条、原图少于 2 张不能剪视频、深度要确认稿子才出片
import { ApiError, wait } from '../shared/http';
import type { Article, DeepDraft, Job, JobKind, Me, NewsItem, Prefs, QueueInfo, Story, WechatItem, Workspace } from './types';

const WS: Workspace[] = [
  { id: 'th', name: '泰国中文社', short: 'TH', site: 'thais.com', signoff: '泰国中文社{m}月{d}日报道。' },
  { id: 'my', name: '大马中文社', short: 'MY', site: 'damanews.com', signoff: '大马中文社{m}月{d}日报道。' },
  { id: 'vn', name: '越南中文社', short: 'VN', site: '[越南新闻源]', signoff: '越南中文社{m}月{d}日报道。' },
];

// 演示工号：MK0217345 编辑（泰国）、MK0102001 主编（泰国 + 大马）、MK0230888 实习编辑
const PEOPLE: Record<string, Omit<Me, 'workspace'> & { ws: string }> = {
  '0217345': { name: '林晓雯', role: 'editor', roleName: '编辑', codeMask: 'MK02••', workspaces: [WS[0]], ws: 'th' },
  '0102001': { name: '陈嘉豪', role: 'chief', roleName: '主编', codeMask: 'MK01••', workspaces: [WS[0], WS[1]], ws: 'th' },
  '0230888': { name: '张伟', role: 'intern', roleName: '实习编辑', codeMask: 'MK02••', workspaces: [WS[0]], ws: 'th' },
};

const db = {
  session: null as null | { code: string; ws: string },
  fails: 0,
  lockedUntil: 0,
  prefs: { length: 60, voice: '欣怡女声 · 新闻播报', speed: 1.0, voiceVol: 100, music: '自动选 · 新闻节奏 03', musicVol: 25 } as Prefs,
  jobs: [] as (Job & { startAt: number; total: number; confirmed?: boolean })[],
  seq: 100,
  used: { quick: 3, deep: 1 },
  wechat: [] as WechatItem[],
};

const NEWS_RAW: [string, string, boolean, number, string, string, number][] = [
  ['泰国惩教署：蓬潘达与丈夫入狱首夜无特殊待遇', '社会', false, 12, '6分钟前', '▲1', 4],
  ['玛诺车队抵达曼谷总理府，要求柴油每升下调10泰铢', '时政', false, 14, '2小时前', '▼1', 5],
  ['素察会见俄籍受害者，称将全面核查自由海滩土地买卖投诉', '社会', false, 16, '3小时前', '–', 3],
  ['曼谷警方逮捕两名中国籍电诈嫌疑人 一人涉非法入境', '社会', true, 4, '48分钟前', '新', 1],
  ['泰国气象厅更新南部强降雨预警至11月13日 北部降温3至5度', '天气', false, 14, '1小时前', '–', 6],
  ['曼谷警方增关披耶泰路应对总理府集会 封闭路段增至5处', '社会', false, 11, '1小时前', '▲2', 3],
  ['泰议长拒收废除6·6法令草案 人民党议员提三项建议', '时政', false, 9, '2小时前', '▼2', 2],
  ['泰议员指责泰自豪党阻挠国会委员会紧急审议湄赛河砷污染', '环境', false, 9, '3小时前', '▲3', 3],
  ['阿努廷假日召警察总长汇报案件，警方公告总理府周边50米禁集会', '时政', false, 7, '4小时前', '–', 2],
  ['芭提雅警方追回中国游客失窃名表，两嫌疑人供认取走', '社会', true, 5, '5小时前', '新', 0],
  ['警方持搜查令突查农普鲁豪宅，控制8名中国籍和2名缅甸籍人员', '社会', true, 8, '5小时前', '▼4', 5],
  ['那空那育府时隔17年举行洗坟仪式 收殓1411具无主遗骸', '社会', true, 6, '6小时前', '–', 6],
  ['曼谷联合行动逮捕两名涉跨国诈骗中国籍男子', '社会', true, 6, '7小时前', '▲1', 2],
  ['泰国前选美冠军夫妇被羁押！家中查获32只名牌包', '社会', false, 6, '8小时前', '▼3', 4],
  ['阿努廷否认操控上议院：只有政绩能保政府', '时政', false, 11, '9小时前', '–', 2],
  ['清迈出现今冬首场浓雾 素贴山观景台气温降至 12°C', '天气', false, 6, '10小时前', '▲2', 6],
  ['曼谷 BTS 金线明年起票价统一 15 铢', '交通', false, 5, '11小时前', '–', 3],
  ['泰国内阁批准“泰国人游泰国”第二期补贴', '经济', false, 7, '11小时前', '▼1', 4],
  ['素万那普机场新航站楼本周启用 中国航线优先搬入', '交通', true, 3, '12小时前', '–', 3],
  ['普吉岛下周起游客税正式征收', '旅游', false, 3, '13小时前', '新', 1],
  ['泰国央行维持利率不变 泰铢小幅走强', '经济', false, 5, '14小时前', '–', 3],
  ['清莱府发布湄公河水位提醒 沿岸码头暂停夜间船班', '社会', false, 4, '15小时前', '▼1', 2],
];
const NEWS: NewsItem[] = NEWS_RAW.map(([title, cat, huaren, medias, ago, move, images], i) => ({ id: 'n' + (i + 1), title, cat, huaren, medias, ago, move, images, rank: i + 1, thumb: null }));

function article(id: string): Article {
  const n = NEWS.find(x => x.id === id);
  const w = db.wechat.find(x => x.id === id);
  if (id === 'n8' || !n && !w) {
    return {
      id, title: n?.title || '泰议员指责泰自豪党阻挠国会委员会紧急审议湄赛河砷污染', cat: '环境', source: '泰国中文社', sourceType: 'site', date: '11月8日', medias: 9,
      url: 'https://thais.com/news-303361/',
      paras: [
        '泰国国会自然灾害与公共灾害防治委员会主席、清迈府人民党议员帕塔蓬·利拉帕 11 月 8 日在脸书发文称，该委员会无法将湄赛河砷污染问题列为紧急议程。',
        '他表示，众议院议长索蓬要求此类动议必须事先获得委员会决议，导致紧急事项至少需等待两周……',
        '[正文其余段落]',
      ],
      images: [{ id: 'i1' }, { id: 'i2' }, { id: 'i3' }],
    };
  }
  if (w) return { id, title: w.title, cat: '公众号', source: w.account, sourceType: 'wechat', date: w.at, medias: 1, url: 'https://mp.weixin.qq.com/s/[文章链接]', paras: [w.summary, '[正文其余段落]'], images: Array.from({ length: w.images }, (_, i) => ({ id: 'w' + i })) };
  return { id, title: n!.title, cat: n!.cat, source: '泰国中文社', sourceType: 'site', date: '11月10日', medias: n!.medias, url: 'https://thais.com/news-' + (303300 + n!.rank) + '/', paras: ['[正文第一段]', '[正文其余段落]'], images: Array.from({ length: n!.images }, (_, i) => ({ id: 'i' + i })) };
}

const STORY: Story = {
  headline: '湄赛河砷超标，国会紧急审议被卡住',
  summary: '清莱湄赛河变浑后，多个监测点检出砷超标，学者怀疑与缅甸上游开矿有关。议员想让委员会紧急审议，却卡在新的委员会规则上。',
  stats: [{ v: '0.25', l: '实测砷 毫克/升' }, { v: '25倍', l: '标准 ≤0.01' }, { v: '20家', l: '获准矿企' }],
  timeline: [
    { d: '10月25日', t: '缅甸大其力至少20家矿企获准开采，铅锰矿石经泰北口岸入境' },
    { d: '10月26日', t: '湄赛河变红浊，学者怀疑与上游采矿有关' },
    { d: '10月30日', t: '3个监测点砷超标；污染控制厅称泰国境内无跨境污染源' },
    { d: '11月1日', t: '污染控制厅通报自来水局加强监测' },
    { d: '11月8日', t: '议员称委员会无法紧急审议砷污染，指责新规则阻挠' },
  ],
  latest: '[从最新一篇报道里整理的最新进展，一两句话]',
  refs: [{ date: '10-30', title: '[之前的相关报道标题]', url: '#' }, { date: '10-26', title: '[之前的相关报道标题]', url: '#' }],
  images: [
    { id: 's1', from: '原文配图', picked: true }, { id: 's2', from: 'Thairath', picked: true }, { id: 's3', from: 'Matichon', picked: false },
    { id: 's4', from: 'Facebook', picked: true }, { id: 's5', from: '旧报道', picked: false }, { id: 's6', from: 'Thai PBS', picked: false },
  ],
};

/* ---------- 任务进度：按时间推进 ---------- */
const PHASES = ['查资料、写文案', '配音、找画面', '剪辑、导出'];
const STAGES = [['读取原文', '查来龙去脉', '写口播'], ['配音', '找现场视频', '找配图'], ['剪辑画面', '加字幕', '导出成片']];
const RUN_AT_ONCE = 2;

function now() { return Date.now(); }
function hhmm(t = new Date()) { return String(t.getHours()).padStart(2, '0') + ':' + String(t.getMinutes()).padStart(2, '0'); }

function tick() {
  const t = now();
  // 进行中的往前走
  for (const j of db.jobs) {
    if (j.status !== 'running') continue;
    let p = Math.min(100, Math.round(((t - j.startAt) / j.total) * 100));
    if (j.kind === 'deep' && !j.confirmed && p >= 30) { p = 30; j.status = 'review'; j.stage = '稿子写好了，等你确认'; }
    j.progress = p;
    if (j.status === 'running') {
      j.phase = p < 30 ? 0 : p < 75 ? 1 : 2;
      const [a, b] = [[0, 30], [30, 75], [75, 100]][j.phase];
      const st = STAGES[j.phase];
      j.stage = st[Math.min(st.length - 1, Math.floor(((p - a) / (b - a)) * st.length))];
      const left = Math.max(1, Math.round(((100 - p) / 100) * (j.total / 1000) / 60 * 3));
      j.eta = `大约 ${left} 分钟后做好`;
      if (p >= 100) Object.assign(j, { status: 'done', progress: 100, stage: '做好了', duration: j.kind === 'deep' ? 158 : 54, eta: undefined });
    }
  }
  // 排队的补上
  let running = db.jobs.filter(j => j.status === 'running').length;
  for (const j of db.jobs.filter(x => x.status === 'queued').sort((a, b) => a.startAt - b.startAt)) {
    if (running >= RUN_AT_ONCE) break;
    j.status = 'running'; j.startAt = t; running++;
  }
  db.jobs.filter(j => j.status === 'queued').sort((a, b) => a.startAt - b.startAt).forEach((j, i) => {
    j.queuePos = i + 1; j.stage = `排第 ${i + 1} 位`; j.eta = `约 ${i * 2 + 1} 分钟后开始`;
  });
}

function seed() {
  if (db.jobs.length) return;
  const base = now();
  const mk = (o: Partial<Job> & { title: string; kind: JobKind }, startAgo: number, total: number): any => ({
    id: 'j' + (db.seq++), status: 'running', progress: 0, stage: '', phase: 0, createdAt: hhmm(new Date(base - startAgo)), day: 'today',
    startAt: base - startAgo, total, articleId: 'n15', ...o,
  });
  db.jobs.push(
    mk({ title: '阿努廷否认操控上议院：只有政绩能保政府', kind: 'deep', confirmed: true } as any, 50_000, 110_000),
    mk({ title: '玛诺车队抵达曼谷总理府，要求柴油每升下调10泰铢', kind: 'quick', articleId: 'n2' }, 6_000, 60_000),
    { ...mk({ title: '泰铢兑人民币跌破 4.4 意味着什么', kind: 'deep' }, -1, 120_000), status: 'queued', startAt: base + 1 },
    { ...mk({ title: '素察会见俄籍受害者，称将全面核查自由海滩土地买卖投诉', kind: 'quick', articleId: 'n3' }, -2, 60_000), status: 'queued', startAt: base + 2 },
    mk({ title: '泰国前选美冠军夫妇被羁押！家中查获32只名牌包', kind: 'deep', articleId: 'n14', confirmed: true } as any, 9 * 3600_000, 1000),
    mk({ title: '曼谷警方逮捕两名中国籍电诈嫌疑人 一人涉非法入境', kind: 'quick', articleId: 'n4' }, 9.5 * 3600_000, 1000),
    { ...mk({ title: '芭提雅海滩夜市现场（上传 3 段）', kind: 'upload', day: 'yesterday', failReason: '素材太短，至少要 20 秒' }, 20 * 3600_000, 1000), status: 'failed', createdAt: '22:40' },
    { ...mk({ title: '泰国惩教署：蓬潘达与丈夫入狱首夜无特殊待遇', kind: 'deep', day: 'yesterday', confirmed: true } as any, 23 * 3600_000, 1000), createdAt: '18:02' },
  );
  for (const j of db.jobs) {
    if (j.status === 'running' && j.total === 1000) Object.assign(j, { status: 'done', progress: 100, stage: '做好了', duration: j.kind === 'deep' ? 161 : 58 });
    j.publishTitle = j.title.replace(/！/, '，') + ' #泰国新闻 #泰国中文社';
    j.script = ['泰国总理阿努廷这两天被问得最多的一个问题：政府到底有没有在操控上议院？', '[背景段：从查到的报道里整理的来龙去脉]', '[最新进展]', '泰国中文社11月10日报道。'];
    j.scenes = [
      { n: 1, type: '图表卡', sec: 10 }, { n: 2, type: '照片', sec: 42 }, { n: 3, type: '照片', sec: 31 }, { n: 4, type: '视频片段', sec: 24 },
      { n: 5, type: '照片', sec: 21 }, { n: 6, type: '图表卡', sec: 15 }, { n: 7, type: '照片', sec: 18 },
    ];
  }
  db.wechat = [
    { id: 'w1', title: '[公众号文章标题]', account: '[公众号名称]', at: '今天 15:20', images: 4, chars: 1860, done: '已做快讯', summary: '[正文前两行摘要……]' },
    { id: 'w2', title: '[公众号文章标题]', account: '[公众号名称]', at: '今天 11:05', images: 3, chars: 1420, summary: '[正文前两行摘要……]' },
    { id: 'w3', title: '[公众号文章标题]', account: '[公众号名称]', at: '昨天 21:40', images: 1, chars: 980, summary: '[正文前两行摘要……]' },
    { id: 'w4', title: '[公众号文章标题]', account: '[公众号名称]', at: '昨天 18:12', images: 6, chars: 2310, done: '已做深度', summary: '[正文前两行摘要……]' },
  ];
}

function me(): Me {
  if (!db.session) throw new ApiError(401, '请先登录');
  const p = PEOPLE[db.session.code];
  const { ws, ...rest } = p;
  return { ...rest, workspace: WS.find(w => w.id === db.session!.ws) || WS[0] };
}

function limits() {
  const r = me().role;
  return r === 'chief' || r === 'admin' ? { quick: null, deep: null } : r === 'intern' ? { quick: 5, deep: 0 } : { quick: 10, deep: 3 };
}

function publicJob(j: any): Job {
  const { startAt, total, confirmed, ...rest } = j;
  return rest;
}

function active() { return db.jobs.filter(j => j.status === 'running' || j.status === 'queued' || j.status === 'review'); }

function createJob(kind: JobKind, title: string, extra: Partial<Job> = {}) {
  const lim = limits();
  if (active().length >= 5) throw new ApiError(429, '同时最多 5 条（剪辑中 + 排队），等前面做完一条再提交');
  if (kind === 'deep' || kind === 'quick') {
    const l = lim[kind];
    if (l !== null && db.used[kind] >= l) throw new ApiError(429, l === 0 ? '你的角色不能做深度解析，找主编开' : `今天的${kind === 'deep' ? '深度解析' : '快讯'}额度用完了`);
    db.used[kind]++;
  }
  const j: any = {
    id: 'j' + (db.seq++), kind, title, status: 'queued', progress: 0, stage: '排队', phase: 0, createdAt: hhmm(), day: 'today',
    startAt: now(), total: kind === 'deep' ? 120_000 : 60_000, ...extra,
  };
  j.publishTitle = title + ' #泰国新闻 #泰国中文社';
  j.script = ['[口播第一段]', '[口播其余段落]', '泰国中文社11月10日报道。'];
  j.scenes = [{ n: 1, type: '照片', sec: 12 }, { n: 2, type: '照片', sec: 15 }, { n: 3, type: '视频片段', sec: 18 }, { n: 4, type: '图表卡', sec: 9 }];
  db.jobs.unshift(j);
  tick();
  return publicJob(j);
}

function queue(): QueueInfo {
  tick();
  const lim = limits();
  const run = db.jobs.filter(j => j.status === 'running' || j.status === 'review');
  const q = db.jobs.filter(j => j.status === 'queued').sort((a, b) => a.startAt - b.startAt);
  return {
    running: run.map(j => ({ id: j.id, title: j.title, kind: j.kind, status: 'running', progress: j.progress, stage: j.status === 'review' ? '等你确认稿子' : '剪辑中' })),
    queued: q.map(j => ({ id: j.id, title: j.title, kind: j.kind, status: 'queued', progress: 0, stage: `排第 ${j.queuePos} 位`, pos: j.queuePos })),
    limit: 5,
    quota: { quick: { used: db.used.quick, limit: lim.quick }, deep: { used: db.used.deep, limit: lim.deep } },
  };
}

function draft(j: any): DeepDraft {
  if (!j.draft) {
    const paras = [
      { key: 'lead', label: '导语', text: '[导语：一句话说清楚「' + j.title + '」]' },
      { key: 'bg', label: '背景', text: '[背景段：按右边时间线整理的来龙去脉，只写有来源的事实]' },
      { key: 'body', label: '经过', text: '[经过段：各方说法，每句都带上是谁说的]' },
      { key: 'latest', label: '最新进展', text: '[最新进展：已经发生的具体下一步，保留"拟""待协商"等状态]' },
      { key: 'sign', label: '片尾署名', text: '泰国中文社11月10日报道。', locked: true },
    ];
    j.draft = {
      paras, original: paras.map(p => ({ ...p })),
      comments: [{ who: '陈嘉豪', role: '主编', at: '18:50', para: '经过段', text: '[留言内容]' }],
      share: { url: 'https://kpos.com/r/' + j.id.slice(1).padStart(6, '0'), canEdit: true },
    };
  }
  const chars = j.draft.paras.reduce((s: number, p: any) => s + p.text.length, 0);
  return {
    job: publicJob(j), paras: j.draft.paras, original: j.draft.original, comments: j.draft.comments, share: j.draft.share,
    checks: [{ ok: chars <= 900, text: chars <= 900 ? '字数合格' : '字数超了' }, { ok: true, text: '没有第三方媒体署名' }, { ok: true, text: '结尾有具体进展' }, { ok: false, text: '1 处待核：经过段的数字和来源对不上' }],
    timeline: [{ d: '[日期]', t: '[事件一句话]', sources: 2 }, { d: '[日期]', t: '[事件一句话]', sources: 1 }, { d: '[日期]', t: '[事件一句话]', sources: 3 }],
    sources: [
      { kind: '一手', title: '[政府 / 警方通报名称]', at: '[发布时间]', url: '#' },
      { kind: '一手', title: '[当事人公开发言]', at: '[发布时间]', url: '#' },
      { kind: '媒体', title: '[媒体报道标题]', at: '只当线索，不写进口播', url: '#' },
    ],
    seconds: Math.round(chars / 3.9), chars, maxChars: 900,
  };
}

function job(id: string) {
  tick();
  const j = db.jobs.find(x => x.id === id);
  if (!j) throw new ApiError(404, '找不到这条记录，可能已经过了 30 天被清理');
  return j;
}

/* ---------- 路由 ---------- */
export async function mockApp(method: string, path: string, body: any = {}, token = ''): Promise<any> {
  await wait(path.startsWith('/queue') ? 60 : 200);
  seed();
  const [p, qs = ''] = path.split('?');
  const q = new URLSearchParams(qs);
  const m = (re: RegExp) => p.match(re);
  let r: RegExpMatchArray | null;

  if (method === 'POST' && p === '/auth/login') {
    if (db.lockedUntil > now()) throw new ApiError(423, `这台电脑已锁定，${Math.ceil((db.lockedUntil - now()) / 60000)} 分钟后再试`);
    const code = String(body.code || '').replace(/\D/g, '');
    if (code.length !== 7) throw new ApiError(422, '工号是 MK 后面 7 位数字');
    if (!PEOPLE[code]) {
      db.fails++;
      if (db.fails >= 5) { db.lockedUntil = now() + 15 * 60_000; db.fails = 0; throw new ApiError(423, '连续输错 5 次，这台电脑锁定 15 分钟，已通知管理员'); }
      throw new ApiError(401, `工号不对，还能试 ${5 - db.fails} 次`);
    }
    db.fails = 0;
    db.session = { code, ws: PEOPLE[code].ws };
    return { token: 'demo-' + code, me: me() };
  }
  if (method === 'POST' && p === '/auth/logout') { db.session = null; return { ok: true }; }
  const restoredCode = /^demo-([0-9]{7})$/.exec(token)?.[1];
  if (!db.session && restoredCode && PEOPLE[restoredCode]) {
    db.session = { code: restoredCode, ws: PEOPLE[restoredCode].ws };
  }
  if (p === '/me') return me();
  if (method === 'POST' && p === '/me/workspace') {
    const ws = me().workspaces.find(w => w.id === body.id);
    if (!ws) throw new ApiError(403, '没有这个工作区的权限');
    db.session!.ws = ws.id; return me();
  }
  me(); // 下面都要登录

  if (p === '/queue') return queue();
  if (p === '/prefs') { if (method === 'PUT') Object.assign(db.prefs, body); return db.prefs; }

  if (p === '/news') {
    const tab = q.get('tab') || 'recommend', page = Number(q.get('page') || 1), size = 20;
    let list = NEWS.slice();
    if (tab === 'huaren') list = list.filter(x => x.huaren);
    if (tab === 'society') list = list.filter(x => x.cat === '社会');
    if (tab === 'deep') list = list.filter(x => x.medias >= 9);
    if (tab === 'latest') list = list.slice().reverse();
    if (tab === 'week') list = list.concat(NEWS.slice(0, 14).map(x => ({ ...x, id: x.id + 'w' }))).map((x, i) => ({ ...x, rank: i + 1 }));
    return { items: list.slice((page - 1) * size, page * size).map((x, i) => ({ ...x, rank: (page - 1) * size + i + 1 })), total: list.length, page, pageSize: size, updatedAt: '17:45', nextAt: '18:00' };
  }
  if (method === 'POST' && p === '/news/resolve') {
    const url = String(body.url || '').trim();
    if (!/^https?:\/\//.test(url)) throw new ApiError(422, '请贴完整链接，要以 http 开头');
    if (/mp\.weixin\.qq\.com/.test(url)) throw new ApiError(422, '公众号文章请到「公众号剪辑」里贴');
    return { id: 'n8' };
  }
  if ((r = m(/^\/articles\/([^/]+)$/))) return article(r[1]);
  if ((r = m(/^\/articles\/([^/]+)\/story$/))) return STORY;

  if (method === 'POST' && p === '/jobs') {
    const a = body.articleId ? article(body.articleId) : null;
    if (a && a.images.length < 2 && body.kind !== 'smart' && body.kind !== 'upload') throw new ApiError(422, '原图不够 2 张，先用「一键找图」补图');
    const title = body.title || a?.title || '[自动起的标题]';
    return createJob(body.kind, title, { articleId: body.articleId });
  }
  if (p === '/jobs') {
    tick();
    const f = q.get('filter') || 'all';
    let list = db.jobs;
    if (f === 'active') list = list.filter(j => ['running', 'queued', 'review'].includes(j.status));
    if (f === 'failed') list = list.filter(j => j.status === 'failed' || j.status === 'cancelled');
    return list.map(publicJob);
  }
  if ((r = m(/^\/jobs\/([^/]+)$/))) return publicJob(job(r[1]));
  if (method === 'POST' && (r = m(/^\/jobs\/([^/]+)\/cancel$/))) {
    const j = job(r[1]); if (!['running', 'queued', 'review'].includes(j.status)) throw new ApiError(409, '这条已经做完了');
    Object.assign(j, { status: 'cancelled', stage: '你终止了', failReason: '你在第 ' + (j.phase + 1) + ' 步终止' }); tick(); return publicJob(j);
  }
  if (method === 'POST' && (r = m(/^\/jobs\/([^/]+)\/retry$/))) {
    const j = job(r[1]); return createJob(j.kind, j.title, { articleId: j.articleId });
  }
  if ((r = m(/^\/jobs\/([^/]+)\/draft$/))) {
    const j: any = job(r[1]);
    if (j.kind !== 'deep') throw new ApiError(409, '只有深度解析有审阅稿');
    if (method === 'PUT') {
      if (j.confirmed && j.status !== 'review') throw new ApiError(409, '已经确认出片，稿子锁定了；出片后在「生成记录」里改文案');
      const d = draft(j);
      for (const para of d.paras) {
        const nt = body.paras?.[para.key];
        if (nt !== undefined && !para.locked && nt !== para.text) Object.assign(para, { text: nt, editedBy: me().name, editedAt: hhmm() });
      }
      if (typeof body.canEdit === 'boolean') j.draft.share.canEdit = body.canEdit;
      if (body.comment) j.draft.comments.push({ who: me().name, role: me().roleName, at: hhmm(), para: body.comment.para || '全文', text: body.comment.text });
    }
    return draft(j);
  }
  if (method === 'POST' && (r = m(/^\/jobs\/([^/]+)\/confirm$/))) {
    const j: any = job(r[1]);
    j.confirmed = true;
    if (j.status === 'review') { j.status = 'running'; j.startAt = now() - j.total * 0.3; }
    tick(); return publicJob(j);
  }
  if (method === 'POST' && (r = m(/^\/jobs\/([^/]+)\/rewrite$/))) {
    const j: any = job(r[1]); const d = draft(j); const para = d.paras.find(x => x.key === body.key);
    if (para && !para.locked) Object.assign(para, { text: '[重写后的' + para.label + '段]', editedBy: '自动重写', editedAt: hhmm() });
    return draft(j);
  }
  if (method === 'POST' && (r = m(/^\/jobs\/([^/]+)\/regenerate$/))) {
    const j = job(r[1]);
    return createJob(j.kind, j.title, { articleId: j.articleId });
  }

  if (method === 'POST' && p === '/wechat/extract') {
    const urls: string[] = (body.urls || []).filter((u: string) => u.trim());
    if (!urls.length) throw new ApiError(422, '先贴公众号文章链接');
    if (urls.length > 5) throw new ApiError(422, '一次最多 5 条');
    if (urls.some(u => !/mp\.weixin\.qq\.com\/s/.test(u))) throw new ApiError(422, '只能贴 mp.weixin.qq.com/s/ 开头的公众号文章链接');
    const items = urls.map((u, i) => ({ id: 'w' + (db.seq++), title: '[公众号文章标题]', account: '[公众号名称]', at: '刚刚', images: 5 - i, chars: 1860, summary: '[正文前两行摘要……]' }));
    db.wechat.unshift(...items);
    return items;
  }
  if (p === '/wechat/recent') return db.wechat;

  if (method === 'POST' && p === '/smart/search') {
    if (!String(body.prompt || '').trim() && !String(body.videos || '').trim()) throw new ApiError(422, '写一句事件提示，或者贴视频链接');
    await wait(900);
    return {
      materials: [
        { id: 'm1', type: 'video', from: 'Facebook 帖子', dur: '0:42', ok: true }, { id: 'm2', type: 'video', from: 'TikTok', dur: '0:28', ok: true },
        { id: 'm3', type: 'video', from: '泰国电视台', dur: '1:05', ok: true }, { id: 'm4', type: 'image', from: '泰国媒体', ok: true },
        { id: 'm5', type: 'image', from: '泰国媒体', ok: true }, { id: 'm6', type: 'image', from: '广告', ok: false, reason: '广告' },
      ],
      summary: '3 条视频 · 2 张图片可用；排除广告、无关 1 条，打不开或日期不符 2 条',
      script: '[系统查完资料后整理的口播文案，可以直接改]',
      refs: [{ title: '[查到的报道标题]', url: '#' }, { title: '[查到的报道标题]', url: '#' }],
    };
  }
  if (method === 'POST' && p === '/smart/jobs') return createJob('smart', body.title || '[智能剪辑 · 自动起的标题]');
  if (method === 'POST' && p === '/upload/jobs') {
    if (!body.files?.length) throw new ApiError(422, '先选素材');
    const len = String(body.text || '').trim().length;
    if (body.mode === 'rewrite' && (len < 40 || len > 6000)) throw new ApiError(422, '按模板改写要 40–6000 字的资料');
    if (body.mode === 'verbatim' && (len < 10 || len > 800)) throw new ApiError(422, '原样配音的文案要 10–800 字');
    return createJob('upload', body.title || '[手动上传 · 自动起的标题]');
  }
  throw new ApiError(404, '没有这个接口：' + method + ' ' + p);
}
