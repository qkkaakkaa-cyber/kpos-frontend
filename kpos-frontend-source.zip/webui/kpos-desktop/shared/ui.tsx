// 共用小组件和 hooks
import { createContext, useCallback, useContext, useEffect, useRef, useState, type ReactNode, type CSSProperties } from 'react';
import { Icon } from './icons';

/* ---------- 异步加载 ---------- */
export function useAsync<T>(fn: () => Promise<T>, deps: any[] = []) {
  const [state, set] = useState<{ data?: T; error?: Error; loading: boolean }>({ loading: true });
  const seq = useRef(0);
  const run = useCallback(() => {
    const n = ++seq.current;
    set(s => ({ ...s, loading: true, error: undefined }));
    fn().then(d => { if (n === seq.current) set({ data: d, loading: false }); })
      .catch(e => { if (n === seq.current) set({ error: e, loading: false }); });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, deps);
  useEffect(() => { run(); }, [run]);
  return { ...state, reload: run, setData: (d: T) => set(s => ({ ...s, data: d })) };
}

/** 每隔 ms 刷新一次（页面不可见时暂停） */
export function useInterval(cb: () => void, ms: number | null) {
  const ref = useRef(cb); ref.current = cb;
  useEffect(() => {
    if (ms == null) return;
    const id = setInterval(() => { if (!document.hidden) ref.current(); }, ms);
    return () => clearInterval(id);
  }, [ms]);
}

/* ---------- 提示 ---------- */
const ToastCtx = createContext<(msg: string) => void>(() => {});
export function ToastHost({ children }: { children: ReactNode }) {
  const [msg, setMsg] = useState('');
  const timer = useRef<any>();
  const show = useCallback((m: string) => {
    setMsg(m); clearTimeout(timer.current); timer.current = setTimeout(() => setMsg(''), 2400);
  }, []);
  return <ToastCtx.Provider value={show}>{children}{msg && <div className="toast" role="status">{msg}</div>}</ToastCtx.Provider>;
}
export const useToast = () => useContext(ToastCtx);

/** 复制文字。剪贴板不让用时返回 false，调用的地方提示手动复制 */
export async function copyText(t: string) {
  try { await navigator.clipboard.writeText(t); return true; } catch { return false; }
}

/* ---------- 小组件 ---------- */
export function Seg<T extends string>({ value, options, onChange }: { value: T; options: { v: T; label: ReactNode }[]; onChange: (v: T) => void }) {
  return (
    <span className="seg" role="radiogroup">
      {options.map(o => <button key={o.v} type="button" role="radio" aria-checked={o.v === value} className={o.v === value ? 'on' : ''} onClick={() => onChange(o.v)}>{o.label}</button>)}
    </span>
  );
}

export function Tabs<T extends string>({ value, options, onChange, right }: { value: T; options: { v: T; label: ReactNode }[]; onChange: (v: T) => void; right?: ReactNode }) {
  return (
    <div className="tabs" role="tablist">
      {options.map(o => <button key={o.v} type="button" role="tab" aria-selected={o.v === value} className={o.v === value ? 'on' : ''} onClick={() => onChange(o.v)}>{o.label}</button>)}
      {right && <span className="small muted" style={{ marginLeft: 'auto', alignSelf: 'center', whiteSpace: 'nowrap' }}>{right}</span>}
    </div>
  );
}

export function Toggle({ on, onChange, label }: { on: boolean; onChange: (v: boolean) => void; label: string }) {
  return <button type="button" className={'tog' + (on ? ' on' : '')} aria-pressed={on} aria-label={label} onClick={() => onChange(!on)}><span /></button>;
}

const STATUS: Record<string, [string, string]> = {
  running: ['剪辑中', 'c-p'], queued: ['排队', 'c-g'], review: ['等你确认', 'c-y'], done: ['做好了', 'c-m'],
  failed: ['失败', 'c-r'], cancelled: ['已终止', 'c-g'], retrying: ['失败 · 重试中', 'c-w'],
};
export function StatusChip({ status, text }: { status: string; text?: string }) {
  const [t, c] = STATUS[status] || [status, 'c-g'];
  return <span className={'chip ' + c}>{status === 'done' && <Icon name="check" size={10} sw={3} />}{text || t}</span>;
}

export const KIND: Record<string, string> = { quick: '快讯', deep: '深度解析', upload: '上传素材', smart: '智能剪辑', wechat: '公众号' };

/** 图片：有地址就显示，没有就显示色块（演示数据没有真图） */
export function Thumb({ src, w, h, i = 0, label, style }: { src?: string | null; w: number | string; h: number | string; i?: number; label?: ReactNode; style?: CSSProperties }) {
  return (
    <span className={'thumb ph' + (i % 4)} style={{ width: w, height: h, ...style }}>
      {src ? <img src={src} alt="" loading="lazy" /> : <Icon name="image" size={18} />}
      {label}
    </span>
  );
}

export function Modal({ title, children, onClose, actions }: { title: string; children: ReactNode; onClose: () => void; actions?: ReactNode }) {
  useEffect(() => {
    const k = (e: KeyboardEvent) => { if (e.key === 'Escape') onClose(); };
    window.addEventListener('keydown', k); return () => window.removeEventListener('keydown', k);
  }, [onClose]);
  return (
    <div className="modal-bg" onClick={onClose}>
      <div className="modal" role="dialog" aria-modal="true" aria-label={title} onClick={e => e.stopPropagation()}>
        <span className="h2">{title}</span>
        {children}
        {actions && <div className="row" style={{ justifyContent: 'flex-end' }}>{actions}</div>}
      </div>
    </div>
  );
}

export function Loading({ rows = 4 }: { rows?: number }) {
  return <div className="col" style={{ gap: 10, padding: 16 }}>{Array.from({ length: rows }, (_, i) => <div key={i} className="skel" style={{ height: 44 }} />)}</div>;
}

export function ErrorBox({ error, retry }: { error: Error; retry?: () => void }) {
  return <div className="note row" style={{ justifyContent: 'space-between' }}><span>{error.message || '出错了'}</span>{retry && <button className="btn sm warn" onClick={retry}>再试一次</button>}</div>;
}

export function Empty({ children }: { children: ReactNode }) { return <div className="empty">{children}</div>; }

/** 新开的标签页打开外部链接 */
export function Ext({ href, children, className }: { href: string; children: ReactNode; className?: string }) {
  return <a href={href} target="_blank" rel="noreferrer noopener" className={className}>{children}</a>;
}

export function fmtNum(n: number) { return n.toLocaleString('en-US'); }
export function fmtK(n: number) { return n >= 1e6 ? (n / 1e6).toFixed(2) + 'M' : n >= 1e3 ? Math.round(n / 1e3) + 'K' : String(n); }
export function fmtDur(sec: number) { const m = Math.floor(sec / 60), s = sec % 60; return m ? `${m}分${String(s).padStart(2, '0')}秒` : `${s}秒`; }
export function fmtClock(sec: number) { return Math.floor(sec / 60) + ':' + String(sec % 60).padStart(2, '0'); }
