// 请求后端。演示模式（__MOCK__）下交给 mock 处理函数，不发网络请求
export class ApiError extends Error {
  constructor(public status: number, message: string, public data?: any) { super(message); }
}

export type MockHandler = (method: string, path: string, body: any, token: string) => Promise<any>;

export function createClient(opts: { base: string; tokenKey: string; mock?: MockHandler; onUnauthorized?: () => void }) {
  const tokenKey = opts.mock ? `${opts.tokenKey}.demo` : opts.tokenKey;
  const expiryKey = `${tokenKey}.expiry`;

  function getToken(): string {
    try {
      const sessionToken = sessionStorage.getItem(tokenKey);
      if (sessionToken) return sessionToken;
      const expiry = localStorage.getItem(expiryKey);
      if (expiry && Number(expiry) <= Date.now()) {
        setToken(null);
        return '';
      }
      return localStorage.getItem(tokenKey) || '';
    } catch { return ''; }
  }

  function setToken(token: string | null, remember = true, days?: number) {
    try {
      sessionStorage.removeItem(tokenKey);
      localStorage.removeItem(tokenKey);
      localStorage.removeItem(expiryKey);
      if (!token) return;
      if (!remember) {
        sessionStorage.setItem(tokenKey, token);
        return;
      }
      if (days) localStorage.setItem(expiryKey, String(Date.now() + days * 86_400_000));
      localStorage.setItem(tokenKey, token);
    } catch { /* 私密窗口等 */ }
  }

  async function request<T = any>(method: string, path: string, body?: any): Promise<T> {
    if (opts.mock) {
      try { return await opts.mock(method, path, body, getToken()); }
      catch (e) { if (e instanceof ApiError && e.status === 401) opts.onUnauthorized?.(); throw e; }
    }
    const isForm = typeof FormData !== 'undefined' && body instanceof FormData;
    const res = await fetch(opts.base + path, {
      method,
      headers: { Accept: 'application/json', ...(isForm || body === undefined ? {} : { 'Content-Type': 'application/json' }), ...(getToken() ? { Authorization: 'Bearer ' + getToken() } : {}) },
      body: body === undefined ? undefined : isForm ? body : JSON.stringify(body),
      credentials: 'same-origin',
    });
    const text = await res.text();
    let data: any = null;
    try { data = text ? JSON.parse(text) : null; } catch { data = { message: text }; }
    if (!res.ok) {
      if (res.status === 401) opts.onUnauthorized?.();
      throw new ApiError(res.status, (data && (data.message || data.error)) || '网络不太好，再试一次', data);
    }
    return data as T;
  }

  return {
    getToken, setToken,
    get: <T = any>(p: string) => request<T>('GET', p),
    post: <T = any>(p: string, b?: any) => request<T>('POST', p, b ?? {}),
    put: <T = any>(p: string, b?: any) => request<T>('PUT', p, b ?? {}),
    del: <T = any>(p: string) => request<T>('DELETE', p),
  };
}

/** 演示用：等一会儿再返回，像真的网络 */
export const wait = (ms = 220) => new Promise(r => setTimeout(r, ms));
