// 很小的 hash 路由：#/path?x=1。两个后台都用，不引第三方库
import { useEffect, useState, type ReactNode, type MouseEvent, type CSSProperties } from 'react';

export type Route = { path: string; query: URLSearchParams };

function read(): Route {
  const raw = location.hash.replace(/^#/, '') || '/';
  const [path, qs = ''] = raw.split('?');
  return { path: path || '/', query: new URLSearchParams(qs) };
}

export function useRoute(): Route {
  const [r, setR] = useState(read);
  useEffect(() => {
    const on = () => { setR(read()); window.scrollTo(0, 0); };
    window.addEventListener('hashchange', on);
    return () => window.removeEventListener('hashchange', on);
  }, []);
  return r;
}

export function go(to: string) {
  location.hash = to.startsWith('#') ? to : '#' + to;
}

/** 把 /jobs/:id 这种模式和路径对上，返回参数 */
export function match(pattern: string, path: string): Record<string, string> | null {
  const a = pattern.split('/').filter(Boolean), b = path.split('/').filter(Boolean);
  if (a.length !== b.length) return null;
  const out: Record<string, string> = {};
  for (let i = 0; i < a.length; i++) {
    if (a[i].startsWith(':')) out[a[i].slice(1)] = decodeURIComponent(b[i]);
    else if (a[i] !== b[i]) return null;
  }
  return out;
}

export function Link({ to, className, style, children, title }: { to: string; className?: string; style?: CSSProperties; children: ReactNode; title?: string }) {
  const href = '#' + to;
  return (
    <a href={href} className={className} style={style} title={title}
      onClick={(e: MouseEvent) => { if (e.metaKey || e.ctrlKey) return; e.preventDefault(); go(to); }}>
      {children}
    </a>
  );
}
