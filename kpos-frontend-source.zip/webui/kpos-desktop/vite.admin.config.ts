import { defineConfig, loadEnv } from 'vite';
import react from '@vitejs/plugin-react';

// 总后台：建议放单独的域名或路径（如 admin.kpos.com），只给管理员工号开
export default defineConfig(({ mode }) => {
  const env = loadEnv(mode, process.cwd(), '');
  return {
    root: 'admin',
    envDir: '..',
    base: env.VITE_ADMIN_BASE || '/',
    plugins: [react()],
    define: { __MOCK__: JSON.stringify(mode === 'mock' || env.VITE_MOCK === '1') },
    server: { port: 5174, proxy: { '/admin-api': env.VITE_API_PROXY || 'http://localhost:8000' } },
    build: { outDir: '../dist/admin', emptyOutDir: true },
  };
});
