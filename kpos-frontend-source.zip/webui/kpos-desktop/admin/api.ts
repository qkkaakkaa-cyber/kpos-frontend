// 总后台接口，都在 /admin-api 下。只给管理员工号；后端每个接口都要再查一次角色
import { createClient } from '../shared/http';
import { go } from '../shared/router';
import { mockAdmin } from './mock';

export const http = createClient({
  base: '/admin-api',
  tokenKey: 'kpos.admin.token',
  mock: __MOCK__ ? mockAdmin : undefined,
  onUnauthorized: () => { http.setToken(null); if (!location.hash.startsWith('#/login')) go('/login'); },
});

export const api = {
  login: (code: string) => http.post<{ token: string; me: AdminMe }>('/auth/login', { code }),
  logout: () => http.post('/auth/logout'),
  me: () => http.get<AdminMe>('/me'),
  overview: (range: string) => http.get<any>('/overview?range=' + range),
  jobs: (kind: string, q: string, date: string) => http.get<any>(`/jobs?kind=${kind}&q=${encodeURIComponent(q)}&date=${date}`),
  job: (id: string) => http.get<any>('/jobs/' + id),
  exportUrl: (kind: string, q: string, date: string) => `/admin-api/jobs.csv?kind=${kind}&q=${encodeURIComponent(q)}&date=${date}`,
  usage: () => http.get<any>('/usage'),
  staff: () => http.get<any>('/staff'),
  createStaff: (b: any) => http.post<any>('/staff', b),
  staffAction: (id: number, a: 'kick' | 'disable' | 'enable') => http.post<any>(`/staff/${id}/${a}`),
  updateStaff: (id: number, b: any) => http.put<any>(`/staff/${id}`, b),
  security: (b: any) => http.put<any>('/security', b),
  roles: (b: any) => http.put<any>('/roles', b),
  workspaces: () => http.get<any>('/workspaces'),
  saveWorkspace: (b: any) => http.put<any>('/workspaces', b),
  vnStep: (i: number, done: boolean) => http.post<any>(`/workspaces/vn/steps/${i}`, { done }),
  depth: () => http.get<any>('/depth'),
  saveDepth: (b: any) => http.put<any>('/depth', b),
  nodes: () => http.get<any>('/nodes'),
  queueRules: (b: any) => http.put<any>('/queue/rules', b),
  queueAct: (id: string, a: 'up' | 'cancel') => http.post<any>(`/queue/${id}/${a}`),
};

export type AdminMe = { name: string; roleName: string; codeMask: string };
