// 总后台演示数据（npm run dev:admin:mock）。数字和画布一致，都是示例
import { ApiError, wait } from '../shared/http';

const db: any = {
  session: false,
  fails: 0,
  ws: 'all',
  staff: [
    { id: 1, code: 'MK0217345', name: '林晓雯', role: 'editor', dept: '新闻部', ws: ['th'], status: 'ok', last: '刚刚 · 剪辑部 PC-07', joined: '2025-03', quick: 58, deep: 21, tokens: 2_080_000, cost: 17.4, today: [7, 2], quota: { quick: 10, deep: 3, monthCost: 30, maxDepth: 'deep' } },
    { id: 2, code: 'MK0102001', name: '陈嘉豪', role: 'chief', dept: '新闻部', ws: ['th', 'my'], status: 'ok', last: '10 分钟前 · 主编室 PC-01', joined: '2024-08', quick: 71, deep: 18, tokens: 1_980_000, cost: 16.21, today: [9, 3], quota: {} },
    { id: 3, code: 'MK0188020', name: '王一凡', role: 'editor', dept: '社会部', ws: ['th'], status: 'ok', last: '25 分钟前 · 剪辑部 PC-03', joined: '2025-01', quick: 44, deep: 12, tokens: 1_310_000, cost: 10.66, today: [6, 1], quota: {} },
    { id: 4, code: 'MK0205111', name: 'Somchai 苏', role: 'editor', dept: '社会部', ws: ['th'], status: 'ok', last: '34 分钟前 · 家里 VPN', joined: '2025-05', quick: 20, deep: 9, tokens: 840_000, cost: 6.94, today: [9, 2], quota: {} },
    { id: 5, code: 'MK0110300', name: '李佳', role: 'chief', dept: '生活部', ws: ['my'], status: 'ok', last: '2 小时前 · 主编室 PC-02', joined: '2024-11', quick: 15, deep: 11, tokens: 950_000, cost: 7.52, today: [2, 1], quota: {} },
    { id: 6, code: 'MK0221456', name: '周敏', role: 'editor', dept: '生活部', ws: ['my'], status: 'ok', last: '昨天 · 家里 VPN', joined: '2025-06', quick: 30, deep: 9, tokens: 940_000, cost: 7.75, today: [10, 3], quota: {} },
    { id: 7, code: 'MK0230888', name: '张伟', role: 'intern', dept: '社会部', ws: ['th'], status: 'new', last: '—', joined: '2026-11', quick: 6, deep: 0, tokens: 60_000, cost: 0.66, today: [3, 0], quota: {} },
    { id: 8, code: 'MK0000001', name: '阿明', role: 'admin', dept: '技术部', ws: ['th', 'my', 'vn'], status: 'ok', last: '在线 · 机房 PC-00', joined: '2024-01', quick: 0, deep: 0, tokens: 0, cost: 0, today: [0, 0], quota: {} },
    { id: 9, code: 'MK0164009', name: '吴可', role: 'editor', dept: '生活部', ws: ['th'], status: 'off', last: '11-02 离职', joined: '2025-02', quick: 3, deep: 0, tokens: 30_000, cost: 0.33, today: [0, 0], quota: {} },
  ],
  roles: { intern: { quick: 5, deep: 0 }, editor: { quick: 10, deep: 3 }, chief: { quick: null, deep: null }, admin: { quick: null, deep: null } },
  security: { vpnOnly: true, keepDays: 7, maxDevices: 2, lockAfter: 5, lockMinutes: 15 },
  workspaces: [
    { id: 'th', short: 'TH', name: '泰国中文社', prefix: 'MK-[前缀]', sources: '中文社、公众号、外站', signoff: '泰国中文社X月X日报道', year: '佛历', status: 'ok' },
    { id: 'my', short: 'MY', name: '大马中文社', prefix: 'MK-[前缀]', sources: 'damanews.com、公众号、外站', signoff: '大马中文社X月X日报道', year: '公历', status: 'ok' },
    { id: 'vn', short: 'VN', name: '越南中文社', prefix: 'MK-[前缀]', sources: '[越南新闻源]', signoff: '越南中文社X月X日报道', year: '公历', status: 'setup' },
  ],
  vnRules: [
    ['片尾署名', '越南中文社X月X日报道。'], ['地点写到', '省、市、郡或县'],
    ['人名括号', '中国人和越南人姓名，拼写不带声调，如 阮文雄（NGUYEN VAN HUNG）'],
    ['金额', '1 tỷ đồng = 10亿越南盾，1 triệu = 100万，1 nghìn tỷ = 1万亿；一万以上用万、亿，不写千位逗号；金额不对就停止生成'],
    ['年份', '保留公历'], ['来源署名', '不写第三方媒体署名，也不换成"外媒""据报道"；警方、法院、政府照留；只有媒体单方说法的信息省略'],
    ['分析类表述', '原文没有的"分析认为""专家认为""这意味着"会被拦下'],
    ['优先写进口播', '中国公民、华人、中资、中越往来、签证居留、出入境、交通、在越生活安全'],
  ],
  vnSteps: [
    ['把越南版写稿规则填进工作区', '署名、地点、人名、越南盾换算、来源署名、分析类表述拦截，见右边', 'todo'],
    ['接越南新闻源', '「直接选新闻」列表改成越南的源，原图张数规则照用', 'todo'],
    ['给越南编辑开工号', '在「员工账号」里选工作区：越南中文社', 'todo'],
    ['导入旧的越南生成记录', '已发布的成片和文案保留，能在「生成记录」里查到', 'todo'],
    ['停用旧越南版入口', '并行跑一周，没问题再停', 'todo'],
  ],
  depth: {
    quick: { maxSec: 60, rewrite: 'plain', check: 'sensitive', tokens: 9800, cost: 0.11 },
    deep: { minutes: '2–3', articles: 6, days: 90, videos: 5, crossCheck: 3, check: 'full', tokens: 72000, cost: 0.52 },
    deeper: { articles: 10, days: 365, videos: 8, charts: '自动生成 1–2 张', tokens: 140000, cost: 0.98 },
    models: [
      { step: '新闻排行 · 聚类', note: '每 15 分钟一轮', model: 'Claude Haiku', in: 1, out: 5 },
      { step: '查来龙去脉', note: '读得最多，占 60%', model: 'Claude Sonnet', in: 3, out: 15 },
      { step: '写口播文案', note: '', model: 'Claude Sonnet', in: 3, out: 15 },
      { step: '核对事实 · 敏感词', note: '', model: 'Claude Sonnet', in: 3, out: 15 },
      { step: '翻译泰文引语', note: '', model: 'Claude Haiku', in: 1, out: 5 },
      { step: '标题和话题标签', note: '', model: 'Claude Haiku', in: 1, out: 5 },
    ],
    budget: { day: 40, month: 600, alertPct: 80, over: 'chief', voicePrice: 0.30, fx: 32.5 },
  },
  nodes: [
    { id: 1, name: '剪辑机-1', hw: 'Mac Studio M2 Ultra · 办公室', status: 'busy', job: '阿努廷否认操控上议院（深度 · 林晓雯）', pct: 46, cpu: 64, gpu: 71, disk: 58, done: 32 },
    { id: 2, name: '剪辑机-2', hw: 'Mac Studio M2 Ultra · 办公室', status: 'retry', job: '玛诺车队抵达曼谷总理府（深度 · 配音超时）', pct: 63, cpu: 38, gpu: 22, disk: 61, done: 29 },
    { id: 3, name: '剪辑机-3', hw: 'Windows · RTX 4080 · 机房', status: 'idle', job: '', pct: 0, cpu: 6, gpu: 3, disk: 88, done: 25 },
  ],
  queue: [
    { id: 'q1', user: '陈嘉豪', title: '泰铢兑人民币跌破 4.4 意味着什么', kind: 'deep', eta: '约 1 分钟后', node: '剪辑机-3' },
    { id: 'q2', user: '王一凡', title: '普吉岛下周起游客税正式征收', kind: 'quick', eta: '约 2 分钟后', node: '剪辑机-3' },
    { id: 'q3', user: '林晓雯', title: '素察会见俄籍受害者（重试）', kind: 'deep', eta: '约 4 分钟后', node: '自动分配' },
    { id: 'q4', user: '周敏', title: '清迈天灯节门票开售', kind: 'quick', eta: '约 6 分钟后', node: '自动分配' },
  ],
  queueRules: { perNode: 1, alertMin: 15, retries: 1, keepDays: 30, perUser: 5 },
};

const JOBS = ([
  ['17:01', '林晓雯', '阿努廷否认操控上议院：只有政绩能保政府', 'deep', '6 篇 · 5 段', 'running', 46, null, 227, 58210, 0.31, '剪辑机-1'],
  ['16:52', '陈嘉豪', '玛诺车队抵达曼谷总理府，要求柴油每升下调10泰铢', 'deep', '6 篇 · 5 段', 'retrying', 63, null, 550, 70480, 0.36, '剪辑机-2'],
  ['16:40', '王一凡', '曼谷 BTS 金线明年起票价统一 15 铢', 'quick', '—', 'done', 100, 56, 185, 9420, 0.11, '剪辑机-3'],
  ['16:31', 'Somchai 苏', '清迈出现今冬首场浓雾', 'quick', '—', 'done', 100, 49, 178, 8960, 0.10, '剪辑机-1'],
  ['15:40', '林晓雯', '素察会见俄籍受害者，核查自由海滩土地买卖', 'deep', '—', 'failed', 3, null, 12, 2140, 0.01, '—'],
  ['15:22', '李佳', '泰国内阁批准“泰国人游泰国”第二期补贴', 'deep', '8 篇 · 5 段', 'done', 100, 178, 662, 91300, 0.63, '剪辑机-3'],
  ['14:18', '王一凡', '芭提雅海滩夜市现场', 'upload', '3 段素材', 'done', 100, 44, 161, 5880, 0.08, '剪辑机-1'],
  ['08:15', '林晓雯', '泰国前选美冠军夫妇被羁押！家中查获32只名牌包', 'deep', '6 篇 · 5 段', 'done', 100, 161, 532, 73040, 0.52, '剪辑机-2'],
  ['07:50', '林晓雯', '曼谷警方逮捕两名中国籍电诈嫌疑人', 'quick', '—', 'done', 100, 58, 200, 10110, 0.11, '剪辑机-1'],
  ['07:12', '陈嘉豪', '泰国内阁批准“泰国人游泰国”第二期补贴', 'quick', '—', 'done', 100, 52, 181, 9350, 0.10, '剪辑机-3'],
] as const).map((r, i) => ({ id: 'J-20261110-' + String(42 - i).padStart(4, '0'), at: r[0], user: r[1], title: r[2], kind: r[3], depth: r[4], status: r[5], progress: r[6], duration: r[7], took: r[8], tokens: r[9], cost: r[10], node: r[11] }));

const STEPS = [
  ['读取原文', 4, 2100, 0], ['判断新闻类型', 2, 1300, 40], ['查来龙去脉 · 6 篇', 72, 38400, 2900], ['写口播文案', 38, 14200, 1850],
  ['核对事实和敏感词', 15, 6900, 420], ['翻译泰文引语', 9, 1800, 350], ['生成标题和话题标签', 6, 2600, 180],
  ['配音 · 615 字', 41, null, null], ['找现场视频 · 5 段', 125, null, null], ['找配图 · 4 张', 22, null, null], ['剪辑 · 加字幕 · 混音 · 导出', 198, null, null],
];

const DAYS = ['10/28', '10/29', '10/30', '10/31', '11/1', '11/2', '11/3', '11/4', '11/5', '11/6', '11/7', '11/8', '11/9', '11/10'];
const LIN = [1.21, 1.05, 1.32, 1.18, 0.86, 0.79, 1.27, 1.36, 1.41, 1.30, 1.22, 0.95, 1.38, 1.44];
const WEN = [0.62, 0.58, 0.66, 0.61, 0.47, 0.44, 0.64, 0.69, 0.71, 0.66, 0.63, 0.52, 0.70, 0.71];
const OTH = [0.21, 0.19, 0.22, 0.21, 0.17, 0.16, 0.22, 0.23, 0.24, 0.22, 0.21, 0.18, 0.24, 0.25];

const ROLE_NAME: Record<string, string> = { intern: '实习编辑', editor: '编辑', chief: '主编', admin: '管理员' };
const mask = (c: string) => c.slice(0, 4) + '••';
const pubStaff = (s: any) => ({ ...s, code: mask(s.code), roleName: ROLE_NAME[s.role] });

export async function mockAdmin(method: string, path: string, body: any = {}, token = ''): Promise<any> {
  await wait(180);
  const [p, qs = ''] = path.split('?');
  const q = new URLSearchParams(qs);
  let r: RegExpMatchArray | null;

  if (method === 'POST' && p === '/auth/login') {
    const code = String(body.code || '').replace(/\D/g, '');
    const s = db.staff.find((x: any) => x.code === 'MK' + code);
    if (!s || s.status === 'off') { db.fails++; throw new ApiError(401, db.fails >= 5 ? '连续输错 5 次，这台电脑锁定 15 分钟' : `工号不对，还能试 ${5 - db.fails} 次`); }
    if (s.role !== 'admin') throw new ApiError(403, '这个工号不是管理员，不能进总后台');
    db.session = true; db.fails = 0;
    return { token: 'demo-admin', me: { name: s.name, roleName: '管理员', codeMask: mask(s.code) } };
  }
  if (method === 'POST' && p === '/auth/logout') { db.session = false; return { ok: true }; }
  if (!db.session && token !== 'demo-admin') throw new ApiError(401, '请先登录');
  if (p === '/me') return { name: '阿明', roleName: '管理员', codeMask: 'MK00••' };

  if (p === '/overview') {
    const range = q.get('range') || 'today';
    const k = { today: 1, '7d': 6.6, '30d': 27, month: 9.4 }[range] || 1;
    return {
      range, asOf: '11月10日 周二 · 截至 17:05',
      kpi: { videos: Math.round(86 * k), quick: Math.round(61 * k), deep: Math.round(25 * k), vsPrev: 12, success: 94.2, failed: Math.round(4 * k), cancelled: Math.round(1 * k), running: 3, tokens: 2.40 * k, tokensIn: 2.05 * k, tokensOut: 0.35 * k, cost: 19.7 * k, costVoice: 8.9 * k, fx: 32.5, nodesOnline: 3, nodes: 3, queued: 4, clearMin: 6 },
      daily: DAYS.map((d, i) => ({ day: d, story: LIN[i], script: WEN[i], other: OTH[i] })),
      perVideo: [
        ['Token', '9,800', '72,000', '6,100'], ['AI 费用', 'US$ 0.11', 'US$ 0.52', 'US$ 0.09'], ['配音字数', '220', '615', '180'],
        ['查的报道', '0', '6 篇', '0'], ['现场视频', '0', '5 段', '用户上传'], ['成片时长', '54 秒', '2分36秒', '48 秒'], ['生成用时', '3分12秒', '9分40秒', '2分50秒'],
      ],
      top: db.staff.filter((s: any) => s.tokens > 0).slice(0, 5).map((s: any, i: number) => ({ name: s.name, roleName: ROLE_NAME[s.role], quick: [21, 18, 12, 6, 4][i], deep: [9, 6, 4, 3, 3][i], tokens: [702, 512, 351, 242, 233][i] * 1000, cost: [5.36, 3.92, 2.71, 1.83, 1.79][i] })),
      problems: [['17:02', '配音超时，已自动重试 1 次', '陈嘉豪 · 剪辑机-2'], ['15:40', '原文链接打不开（Matichon 403）', '林晓雯 · —'], ['14:18', '现场视频都不能用，换成配图后完成', '王一凡 · 剪辑机-1'], ['11:05', '用户在第 4 步终止', 'Somchai 苏 · —']],
      monthCost: 203, monthBudget: 600,
    };
  }
  if (p === '/jobs') {
    const kind = q.get('kind') || 'all', kw = (q.get('q') || '').trim();
    const list = JOBS.filter(j => (kind === 'all' || j.kind === kind) && (!kw || j.user.includes(kw) || j.title.includes(kw)));
    return { items: list, sum: { count: kind === 'all' && !kw ? 89 : list.length, tokens: list.reduce((s, j) => s + (j.tokens as number), 0) * (kind === 'all' && !kw ? 10.4 : 1), cost: 19.71, voiceChars: 31450, footage: '1 小时 52 分' } };
  }
  if ((r = p.match(/^\/jobs\/([^/]+)$/))) {
    const j = JOBS.find(x => x.id === r![1]);
    if (!j) throw new ApiError(404, '找不到这条');
    return {
      ...j, startedAt: j.at, depthName: j.kind === 'deep' ? '标准' : '—', tokensIn: Math.round((j.tokens as number) * 0.92), tokensOut: Math.round((j.tokens as number) * 0.08),
      steps: STEPS.map(s => ({ name: s[0], sec: s[1], in: s[2], out: s[3] })),
      costLines: [['大模型 · Claude Sonnet', '67,300 × $3/M + 5,740 × $15/M = US$ 0.29'], ['配音 · ElevenLabs', '615 字 = US$ 0.18'], ['搜索 · 找视频和图', '23 次 = US$ 0.05']],
      log: ['08:15:02 开始', '08:16:14 查到 6 篇相关报道', '08:17:30 口播写好 612 字', '08:19:40 找到 5 段现场视频', '08:24:01 导出完成'],
    };
  }
  if (p === '/staff' && method === 'GET') return { items: db.staff.map(pubStaff), roles: db.roles, security: db.security };
  if (method === 'POST' && p === '/staff') {
    if (!String(body.name || '').trim()) throw new ApiError(422, '填名字');
    const code = String(body.code || '').toUpperCase();
    if (!/^MK\d{7}$/.test(code)) throw new ApiError(422, '工号是 MK + 7 位数字');
    if (db.staff.some((s: any) => s.code === code)) throw new ApiError(409, '这个工号已经有人用了');
    if (!body.ws?.length) throw new ApiError(422, '至少选一个工作区');
    const s = { id: db.staff.length + 1, code, name: body.name.trim(), role: body.role, dept: body.dept, ws: body.ws, status: 'new', last: '—', joined: '2026-11', quick: 0, deep: 0, tokens: 0, cost: 0, today: [0, 0], quota: {} };
    db.staff.unshift(s);
    return { ...pubStaff(s), fullCode: code };
  }
  if (method === 'POST' && (r = p.match(/^\/staff\/(\d+)\/(kick|disable|enable)$/))) {
    const s = db.staff.find((x: any) => x.id === Number(r![1]));
    if (s.role === 'admin' && r[2] === 'disable' && db.staff.filter((x: any) => x.role === 'admin' && x.status !== 'off').length <= 1) throw new ApiError(409, '至少要留一个管理员');
    if (r[2] === 'disable') { s.status = 'off'; s.last = '刚刚停用'; }
    if (r[2] === 'enable') s.status = 'ok';
    return pubStaff(s);
  }
  if (method === 'PUT' && (r = p.match(/^\/staff\/(\d+)$/))) {
    const s = db.staff.find((x: any) => x.id === Number(r![1]));
    Object.assign(s.quota, body.quota || {}); if (body.ws) s.ws = body.ws; if (body.role) s.role = body.role;
    return pubStaff(s);
  }
  if (p === '/security') { if (method === 'PUT') Object.assign(db.security, body); return db.security; }
  if (p === '/roles') { if (method === 'PUT') Object.assign(db.roles, body); return db.roles; }
  if (p === '/usage') {
    const daily = [62, 80, 41, 95, 120, 70, 0, 0, 88, 101, 76, 130, 64, 92, 110, 73, 0, 58, 140, 96, 84, 77, 102, 69, 0, 91, 118, 66, 125, 104];
    return { items: db.staff.filter((s: any) => s.role !== 'admin').map(pubStaff), roles: db.roles, daily };
  }
  if (p === '/workspaces') { if (method === 'PUT') { const w = db.workspaces.find((x: any) => x.id === body.id); Object.assign(w, body); } return { items: db.workspaces, vnRules: db.vnRules, vnSteps: db.vnSteps }; }
  if (method === 'POST' && (r = p.match(/^\/workspaces\/vn\/steps\/(\d)$/))) { db.vnSteps[Number(r[1])][2] = body.done ? 'done' : 'todo'; return { items: db.workspaces, vnRules: db.vnRules, vnSteps: db.vnSteps }; }
  if (p === '/depth') { if (method === 'PUT') Object.assign(db.depth, body); return db.depth; }
  if (p === '/nodes') return { nodes: db.nodes, queue: db.queue, rules: db.queueRules };
  if (method === 'PUT' && p === '/queue/rules') { Object.assign(db.queueRules, body); return db.queueRules; }
  if (method === 'POST' && (r = p.match(/^\/queue\/(q\d+)\/(up|cancel)$/))) {
    const i = db.queue.findIndex((x: any) => x.id === r![1]);
    if (i < 0) throw new ApiError(404, '这条已经开始或已取消');
    const [it] = db.queue.splice(i, 1);
    if (r[2] === 'up') db.queue.unshift(it);
    return { nodes: db.nodes, queue: db.queue, rules: db.queueRules };
  }
  throw new ApiError(404, '没有这个接口：' + method + ' ' + p);
}
