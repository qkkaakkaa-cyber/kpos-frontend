import { createRoot } from 'react-dom/client';
import '../shared/styles.css';
import { AdminApp } from './App';

createRoot(document.getElementById('root')!).render(<AdminApp />);
