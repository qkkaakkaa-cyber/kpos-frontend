// 国家工作区：一个入口按工号进对应国家；各国的新闻源、署名、写稿差异
import { ErrorBox, Loading, useAsync, useToast } from '../../shared/ui';
import { api } from '../api';
import { Top } from '../App';

const CH: Record<string, string> = { th: 'c-p', my: 'c-m', vn: 'c-y' };

export function Workspaces() {
  const toast = useToast();
  const { data, error, loading, reload, setData } = useAsync(() => api.workspaces(), []);
  if (loading && !data) return <><Top title="国家工作区" /><Loading rows={6} /></>;
  if (error) return <><Top title="国家工作区" /><div className="body"><ErrorBox error={error} retry={reload} /></div></>;
  const done = data.vnSteps.filter((s: any) => s[2] === 'done').length;
  return (
    <>
      <Top title="国家工作区" sub="一个 KPOS 入口，按工号进对应国家；每个国家的新闻源和写稿规则分开设" right={<button className="btn" onClick={() => toast('新建工作区：先在后端加新闻源和署名规则')}>新建工作区</button>} />
      <div className="body">
        <section className="col" style={{ flex: '1 1 0' }}>
          <div className="card" style={{ overflowX: 'auto' }}><table className="t">
            <thead><tr><th>工作区</th><th>工号前缀</th><th>新闻源</th><th>片尾署名</th><th>年份</th><th>状态</th></tr></thead>
            <tbody>{data.items.map((w: any) => <tr key={w.id} className={w.id === 'vn' ? 'sel' : ''}>
              <td><span className="row" style={{ gap: 8 }}><span className={'chip ' + CH[w.id]}>{w.short}</span><b>{w.name}</b></span></td>
              <td className="num">{w.prefix}</td><td className="muted">{w.sources}</td><td>{w.signoff}</td><td>{w.year}</td>
              <td><span className={'chip ' + (w.status === 'ok' ? 'c-m' : 'c-y')}>{w.status === 'ok' ? '正常' : '接入中'}</span></td></tr>)}</tbody></table></div>
          <section className="card pad col" style={{ gap: 4 }}>
            <div className="row wrap" style={{ paddingBottom: 4 }}><span className="h2">越南版搬进 KPOS</span><span className="small muted">做完这几步，越南编辑就从 kpos.com 登录，旧入口停掉</span><span className="chip c-y" style={{ marginLeft: 'auto' }}>{done} / {data.vnSteps.length}</span></div>
            {data.vnSteps.map((s: any, i: number) => (
              <div key={i} className="row" style={{ alignItems: 'flex-start', gap: 12, padding: '9px 0', borderBottom: i < data.vnSteps.length - 1 ? '1px solid var(--line2)' : 0 }}>
                <span style={{ width: 22, height: 22, flex: 'none', borderRadius: 9999, border: '2px solid ' + (s[2] === 'done' ? 'var(--m)' : 'var(--input)'), background: s[2] === 'done' ? 'var(--m)' : '#fff', color: s[2] === 'done' ? '#fff' : 'var(--grey)', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 12, fontWeight: 700 }}>{s[2] === 'done' ? '✓' : i + 1}</span>
                <span className="col grow" style={{ gap: 0 }}><b style={{ fontSize: 13 }}>{s[0]}</b><span className="small muted">{s[1]}</span></span>
                <button className={'btn sm ' + (s[2] === 'done' ? 'ghost' : 'soft')} onClick={async () => { try { setData(await api.vnStep(i, s[2] !== 'done')); } catch (e: any) { toast(e.message); } }}>{s[2] === 'done' ? '标为未完成' : '标为完成'}</button>
              </div>
            ))}
          </section>
        </section>
        <aside className="col" style={{ flex: '0 0 420px' }}>
          <section className="card pad col" style={{ gap: 14 }}>
            <div className="row"><span className="chip c-y">VN</span><span className="h2">越南中文社 · 写稿规则</span></div>
            <div className="kv" style={{ gridTemplateColumns: '96px 1fr', lineHeight: '20px' }}>{data.vnRules.map((r: string[]) => [<span key={r[0]}>{r[0]}</span>, <span key={r[0] + 'v'} style={{ color: 'var(--ink)' }}>{r[1]}</span>])}</div>
            <div className="col" style={{ gap: 8, paddingTop: 4 }}><span className="small b">写稿流程</span>
              <span className="row wrap" style={{ gap: 6 }}><span className="chip c-p">初稿</span><span className="muted">→</span><span className="chip c-p">改稿</span><span className="muted">→</span><span className="chip c-y">压缩（新增）</span><span className="muted">→</span><span className="chip c-y">精修（新增）</span></span>
              <span className="small muted">旧越南版只有初稿和改稿；搬进 KPOS 后和泰国、大马用同一套流程。</span></div>
          </section>
          <div className="note">写稿总规则、翻译、标题三个国家共用一份，在「深度与模型」里改一次全部生效；上面这些是各国自己的差异。</div>
        </aside>
      </div>
    </>
  );
}
