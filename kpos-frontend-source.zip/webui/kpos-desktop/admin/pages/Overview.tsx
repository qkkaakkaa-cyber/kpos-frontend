// 概览：剪辑量、成功率、Token、费用、剪辑机；近 14 天 Token 堆叠柱状图
import { useState } from 'react';
import { go, Link } from '../../shared/router';
import { ErrorBox, fmtK, Loading, Seg, useAsync } from '../../shared/ui';
import { api } from '../api';
import { Top } from '../App';

// 三种用途的颜色（已校验色弱可分；配图例和表格）
const SERIES = [{ k: 'story', name: '查来龙去脉', c: '#2E9C80' }, { k: 'script', name: '写口播文案', c: '#6A55A0' }, { k: 'other', name: '标题·翻译·排行', c: '#D08A1E' }];

export function Overview({ range }: { range: string }) {
  const { data: d, error, loading, reload } = useAsync(() => api.overview(range), [range]);
  const [table, setTable] = useState(false);
  return (
    <>
      <Top title="概览" sub={d?.asOf} right={<Seg value={range} onChange={v => go('/overview?range=' + v)} options={[{ v: 'today', label: '今天' }, { v: '7d', label: '7 天' }, { v: '30d', label: '30 天' }, { v: 'month', label: '本月' }]} />} />
      {loading && !d ? <Loading rows={6} /> : error ? <div className="body"><ErrorBox error={error} retry={reload} /></div> : (
        <div className="col" style={{ padding: '24px 28px', gap: 16 }}>
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(190px, 1fr))', gap: 16 }}>
            <Kpi lab={range === 'today' ? '今天剪辑' : '剪辑'} val={d.kpi.videos} unit="条" foot={<>快讯 {d.kpi.quick} · 深度解析 {d.kpi.deep}{range === 'today' && <> · <span className="up">比昨天 +{d.kpi.vsPrev}</span></>}</>} />
            <Kpi lab="成功率" val={d.kpi.success} unit="%" foot={`失败 ${d.kpi.failed} · 终止 ${d.kpi.cancelled} · 生成中 ${d.kpi.running}`} />
            <Kpi lab="Token 消耗" val={d.kpi.tokens.toFixed(2)} unit="M" foot={`输入 ${d.kpi.tokensIn.toFixed(2)}M · 输出 ${d.kpi.tokensOut.toFixed(2)}M`} />
            <Kpi lab="AI 费用" val={'US$ ' + d.kpi.cost.toFixed(1)} foot={`≈ ฿ ${Math.round(d.kpi.cost * d.kpi.fx).toLocaleString()} · 其中配音 US$ ${d.kpi.costVoice.toFixed(1)}`} />
            <Kpi lab="剪辑机" val={`${d.kpi.nodesOnline} / ${d.kpi.nodes}`} unit="在线" foot={`排队 ${d.kpi.queued} 条 · 预计 ${d.kpi.clearMin} 分钟清空`} to="/nodes" />
          </div>
          <div className="body" style={{ padding: 0, alignItems: 'stretch' }}>
            <section className="card pad col" style={{ flex: '1 1 0', gap: 12 }}>
              <div className="row wrap"><span className="h2">近 14 天 Token 消耗</span>
                <span className="row" style={{ marginLeft: 'auto', gap: 14 }}>{SERIES.map(s => <span key={s.k} className="row small" style={{ gap: 6 }}><span className="dot" style={{ background: s.c, borderRadius: 3 }} />{s.name}</span>)}</span>
                <button className="back small" onClick={() => setTable(!table)}>{table ? '看图' : '看表格'}</button></div>
              {table ? <DailyTable rows={d.daily} /> : <Chart rows={d.daily} />}
              <span className="small muted">深度解析一条约 7.2 万 Token，是快讯的 7 倍多；大头在「查来龙去脉」读相关报道。</span>
            </section>
            <section className="card col" style={{ flex: '0 0 400px', gap: 0, overflow: 'hidden' }}>
              <div className="pad" style={{ paddingBottom: 10 }}><span className="h2">平均每条</span></div>
              <table className="t"><thead><tr><th></th><th className="r">快讯</th><th className="r">深度解析</th><th className="r">上传素材</th></tr></thead>
                <tbody>{d.perVideo.map((r: string[]) => <tr key={r[0]}><td className="muted">{r[0]}</td><td className="r num">{r[1]}</td><td className="r num b">{r[2]}</td><td className="r num">{r[3]}</td></tr>)}</tbody></table>
              <Link to="/depth" className="small sb" style={{ padding: '12px 20px' }}>调整深度和模型 →</Link>
            </section>
          </div>
          <div className="body" style={{ padding: 0, alignItems: 'stretch' }}>
            <section className="card col" style={{ flex: '1 1 0', gap: 0, overflow: 'hidden' }}>
              <div className="pad row" style={{ paddingBottom: 10 }}><span className="h2">用得最多的人</span><Link to="/usage" className="small sb" style={{ marginLeft: 'auto' }}>全部员工 →</Link></div>
              <table className="t"><thead><tr><th>用户</th><th>身份</th><th className="r">快讯</th><th className="r">深度</th><th className="r">Token</th><th className="r">费用</th></tr></thead>
                <tbody>{d.top.map((u: any) => <tr key={u.name}><td><span className="row" style={{ gap: 8 }}><span className="av sm">{u.name.slice(0, 1)}</span><b>{u.name}</b></span></td><td className="muted">{u.roleName}</td><td className="r num">{u.quick}</td><td className="r num">{u.deep}</td><td className="r num b">{fmtK(u.tokens)}</td><td className="r num">US$ {u.cost.toFixed(2)}</td></tr>)}</tbody></table>
            </section>
            <section className="card pad col" style={{ flex: '0 0 400px', gap: 4 }}>
              <div className="row"><span className="h2">失败和异常</span><Link to="/jobs" className="small sb" style={{ marginLeft: 'auto' }}>剪辑记录 →</Link></div>
              {d.problems.map((p: string[], i: number) => <div key={i} className="row" style={{ gap: 12, padding: '10px 0', borderBottom: '1px solid var(--line2)', alignItems: 'flex-start' }}><span className="small num muted" style={{ width: 40, flex: 'none' }}>{p[0]}</span><span className="col" style={{ gap: 0 }}><span style={{ fontSize: 13 }}>{p[1]}</span><span className="small muted">{p[2]}</span></span></div>)}
              <div className="col" style={{ gap: 6, paddingTop: 12 }}><span className="small sb">本月 AI 费用 US$ {d.monthCost} / 预算 {d.monthBudget}</span><div className="bar"><i style={{ width: Math.min(100, d.monthCost / d.monthBudget * 100) + '%', background: 'var(--y)' }} /></div></div>
            </section>
          </div>
        </div>
      )}
    </>
  );
}

function Kpi({ lab, val, unit, foot, to }: { lab: string; val: any; unit?: string; foot: any; to?: string }) {
  const inner = <><span className="lab">{lab}</span><span className="val">{val}{unit && <small>{unit}</small>}</span><span className="foot">{foot}</span></>;
  return to ? <Link to={to} className="card kpi" style={{ textDecoration: 'none', color: 'inherit' }}>{inner}</Link> : <div className="card kpi">{inner}</div>;
}

function Chart({ rows }: { rows: any[] }) {
  const [hover, setHover] = useState<number | null>(null);
  const W = 640, H = 280, L = 40, B = 26, ph = H - B - 8, max = 3, bw = (W - L) / rows.length;
  const y = (v: number) => 8 + ph - (v / max) * ph;
  return (
    <div style={{ position: 'relative' }}>
      <svg viewBox={`0 0 ${W} ${H}`} width="100%" role="img" aria-label="近 14 天每天 Token 消耗，按用途分" style={{ display: 'block' }}>
        {[0, 1, 2, 3].map(v => <g key={v}><line x1={L} x2={W} y1={y(v)} y2={y(v)} stroke="#EEF1F3" /><text x={L - 8} y={y(v) + 4} textAnchor="end" fontSize="11" fill="#9AA2A8">{v}M</text></g>)}
        {rows.map((r, i) => {
          const x = L + i * bw + 6, w = bw - 12;
          let base = 8 + ph;
          const segs = SERIES.map((s, j) => { const h = (r[s.k] / max) * ph; const top = base - h; const el = <rect key={s.k} x={x} y={top} width={w} height={Math.max(0, h - (j < 2 ? 2 : 0))} rx={j === 2 ? 4 : 0} fill={s.c} opacity={hover === null || hover === i ? 1 : 0.45} />; base = top; return el; });
          const tot = r.story + r.script + r.other;
          return (
            <g key={r.day}>
              {segs}
              {i === rows.length - 1 && <text x={x + w / 2} y={base - 6} textAnchor="middle" fontSize="11" fontWeight="700" fill="#262833">{tot.toFixed(2)}M</text>}
              {(i % 2 === 1 || i === rows.length - 1) && <text x={x + w / 2} y={H - 6} textAnchor="middle" fontSize="11" fill="#9AA2A8">{r.day}</text>}
              <rect x={L + i * bw} y={0} width={bw} height={H} fill="transparent" onMouseEnter={() => setHover(i)} onMouseLeave={() => setHover(null)} />
            </g>
          );
        })}
      </svg>
      {hover !== null && (
        <div className="card small" style={{ position: 'absolute', top: 8, left: `${Math.min(70, ((L + hover * bw) / W) * 100)}%`, padding: '8px 12px', pointerEvents: 'none', boxShadow: '0 6px 18px rgba(38,40,51,.12)', minWidth: 160 }}>
          <b>{rows[hover].day} · {(rows[hover].story + rows[hover].script + rows[hover].other).toFixed(2)}M</b>
          {SERIES.map(s => <div key={s.k} className="row" style={{ gap: 6 }}><span className="dot" style={{ background: s.c, borderRadius: 3 }} /><span className="grow">{s.name}</span><span className="num">{rows[hover][s.k].toFixed(2)}M</span></div>)}
        </div>
      )}
    </div>
  );
}

function DailyTable({ rows }: { rows: any[] }) {
  return <div style={{ overflowX: 'auto' }}><table className="t"><thead><tr><th>日期</th>{SERIES.map(s => <th key={s.k} className="r">{s.name}</th>)}<th className="r">合计</th></tr></thead>
    <tbody>{rows.map(r => <tr key={r.day}><td>{r.day}</td>{SERIES.map(s => <td key={s.k} className="r num">{r[s.k].toFixed(2)}M</td>)}<td className="r num b">{(r.story + r.script + r.other).toFixed(2)}M</td></tr>)}</tbody></table></div>;
}
