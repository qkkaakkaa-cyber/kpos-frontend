// 员工账号：开工号、踢下线、停用；角色默认额度；登录安全
import { useState } from 'react';
import { Icon } from '../../shared/icons';
import { copyText, ErrorBox, Loading, Modal, Seg, Toggle, useAsync, useToast } from '../../shared/ui';
import { api } from '../api';
import { Top } from '../App';

const ROLES = [['intern', '实习编辑', '只能做快讯'], ['editor', '编辑', '快讯和深度解析'], ['chief', '主编', '加「深入」档，不限条数'], ['admin', '管理员', '能进总后台']];
const WS = [['th', '泰国中文社'], ['my', '大马中文社'], ['vn', '越南中文社']];

export function Accounts() {
  const toast = useToast();
  const { data, error, loading, reload, setData } = useAsync(() => api.staff(), []);
  const [f, setF] = useState('all');
  const [q, setQ] = useState('');
  const [form, setForm] = useState({ name: '', code: 'MK', dept: '社会部', role: 'intern', ws: ['th'] as string[] });
  const [created, setCreated] = useState<any>(null);
  const [ask, setAsk] = useState<any>(null);
  if (loading && !data) return <><Top title="员工账号" /><Loading rows={8} /></>;
  if (error) return <><Top title="员工账号" /><div className="body"><ErrorBox error={error} retry={reload} /></div></>;
  const items: any[] = data.items;
  const list = items.filter(s => (f === 'all' || (f === 'off' ? s.status === 'off' : s.status !== 'off')) && (!q || s.name.includes(q) || s.code.includes(q.toUpperCase())));

  async function create() {
    try { const s = await api.createStaff(form); setCreated(s); setForm({ ...form, name: '', code: 'MK' }); reload(); } catch (e: any) { toast(e.message); }
  }
  async function act(s: any, a: 'kick' | 'disable' | 'enable') {
    setAsk(null);
    try { await api.staffAction(s.id, a); toast(a === 'kick' ? '已踢下线' : a === 'disable' ? '已停用' : '已启用'); reload(); } catch (e: any) { toast(e.message); }
  }
  async function sec(patch: any) {
    try { const r = await api.security(patch); setData({ ...data, security: r }); } catch (e: any) { toast(e.message); }
  }
  return (
    <>
      <Top title="员工账号" sub="只有这里开的工号能登录 KPOS，输工号就能进" />
      <div className="body">
        <section className="col" style={{ flex: '1 1 0' }}>
          <div className="row wrap"><Seg value={f} onChange={setF} options={[{ v: 'all', label: `全部 ${items.length}` }, { v: 'ok', label: `正常 ${items.filter(s => s.status !== 'off').length}` }, { v: 'off', label: `已停用 ${items.filter(s => s.status === 'off').length}` }]} />
            <span className="field" style={{ width: 200 }}><Icon name="search" size={16} color="#9AA2A8" /><input value={q} onChange={e => setQ(e.target.value)} placeholder="名字、工号" aria-label="搜名字、工号" /></span></div>
          <div className="card" style={{ overflowX: 'auto' }}><table className="t">
            <thead><tr><th>工号</th><th>名字</th><th>角色</th><th>工作区</th><th>状态</th><th>最近登录</th><th></th></tr></thead>
            <tbody>{list.map(s => <tr key={s.id}>
              <td className="num b">{s.code}</td><td><span className="row" style={{ gap: 8 }}><span className="av sm">{s.name.slice(0, 1)}</span><b>{s.name}</b></span></td>
              <td>{s.roleName}</td><td className="small">{s.ws.map((w: string) => w.toUpperCase()).join(' · ')}</td>
              <td><span className={'chip ' + (s.status === 'off' ? 'c-r' : s.status === 'new' ? 'c-y' : 'c-m')}>{s.status === 'off' ? '已停用' : s.status === 'new' ? '还没登录过' : '正常'}</span></td>
              <td className="small muted">{s.last}</td>
              <td className="r">{s.status !== 'off' && <><button className="back small" onClick={() => act(s, 'kick')}>踢下线</button> · </>}
                <button className="back small" style={{ color: s.status === 'off' ? undefined : 'var(--w-deep)' }} onClick={() => s.status === 'off' ? act(s, 'enable') : setAsk(s)}>{s.status === 'off' ? '启用' : '停用'}</button></td>
            </tr>)}</tbody></table></div>
        </section>
        <aside className="col" style={{ flex: '0 0 360px' }}>
          <section className="card pad col" style={{ gap: 12 }}>
            <span className="h2">新开工号</span>
            <label className="lab">名字<input className="in" value={form.name} onChange={e => setForm({ ...form, name: e.target.value })} /></label>
            <div className="row" style={{ alignItems: 'flex-start' }}>
              <label className="lab grow">工号<input className="in num" value={form.code} maxLength={9} onChange={e => setForm({ ...form, code: 'MK' + e.target.value.replace(/^MK/i, '').replace(/\D/g, '').slice(0, 7) })} /></label>
              <label className="lab grow">部门<select className="in" value={form.dept} onChange={e => setForm({ ...form, dept: e.target.value })}>{['新闻部', '社会部', '生活部', '技术部'].map(d => <option key={d}>{d}</option>)}</select></label>
            </div>
            <label className="lab">角色<Seg value={form.role} onChange={v => setForm({ ...form, role: v })} options={ROLES.map(r => ({ v: r[0], label: r[1] }))} /></label>
            <div className="lab">工作区<span className="row wrap">{WS.map(([id, n]) => <label key={id} className="row small" style={{ gap: 6, fontWeight: 500 }}><input type="checkbox" checked={form.ws.includes(id)} onChange={e => setForm({ ...form, ws: e.target.checked ? [...form.ws, id] : form.ws.filter(x => x !== id) })} />{n}</label>)}</span></div>
            <div className="small muted tip">工号只在开通时完整显示一次，当面告诉对方；列表里只显示前 4 位。离职当天记得停用。</div>
            <button className="btn" disabled={!form.name.trim() || form.code.length !== 9 || !form.ws.length} onClick={create}>开通</button>
          </section>
          <section className="card pad col" style={{ gap: 4 }}>
            <span className="h2">角色和默认额度</span><span className="small muted" style={{ paddingBottom: 4 }}>右边是每天 快讯 · 深度解析 条数</span>
            {ROLES.map(([k, n, d]) => { const r = data.roles[k]; return <div key={k} className="row" style={{ padding: '9px 0', borderBottom: '1px solid var(--line2)' }}><span className="col grow" style={{ gap: 0, lineHeight: '19px' }}><b style={{ fontSize: 13 }}>{n}</b><span className="small muted">{d}</span></span><span className="small num muted">{r.quick == null ? '不限' : `${r.quick} · ${r.deep}`}</span></div>; })}
          </section>
          <section className="card pad col" style={{ gap: 10 }}>
            <span className="h2">登录安全</span>
            <div className="row"><span className="grow sb" style={{ fontSize: 13 }}>只允许公司网络和 VPN</span><Toggle on={data.security.vpnOnly} label="只允许公司网络和 VPN" onChange={v => v ? sec({ vpnOnly: true }) : setAsk({ vpn: true })} /></div>
            <div className="row"><span className="grow sb" style={{ fontSize: 13 }}>保持登录</span><input className="in num" defaultValue={data.security.keepDays} onBlur={e => sec({ keepDays: Number(e.target.value.replace(/\D/g, '') || 7) })} style={{ width: 56, height: 34 }} aria-label="保持登录天数" /> 天</div>
            <div className="row"><span className="grow sb" style={{ fontSize: 13 }}>同一个工号最多同时在</span><input className="in num" defaultValue={data.security.maxDevices} onBlur={e => sec({ maxDevices: Number(e.target.value.replace(/\D/g, '') || 1) })} style={{ width: 56, height: 34 }} aria-label="最多几台电脑" /> 台电脑</div>
            <div className="row"><span className="grow sb" style={{ fontSize: 13 }}>连续输错锁定</span><span className="small muted">{data.security.lockAfter} 次 · 锁 {data.security.lockMinutes} 分钟</span></div>
            <div className="note">工号就是登录凭证，没有另外的密码。安全靠只在公司网络和 VPN 里能打开，这个开关不要关；工号泄露了就停用、换一个新的。</div>
          </section>
        </aside>
      </div>
      {created && <Modal title="工号开好了" onClose={() => setCreated(null)} actions={<button className="btn" onClick={() => setCreated(null)}>我记下了</button>}>
        <span className="muted">{created.name} · {created.roleName}。这个工号只显示这一次：</span>
        <div className="row" style={{ padding: '12px 14px', borderRadius: 10, background: 'var(--p-sel)' }}><b className="num grow" style={{ fontSize: 22, letterSpacing: '.08em' }}>{created.fullCode}</b>
          <button className="btn soft sm" onClick={async () => toast((await copyText(created.fullCode)) ? '已复制' : '复制不了，请手动记下')}><Icon name="copy" size={14} />复制</button></div>
      </Modal>}
      {ask && !ask.vpn && <Modal title={`停用 ${ask.name}？`} onClose={() => setAsk(null)} actions={<><button className="btn ghost" onClick={() => setAsk(null)}>先不</button><button className="btn" style={{ background: 'var(--r)' }} onClick={() => act(ask, 'disable')}>确认停用</button></>}>
        <span className="muted">停用后马上下线，工号不能再登录；做过的视频和记录保留。</span></Modal>}
      {ask?.vpn && <Modal title="关掉网络限制？" onClose={() => setAsk(null)} actions={<><button className="btn ghost" onClick={() => setAsk(null)}>不关</button><button className="btn" style={{ background: 'var(--r)' }} onClick={() => { setAsk(null); sec({ vpnOnly: false }); }}>我知道风险，关掉</button></>}>
        <span className="muted">工号没有密码。关掉以后，任何人在任何网络里知道工号就能登录。</span></Modal>}
    </>
  );
}
