// 剪辑记录：所有人的每一条，Token、费用、用时；右边看每一步
import { useState } from 'react';
import { Icon } from '../../shared/icons';
import { go } from '../../shared/router';
import { Empty, ErrorBox, fmtClock, fmtNum, KIND, Loading, Seg, StatusChip, useAsync } from '../../shared/ui';
import { api } from '../api';
import { Top } from '../App';

export function AdminJobs({ sel, kind }: { sel?: string; kind: string }) {
  const [q, setQ] = useState('');
  const [date, setDate] = useState('2026-11-10');
  const { data, error, loading, reload } = useAsync(() => api.jobs(kind, q, date), [kind, q, date]);
  const items: any[] = data?.items || [];
  const cur = sel || items.find(j => j.status === 'done')?.id;
  const to = (id: string) => go(`/jobs/${id}?kind=${kind}`);
  return (
    <>
      <Top title="剪辑记录" sub="所有用户生成的视频，每一条的 Token、费用和用时" />
      <div className="row wrap" style={{ padding: '16px 28px 0', gap: 10 }}>
        <span className="field"><Icon name="cal" size={16} color="#666A75" /><input type="date" value={date} onChange={e => setDate(e.target.value)} aria-label="日期" /></span>
        <Seg value={kind} onChange={v => go('/jobs?kind=' + v)} options={[{ v: 'all', label: '全部' }, { v: 'quick', label: '快讯' }, { v: 'deep', label: '深度解析' }]} />
        <span className="field" style={{ width: 240 }}><Icon name="search" size={16} color="#9AA2A8" /><input value={q} onChange={e => setQ(e.target.value)} placeholder="搜名字或标题" aria-label="搜名字或标题" /></span>
        <a className="btn ghost" style={{ marginLeft: 'auto' }} href={api.exportUrl(kind, q, date)} download><Icon name="dl" size={16} color="#6A55A0" />导出 CSV</a>
      </div>
      {data && <div className="row wrap small" style={{ padding: '12px 28px 0', gap: 24 }}>
        <span>共 <b className="num">{data.sum.count}</b> 条</span><span>Token <b className="num">{fmtNum(Math.round(data.sum.tokens))}</b></span>
        <span>AI 费用 <b className="num">US$ {data.sum.cost.toFixed(2)}</b></span><span>配音 <b className="num">{fmtNum(data.sum.voiceChars)}</b> 字</span><span>成片 <b>{data.sum.footage}</b></span></div>}
      <div className="body" style={{ paddingTop: 12 }}>
        <section className="card" style={{ flex: '1 1 0', minWidth: 0, overflowX: 'auto' }}>
          {loading && !data ? <Loading rows={8} /> : error ? <div className="pad"><ErrorBox error={error} retry={reload} /></div> : !items.length ? <Empty>没有符合条件的记录</Empty> : (
            <table className="t"><thead><tr><th>时间</th><th>用户</th><th>标题</th><th>类型 · 深度</th><th>状态</th><th className="r">成片</th><th className="r">用时</th><th className="r">Token</th><th className="r">US$</th></tr></thead>
              <tbody>{items.map(j => (
                <tr key={j.id} className={'click' + (j.id === cur ? ' sel' : '')} onClick={() => to(j.id)}>
                  <td className="num muted">{j.at}</td><td>{j.user}</td><td className="ttl" style={{ maxWidth: 160 }} title={j.title}>{j.title}</td>
                  <td><span className={'chip ' + (j.kind === 'deep' ? 'c-p' : j.kind === 'quick' ? 'c-g' : 'c-y')}>{j.kind === 'deep' ? '深度' : KIND[j.kind]}</span><div className="small muted">{j.depth}</div></td>
                  <td><StatusChip status={j.status} text={j.status === 'running' ? `生成中 ${j.progress}%` : undefined} /></td>
                  <td className="r num">{j.duration ? fmtClock(j.duration) : '—'}</td><td className="r num">{fmtClock(j.took)}</td>
                  <td className="r num b">{fmtNum(j.tokens)}</td><td className="r num">{j.cost.toFixed(2)}</td>
                </tr>))}</tbody></table>
          )}
        </section>
        <aside className="card col" style={{ flex: '0 0 420px', gap: 0, overflow: 'hidden' }}>{cur ? <Detail key={cur} id={cur} /> : <Empty>选一条</Empty>}</aside>
      </div>
    </>
  );
}

function Detail({ id }: { id: string }) {
  const { data: j, error, loading } = useAsync(() => api.job(id), [id]);
  const [log, setLog] = useState(false);
  if (loading) return <Loading rows={6} />;
  if (error) return <div className="pad"><ErrorBox error={error} /></div>;
  return (
    <>
      <div className="pad col" style={{ gap: 8, borderBottom: '1px solid var(--line)' }}>
        <span className="row" style={{ gap: 6 }}><StatusChip status={j.status} /><span className="chip c-p">{KIND[j.kind]}</span><span className="small muted" style={{ marginLeft: 'auto' }}>#{j.id}</span></span>
        <span style={{ fontSize: 16, lineHeight: '24px', fontWeight: 700 }}>{j.title}</span>
        <span className="small muted">{j.user} · {j.startedAt} 开始 · 用时 {fmtClock(j.took)} · {j.node}{j.duration ? ' · 成片 ' + fmtClock(j.duration) : ''}</span>
      </div>
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3,1fr)', borderBottom: '1px solid var(--line)' }}>
        <div className="kpi" style={{ padding: '12px 16px' }}><span className="lab">Token</span><span className="num b" style={{ fontSize: 19 }}>{fmtNum(j.tokens)}</span><span className="foot">入 {fmtNum(j.tokensIn)} · 出 {fmtNum(j.tokensOut)}</span></div>
        <div className="kpi" style={{ padding: '12px 16px', borderLeft: '1px solid var(--line2)' }}><span className="lab">费用</span><span className="num b" style={{ fontSize: 19 }}>US$ {j.cost.toFixed(2)}</span><span className="foot">≈ ฿ {(j.cost * 32.5).toFixed(1)}</span></div>
        <div className="kpi" style={{ padding: '12px 16px', borderLeft: '1px solid var(--line2)' }}><span className="lab">深度</span><span className="b" style={{ fontSize: 19 }}>{j.depthName}</span><span className="foot">{j.depth}</span></div>
      </div>
      <table className="t"><thead><tr><th>步骤</th><th className="r">用时</th><th className="r">输入</th><th className="r">输出</th></tr></thead>
        <tbody>{j.steps.map((s: any) => <tr key={s.name}><td><span className="row" style={{ gap: 8 }}><span style={{ width: 16, height: 16, borderRadius: 9999, background: 'var(--m)', display: 'flex', alignItems: 'center', justifyContent: 'center' }}><Icon name="check" size={10} color="#fff" sw={3} /></span>{s.name}</span></td>
          <td className="r num muted">{s.sec >= 60 ? Math.floor(s.sec / 60) + '分' + String(s.sec % 60).padStart(2, '0') + '秒' : s.sec + '秒'}</td><td className={'r num' + (s.in > 30000 ? ' b' : '')}>{s.in == null ? '—' : fmtNum(s.in)}</td><td className="r num">{s.out == null ? '—' : fmtNum(s.out)}</td></tr>)}</tbody></table>
      <div className="pad col" style={{ gap: 6, borderTop: '1px solid var(--line)' }}>
        <span className="small b">费用怎么算的</span>
        <div className="kv small">{j.costLines.map((c: string[]) => [<span key={c[0]}>{c[0]}</span>, <span key={c[0] + 'v'} className="num">{c[1]}</span>])}</div>
      </div>
      {log && <pre className="small" style={{ margin: '0 20px', padding: 12, background: 'var(--bg)', borderRadius: 10, whiteSpace: 'pre-wrap' }}>{j.log.join('\n')}</pre>}
      <div className="row" style={{ padding: '12px 20px 18px', marginTop: 'auto' }}><button className="btn"><Icon name="play" size={14} />看成片</button><button className="btn ghost" onClick={() => setLog(!log)}><Icon name="doc" size={16} color="#6A55A0" />{log ? '收起日志' : '日志'}</button></div>
    </>
  );
}
