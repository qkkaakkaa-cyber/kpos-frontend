// 员工用量：每个人做了多少、花了多少；右边单独设额度
import { useEffect, useState } from 'react';
import { Icon } from '../../shared/icons';
import { go } from '../../shared/router';
import { ErrorBox, fmtK, Loading, Seg, useAsync, useToast } from '../../shared/ui';
import { api } from '../api';
import { Top } from '../App';

export function Usage({ sel }: { sel: number }) {
  const { data, error, loading, reload } = useAsync(() => api.usage(), []);
  const [role, setRole] = useState('all');
  const [q, setQ] = useState('');
  if (loading && !data) return <><Top title="员工用量" /><Loading rows={8} /></>;
  if (error) return <><Top title="员工用量" /><div className="body"><ErrorBox error={error} retry={reload} /></div></>;
  const all: any[] = data.items.slice().sort((a: any, b: any) => b.tokens - a.tokens);
  const list = all.filter(s => (role === 'all' || (role === 'off' ? s.status === 'off' : s.role === role)) && (!q || s.name.includes(q) || s.code.includes(q.toUpperCase())));
  const cur = all.find(s => s.id === sel) || all[0];
  const cnt = (r: string) => all.filter(s => r === 'off' ? s.status === 'off' : s.role === r).length;
  const today = (s: any) => { const l = { ...data.roles[s.role], ...s.quota }; return l.quick == null ? '不限' : `${s.today[0]}/${l.quick} · ${s.today[1]}/${l.deep}`; };
  return (
    <>
      <Top title="员工用量" sub="本月 11-01 至 11-10 · 每个人做了多少、花了多少" />
      <div className="row wrap" style={{ padding: '16px 28px 0', gap: 10 }}>
        <Seg value={role} onChange={setRole} options={[{ v: 'all', label: `全部 ${all.length}` }, { v: 'editor', label: `编辑 ${cnt('editor')}` }, { v: 'intern', label: `实习编辑 ${cnt('intern')}` }, { v: 'chief', label: `主编 ${cnt('chief')}` }, { v: 'off', label: `已停用 ${cnt('off')}` }]} />
        <span className="field" style={{ width: 220 }}><Icon name="search" size={16} color="#9AA2A8" /><input value={q} onChange={e => setQ(e.target.value)} placeholder="名字、工号" aria-label="搜名字、工号" /></span>
        <span className="small muted" style={{ marginLeft: 'auto' }}>按本月 Token 排序</span>
      </div>
      <div className="body" style={{ paddingTop: 12 }}>
        <section className="card" style={{ flex: '1 1 0', minWidth: 0, overflowX: 'auto' }}>
          <table className="t"><thead><tr><th>用户</th><th>身份</th><th>状态</th><th className="r">快讯 · 深度</th><th className="r">本月 Token</th><th className="r">US$</th><th>今天额度</th></tr></thead>
            <tbody>{list.map(s => (
              <tr key={s.id} className={'click' + (s.id === cur?.id ? ' sel' : '')} onClick={() => go('/usage/' + s.id)}>
                <td><span className="row" style={{ gap: 8 }}><span className="av sm">{s.name.slice(0, 1)}</span><span className="col" style={{ gap: 0, lineHeight: '18px' }}><b>{s.name}</b><span className="small muted">{s.code}</span></span></span></td>
                <td>{s.roleName}</td><td><span className={'chip ' + (s.status === 'off' ? 'c-r' : s.today[0] >= (data.roles[s.role].quick ?? 1e9) ? 'c-w' : 'c-m')}>{s.status === 'off' ? '已停用' : s.today[0] >= (data.roles[s.role].quick ?? 1e9) ? '额度用完' : '正常'}</span></td>
                <td className="r num">{s.quick} · {s.deep}</td><td className="r num b">{fmtK(s.tokens)}</td><td className="r num">{s.cost.toFixed(2)}</td><td className="small muted num">{today(s)}<div>最近 {s.last.split(' · ')[0]}</div></td>
              </tr>))}</tbody></table>
        </section>
        {cur && <Person key={cur.id} s={cur} daily={data.daily} roles={data.roles} onSaved={reload} />}
      </div>
    </>
  );
}

function Person({ s, daily, roles, onSaved }: { s: any; daily: number[]; roles: any; onSaved: () => void }) {
  const toast = useToast();
  const [qt, setQt] = useState({ quick: '', deep: '', monthCost: '', maxDepth: 'standard', ...Object.fromEntries(Object.entries(s.quota).map(([k, v]) => [k, String(v)])) });
  useEffect(() => { }, [s.id]);
  const mx = Math.max(...daily);
  const deepPct = s.quick + s.deep ? Math.round(s.deep / (s.quick + s.deep) * 100) : 0;
  const def = roles[s.role];
  async function save() {
    const num = (v: string) => v === '' ? null : Number(v);
    try { await api.updateStaff(s.id, { quota: { quick: num(qt.quick), deep: num(qt.deep), monthCost: num(qt.monthCost), maxDepth: qt.maxDepth } }); toast('已保存'); onSaved(); } catch (e: any) { toast(e.message); }
  }
  return (
    <aside className="card pad col" style={{ flex: '0 0 360px', gap: 16 }}>
      <div className="row" style={{ gap: 12 }}><span className="av" style={{ width: 44, height: 44, fontSize: 16 }}>{s.name.slice(0, 1)}</span><span className="col" style={{ gap: 0 }}><b style={{ fontSize: 17 }}>{s.name}</b><span className="small muted">{s.roleName} · 工号 {s.code} · {s.joined} 入职</span></span></div>
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3,1fr)', gap: 8 }}>
        {[['本月视频', s.quick + s.deep], ['Token', fmtK(s.tokens)], ['费用', '$' + s.cost.toFixed(2)]].map(([a, b]) => <div key={a} style={{ padding: '10px 12px', borderRadius: 10, background: 'var(--bg)' }}><span className="small muted">{a}</span><div className="num b" style={{ fontSize: 18 }}>{b}</div></div>)}
      </div>
      <div className="col" style={{ gap: 8 }}>
        <span className="row small" style={{ justifyContent: 'space-between' }}><b>近 30 天每天 Token</b><span className="muted">最高 {mx}K</span></span>
        <div style={{ height: 80, display: 'flex', alignItems: 'flex-end', gap: 2, borderBottom: '1px solid var(--line)' }}>
          {daily.map((v, i) => <span key={i} title={`${i + 1} 日 ${v}K`} style={{ flex: 1, height: Math.max(2, v / mx * 100) + '%', borderRadius: '3px 3px 0 0', background: i === daily.length - 1 ? '#6A55A0' : v ? '#B9AEDB' : '#E3E7EA' }} />)}
        </div>
        <span className="row small muted" style={{ justifyContent: 'space-between' }}><span>30 天前</span><span>今天</span></span>
      </div>
      <div className="col" style={{ gap: 8 }}><span className="small b">快讯和深度</span>
        <div className="bar" style={{ height: 12 }}><i style={{ width: 100 - deepPct + '%', background: '#B9AEDB' }} /><i style={{ width: deepPct + '%', background: '#6A55A0', borderLeft: deepPct ? '2px solid #fff' : 0 }} /></div>
        <span className="row small" style={{ justifyContent: 'space-between' }}><span>快讯 {s.quick} 条</span><span>深度 {s.deep} 条</span></span></div>
      <div className="hr" />
      <div className="col" style={{ gap: 10 }}><span className="small b">这个人的额度 <span className="muted" style={{ fontWeight: 500 }}>（不填就用{s.roleName}默认：快讯 {def.quick ?? '不限'} · 深度 {def.deep ?? '不限'}）</span></span>
        <div style={{ display: 'grid', gridTemplateColumns: '1fr auto', gap: '8px 12px', alignItems: 'center', fontSize: 13 }}>
          <span>每天快讯</span><span><input className="in num" value={qt.quick} placeholder={String(def.quick ?? '不限')} onChange={e => setQt({ ...qt, quick: e.target.value.replace(/\D/g, '') })} style={{ width: 64, height: 34 }} aria-label="每天快讯" /> 条</span>
          <span>每天深度解析</span><span><input className="in num" value={qt.deep} placeholder={String(def.deep ?? '不限')} onChange={e => setQt({ ...qt, deep: e.target.value.replace(/\D/g, '') })} style={{ width: 64, height: 34 }} aria-label="每天深度解析" /> 条</span>
          <span>每月费用上限</span><span>US$ <input className="in num" value={qt.monthCost} placeholder="不限" onChange={e => setQt({ ...qt, monthCost: e.target.value.replace(/[^\d.]/g, '') })} style={{ width: 64, height: 34 }} aria-label="每月费用上限" /></span>
          <span>允许的最高深度</span><Seg value={qt.maxDepth} onChange={v => setQt({ ...qt, maxDepth: v })} options={[{ v: 'standard', label: '标准' }, { v: 'deep', label: '深入' }]} />
        </div></div>
      <div className="row" style={{ marginTop: 'auto' }}>
        <button className="btn" onClick={save}>保存</button>
        <button className="btn ghost" onClick={() => go('/jobs?kind=all')}>看 TA 的剪辑记录</button>
        <button className="btn warn" style={{ marginLeft: 'auto' }} disabled={s.status === 'off'} onClick={async () => { try { await api.staffAction(s.id, 'disable'); toast('已停用'); onSaved(); } catch (e: any) { toast(e.message); } }}>停用</button>
      </div>
    </aside>
  );
}
