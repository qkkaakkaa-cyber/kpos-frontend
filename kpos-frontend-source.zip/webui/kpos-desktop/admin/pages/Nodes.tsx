// 剪辑机与队列
import { Icon } from '../../shared/icons';
import { ErrorBox, KIND, Loading, useAsync, useInterval, useToast } from '../../shared/ui';
import { api } from '../api';
import { Top } from '../App';

const ST: Record<string, [string, string]> = { busy: ['工作中', 'c-m'], retry: ['重试中', 'c-w'], idle: ['空闲', 'c-g'], off: ['离线', 'c-r'] };

export function Nodes() {
  const toast = useToast();
  const { data, error, loading, reload, setData } = useAsync(() => api.nodes(), []);
  useInterval(() => api.nodes().then(setData).catch(() => {}), 10000);
  if (loading && !data) return <><Top title="剪辑机与队列" /><Loading rows={6} /></>;
  if (error) return <><Top title="剪辑机与队列" /><div className="body"><ErrorBox error={error} retry={reload} /></div></>;
  const full = data.nodes.find((x: any) => x.disk >= 85);
  async function q(id: string, a: 'up' | 'cancel') { try { setData(await api.queueAct(id, a)); toast(a === 'up' ? '已提前' : '已取消'); } catch (e: any) { toast(e.message); } }
  async function rule(k: string, v: string) { try { const r = await api.queueRules({ [k]: Number(v.replace(/\D/g, '') || 0) }); setData({ ...data, rules: r }); } catch (e: any) { toast(e.message); } }
  return (
    <>
      <Top title="剪辑机与队列" sub="视频在自己的剪辑机上合成；AI 只负责文案和查资料" right={<button className="btn ghost" onClick={reload}><Icon name="refresh" size={16} color="#6A55A0" />刷新</button>} />
      <div className="col" style={{ padding: '24px 28px', gap: 16 }}>
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(280px, 1fr))', gap: 16 }}>
          {data.nodes.map((nd: any) => (
            <section key={nd.id} className="card pad col" style={{ gap: 14 }}>
              <div className="row"><span className="av m" style={{ width: 36, height: 36 }}><Icon name="cpu" size={18} /></span><span className="col" style={{ gap: 0, lineHeight: '18px' }}><b style={{ fontSize: 15 }}>{nd.name}</b><span className="small muted">{nd.hw}</span></span>
                <span className={'chip ' + ST[nd.status][1]} style={{ marginLeft: 'auto' }}><span className="dot" style={{ background: 'currentColor', width: 6, height: 6 }} />{ST[nd.status][0]}</span></div>
              {nd.job ? <div className="col" style={{ gap: 6 }}><span className="small muted">正在做</span><span className="sb" style={{ fontSize: 13 }}>{nd.job}</span><div className="bar"><i style={{ width: nd.pct + '%', background: 'var(--p)' }} /></div></div> : <div className="small muted" style={{ padding: '14px 0' }}>空闲，等下一条</div>}
              <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3,1fr)', gap: 12 }}>
                {[['CPU', nd.cpu], ['GPU', nd.gpu], ['硬盘', nd.disk]].map(([k, v]) => <div key={k} className="col" style={{ gap: 4 }}><span className="row small" style={{ justifyContent: 'space-between' }}><span className="muted">{k}</span><span className="num">{v}%</span></span><div className="bar" style={{ height: 6 }}><i style={{ width: v + '%', background: v > 85 ? 'var(--r)' : 'var(--m)' }} /></div></div>)}
              </div>
              <div className="row small muted" style={{ justifyContent: 'space-between' }}><span>今天完成 <b style={{ color: 'var(--ink)' }} className="num">{nd.done}</b> 条</span><span>心跳 3 秒前</span></div>
            </section>
          ))}
        </div>
        <div className="body" style={{ padding: 0 }}>
          <section className="card col" style={{ flex: '1 1 0', gap: 0, overflow: 'hidden' }}>
            <div className="pad row" style={{ paddingBottom: 10 }}><span className="h2">排队中 · {data.queue.length} 条</span><span className="small muted" style={{ marginLeft: 'auto' }}>主编优先；同一个人同时最多 {data.rules.perUser} 条（剪辑中 + 排队）</span></div>
            {data.queue.length ? <table className="t"><thead><tr><th>#</th><th>用户</th><th>标题</th><th>类型</th><th>预计开始</th><th>剪辑机</th><th></th></tr></thead>
              <tbody>{data.queue.map((x: any, i: number) => <tr key={x.id}><td className="num b">{i + 1}</td><td>{x.user}</td><td className="ttl">{x.title}</td><td><span className={'chip ' + (x.kind === 'deep' ? 'c-p' : 'c-g')}>{x.kind === 'deep' ? '深度' : KIND[x.kind]}</span></td><td className="muted">{x.eta}</td><td className="muted">{x.node}</td>
                <td className="r">{i > 0 && <><button className="back small" onClick={() => q(x.id, 'up')}>提前</button> · </>}<button className="back small" style={{ color: 'var(--w-deep)' }} onClick={() => q(x.id, 'cancel')}>取消</button></td></tr>)}</tbody></table>
              : <div className="empty">没有排队的</div>}
          </section>
          <section className="card pad col" style={{ flex: '0 0 400px', gap: 6 }}>
            <span className="h2">队列规则</span>
            {[['perNode', '每台同时剪', '条'], ['alertMin', '排队超过多久提醒', '分钟'], ['retries', '失败自动重试', '次'], ['keepDays', '成片保留', '天'], ['perUser', '每人同时最多', '条']].map(([k, l, u]) => (
              <div key={k} className="row" style={{ padding: '10px 0', borderBottom: '1px solid var(--line2)' }}><span className="grow sb" style={{ fontSize: 13 }}>{l}{k === 'keepDays' && <div className="small muted" style={{ fontWeight: 500 }}>到期自动删，记录和 Token 数据一直保留</div>}</span>
                <input className="in num" defaultValue={data.rules[k]} onBlur={e => rule(k, e.target.value)} style={{ width: 56, height: 34 }} aria-label={l} /><span style={{ fontSize: 13 }}>{u}</span></div>
            ))}
            {full && <div className="note" style={{ marginTop: 10 }}>{full.name} 硬盘用了 {full.disk}%，建议清理 30 天前的素材缓存。</div>}
          </section>
        </div>
      </div>
    </>
  );
}
