// 深度与模型：快讯 / 深度解析 / 深入查多深，每一步用哪个模型，预算
import { useEffect, useState } from 'react';
import { ErrorBox, fmtNum, Loading, Seg, useAsync, useToast } from '../../shared/ui';
import { api } from '../api';
import { Top } from '../App';

export function Depth() {
  const toast = useToast();
  const { data, error, loading, reload } = useAsync(() => api.depth(), []);
  const [d, setD] = useState<any>(null);
  useEffect(() => { if (data) setD(JSON.parse(JSON.stringify(data))); }, [data]);
  if ((loading && !data) || !d) return <><Top title="深度与模型" /><Loading rows={6} /></>;
  if (error) return <><Top title="深度与模型" /><div className="body"><ErrorBox error={error} retry={reload} /></div></>;
  const dirty = JSON.stringify(d) !== JSON.stringify(data);
  const set = (path: string, v: any) => { const n = JSON.parse(JSON.stringify(d)); const ks = path.split('.'); let o = n; ks.slice(0, -1).forEach(k => o = o[k]); o[ks[ks.length - 1]] = v; setD(n); };
  const n = (path: string, unit: string, w = 60) => { const v = path.split('.').reduce((o: any, k) => o[k], d); return <span className="row" style={{ gap: 6, fontSize: 13 }}><input className="in num" value={v} onChange={e => set(path, e.target.value)} style={{ width: w, height: 34 }} aria-label={unit} />{unit}</span>; };
  // 深度解析预计：每多 1 篇约 +6,000 Token
  const deepTok = 72000 + (Number(d.deep.articles) - 6) * 6000;
  return (
    <>
      <Top title="深度与模型" sub="每种视频查多少、用哪个模型、一条大概花多少钱" right={<button className="btn" disabled={!dirty} onClick={async () => { try { await api.saveDepth(d); toast('已保存，新提交的任务按新设置做'); reload(); } catch (e: any) { toast(e.message); } }}>保存修改</button>} />
      <div className="col" style={{ padding: '24px 28px', gap: 16 }}>
        <div className="body" style={{ padding: 0, alignItems: 'stretch' }}>
          <section className="card pad col" style={{ flex: '1 1 0', gap: 6 }}>
            <div className="row"><span className="h2">快讯</span><span className="chip c-g">1分钟内</span></div>
            <Row l="成片长度" c={n('quick.maxSec', '秒以内')} />
            <Row l="改写方式" c={<Seg value={d.quick.rewrite} onChange={v => set('quick.rewrite', v)} options={[{ v: 'plain', label: '按原文改写' }, { v: 'bg', label: '加一句背景' }]} />} />
            <Row l="查来龙去脉" c={<span className="small muted">不查</span>} /><Row l="现场视频" c={<span className="small muted">不找，用配图</span>} />
            <Row l="核对事实" c={<Seg value={d.quick.check} onChange={v => set('quick.check', v)} options={[{ v: 'sensitive', label: '只查敏感词' }, { v: 'full', label: '全文核对' }]} />} />
            <div className="tip row small" style={{ marginTop: 8, gap: 18 }}><span>预计每条 <b className="num">{fmtNum(d.quick.tokens)}</b> Token</span><span>约 <b>US$ {d.quick.cost}</b></span></div>
          </section>
          <section className="card pad col" style={{ flex: '1 1 0', gap: 6 }}>
            <div className="row"><span className="h2">深度解析</span><span className="chip c-p">2到3分钟</span></div>
            <Row l="成片长度" h="内容少会自动缩短" c={n('deep.minutes', '分钟', 64)} />
            <Row l="查来龙去脉" h="最多 10 篇；每多 1 篇约 +6,000 Token" c={n('deep.articles', '篇相关报道')} />
            <Row l="往前查多久" c={n('deep.days', '天')} /><Row l="现场视频" c={n('deep.videos', '段')} />
            <Row l="交叉核对媒体" h="少于这么多家报道的内容不写进文案" c={n('deep.crossCheck', '家以上')} />
            <Row l="核对事实" c={<Seg value={d.deep.check} onChange={v => set('deep.check', v)} options={[{ v: 'sensitive', label: '只查敏感词' }, { v: 'full', label: '全文核对' }]} />} />
            <div className="tip row small" style={{ marginTop: 8, gap: 18 }}><span>预计每条 <b className="num">{fmtNum(deepTok)}</b> Token</span><span>约 <b>US$ {(deepTok / 72000 * 0.52).toFixed(2)}</b></span></div>
          </section>
          <section className="card pad col" style={{ flex: '0 0 300px', gap: 10 }}>
            <div className="row"><span className="h2">深入</span><span className="chip c-y">只给主编</span></div>
            <span className="small muted">深度解析的加强档：查 {d.deeper.articles} 篇、往前 1 年、配专家观点和数据图。</span>
            <div className="kv small"><span>报道</span><span>{d.deeper.articles} 篇</span><span>往前</span><span>{d.deeper.days} 天</span><span>现场视频</span><span>{d.deeper.videos} 段</span><span>数据图</span><span>{d.deeper.charts}</span></div>
            <div className="small" style={{ padding: '12px 14px', borderRadius: 10, background: 'var(--y-soft)', color: 'var(--y-deep)' }}>预计每条 <b>{fmtNum(d.deeper.tokens)}</b> Token · 约 <b>US$ {d.deeper.cost}</b><br />生成用时约 15 分钟</div>
            <span className="small muted">在「员工用量」里可以单独给某个编辑开。</span>
          </section>
        </div>
        <div className="body" style={{ padding: 0 }}>
          <section className="card col" style={{ flex: '1 1 0', gap: 0, overflow: 'hidden' }}>
            <div className="pad row" style={{ paddingBottom: 10 }}><span className="h2">每一步用哪个模型</span><span className="small muted" style={{ marginLeft: 'auto' }}>单价：美元 / 每百万 Token，按你们的合同价填</span></div>
            <table className="t"><thead><tr><th>步骤</th><th>模型</th><th className="r">输入</th><th className="r">输出</th></tr></thead>
              <tbody>{d.models.map((m: any, i: number) => <tr key={m.step}><td><b>{m.step}</b>{m.note && <div className="small muted">{m.note}</div>}</td>
                <td><select className="in" value={m.model} onChange={e => set(`models.${i}.model`, e.target.value)} style={{ height: 34, fontSize: 13 }}>{['Claude Haiku', 'Claude Sonnet', 'Claude Opus'].map(x => <option key={x}>{x}</option>)}</select></td>
                <td className="r"><input className="in num" value={m.in} onChange={e => set(`models.${i}.in`, e.target.value)} style={{ width: 60, height: 34 }} aria-label="输入单价" /></td>
                <td className="r"><input className="in num" value={m.out} onChange={e => set(`models.${i}.out`, e.target.value)} style={{ width: 60, height: 34 }} aria-label="输出单价" /></td></tr>)}</tbody></table>
          </section>
          <section className="card pad col" style={{ flex: '0 0 400px', gap: 6 }}>
            <span className="h2">预算和提醒</span>
            <Row l="每天 AI 费用预算" c={n('budget.day', 'US$')} /><Row l="每月预算" c={n('budget.month', 'US$')} />
            <Row l="用到多少提醒" h="发到管理员手机和邮箱" c={n('budget.alertPct', '%')} />
            <Row l="超过预算后" c={<Seg value={d.budget.over} onChange={v => set('budget.over', v)} options={[{ v: 'chief', label: '只让主编做' }, { v: 'stop', label: '全部暂停' }]} />} />
            <Row l="配音单价" c={n('budget.voicePrice', 'US$/千字', 56)} /><Row l="汇率" c={n('budget.fx', '฿ / US$', 56)} />
            <span className="small muted" style={{ paddingTop: 6 }}>模型的 Key 在服务器上配置，这里不显示。</span>
          </section>
        </div>
      </div>
    </>
  );
}

function Row({ l, h, c }: { l: string; h?: string; c: any }) {
  return <div className="row" style={{ padding: '10px 0', borderBottom: '1px solid var(--line2)' }}><span className="col grow" style={{ gap: 0 }}><span className="sb" style={{ fontSize: 13 }}>{l}</span>{h && <span className="small muted">{h}</span>}</span>{c}</div>;
}
