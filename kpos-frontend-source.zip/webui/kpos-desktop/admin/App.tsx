// 总后台：深紫色侧栏。登录也用工号，但只有管理员能进
import { useEffect, useState, type FormEvent, type ReactNode } from 'react';
import { Icon, KMark } from '../shared/icons';
import { go, Link, useRoute } from '../shared/router';
import { ToastHost } from '../shared/ui';
import { api, http, type AdminMe } from './api';
import { Overview } from './pages/Overview';
import { AdminJobs } from './pages/Jobs';
import { Usage } from './pages/Usage';
import { Workspaces } from './pages/Workspaces';
import { Accounts } from './pages/Accounts';
import { Depth } from './pages/Depth';
import { Nodes } from './pages/Nodes';

const NAV: (null | [string, string, string, string])[] = [
  null, ['overview', 'gauge', '概览', '/overview'], ['jobs', 'film', '剪辑记录', '/jobs'], ['usage', 'users', '员工用量', '/usage'],
  null, ['workspaces', 'globe', '国家工作区', '/workspaces'], ['accounts', 'shield', '员工账号', '/accounts'], ['depth', 'layers', '深度与模型', '/depth'], ['nodes', 'cpu', '剪辑机与队列', '/nodes'],
];

export function AdminApp() {
  const [me, setMe] = useState<AdminMe | null>(null);
  const [ready, setReady] = useState(false);
  const { path, query } = useRoute();
  useEffect(() => {
    if (!http.getToken()) { setReady(true); return; }
    api.me().then(setMe).catch(() => http.setToken(null)).finally(() => setReady(true));
  }, []);
  useEffect(() => { if (ready && !me && path !== '/login') go('/login'); if (ready && me && (path === '/' || path === '/login')) go('/overview'); }, [ready, me, path]);
  if (!ready) return null;

  let page: ReactNode, key = path.split('/')[1] || 'overview';
  switch (key) {
    case 'jobs': page = <AdminJobs sel={path.split('/')[2]} kind={query.get('kind') || 'all'} />; break;
    case 'usage': page = <Usage sel={Number(path.split('/')[2]) || 0} />; break;
    case 'workspaces': page = <Workspaces />; break;
    case 'accounts': page = <Accounts />; break;
    case 'depth': page = <Depth />; break;
    case 'nodes': page = <Nodes />; break;
    default: key = 'overview'; page = <Overview range={query.get('range') || 'today'} />;
  }
  return (
    <ToastHost>
      {!me || path === '/login' ? <AdminLogin onIn={setMe} /> : (
        <div className="app">
          <aside className="side adm" aria-label="总后台菜单">
            <div className="brand"><KMark bg="#FFFFFF" fg="#2E2552" /><span>KPOS<small>中文社传媒 · 总后台</small></span></div>
            {NAV.map((n, i) => n === null
              ? <div key={i}><div className="navgap" /><div className="navlabel">{i === 0 ? '看数据' : '管理'}</div></div>
              : <Link key={n[0]} to={n[3]} className={'nav' + (key === n[0] ? ' on' : '')}><Icon name={n[1]} />{n[2]}</Link>)}
            <button className="nav" style={{ marginTop: 'auto' }} onClick={() => { api.logout().finally(() => { http.setToken(null); setMe(null); go('/login'); }); }}><Icon name="logout" />退出</button>
          </aside>
          <div className="main">{page}</div>
        </div>
      )}
    </ToastHost>
  );
}

/** 顶栏：标题、说明、右边按钮和管理员名字 */
export function Top({ title, sub, right }: { title: string; sub?: string; right?: ReactNode }) {
  return <header className="top"><h1>{title}</h1>{sub && <span className="sub">{sub}</span>}<div className="right">{right}<span className="who"><span className="av">管</span>管理员</span></div></header>;
}

function AdminLogin({ onIn }: { onIn: (m: AdminMe) => void }) {
  const [code, setCode] = useState('');
  const [show, setShow] = useState(false);
  const [err, setErr] = useState('');
  async function submit(e: FormEvent) {
    e.preventDefault();
    try { const r = await api.login(code); http.setToken(r.token); onIn(r.me); go('/overview'); } catch (er: any) { setErr(er.message); setCode(''); }
  }
  return (
    <div style={{ minHeight: '100vh', display: 'flex', alignItems: 'center', justifyContent: 'center', background: 'var(--p-dark)', padding: 16 }}>
      <form onSubmit={submit} className="card col" style={{ width: 400, maxWidth: '100%', padding: 32, gap: 18 }}>
        <div className="row" style={{ gap: 12 }}><KMark size={40} /><span className="col" style={{ gap: 0 }}><b style={{ fontSize: 20, letterSpacing: '.04em' }}>KPOS 总后台</b><span className="small muted">中文社传媒 · 只给管理员</span></span></div>
        <label className="col" style={{ gap: 6, fontWeight: 600 }}>管理员工号
          <span style={{ height: 52, border: '2px solid ' + (err ? 'var(--r)' : 'var(--p)'), borderRadius: 10, padding: '0 6px 0 14px', display: 'flex', alignItems: 'center', gap: 10 }}>
            <b className="num" style={{ fontSize: 18, color: 'var(--p-deep)' }}>MK</b><span style={{ width: 1, height: 22, background: 'var(--line)' }} />
            <input type={show ? 'text' : 'password'} inputMode="numeric" autoComplete="off" autoFocus maxLength={7} value={code} aria-label="工号（MK 后面的 7 位数字）"
              onChange={e => { setCode(e.target.value.replace(/\D/g, '').slice(0, 7)); setErr(''); }} style={{ flex: 1, minWidth: 0, border: 0, outline: 0, fontSize: 20, letterSpacing: '.35em' }} />
            <button type="button" aria-label={show ? '隐藏工号' : '显示工号'} onClick={() => setShow(!show)} style={{ width: 40, height: 40, border: 0, background: 'none', color: 'var(--grey)' }}><Icon name={show ? 'eyeoff' : 'eye'} /></button>
          </span>
          {err && <span className="small" style={{ color: 'var(--r)' }} role="alert">{err}</span>}
        </label>
        <button className="btn lg" disabled={code.length !== 7}>进入总后台</button>
        <span className="small muted">员工端在 kpos.com；总后台单独的地址，只能在公司网络或 VPN 下打开。</span>
        {__MOCK__ && <span className="small faint">演示管理员工号：0000001</span>}
      </form>
    </div>
  );
}
