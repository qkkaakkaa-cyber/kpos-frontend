# KPOS 前端（kpos.com）

中文社传媒内部的新闻视频剪辑系统。分两个，**分开打包、分开部署**：

| | 目录 | 给谁用 | 打包到 | 接口前缀 |
|---|---|---|---|---|
| 员工端 | `app/` | 编辑、主编（工号登录） | `dist/app` → kpos.com | `/api` |
| 总后台 | `admin/` | 只给管理员工号 | `dist/admin` → 建议 admin.kpos.com | `/admin-api` |

界面和画布「泰国中文社 App 界面 → KPOS（电脑版）」一致。React 18 + TypeScript + Vite，没有用别的界面库。

## 本地跑起来

```bash
npm install
npm run dev:mock          # 员工端，演示数据，不用后端  http://localhost:5173
npm run dev:admin:mock    # 总后台，演示数据             http://localhost:5174
```

演示工号（只在演示模式有效）：

- 员工端：`0217345` 编辑（泰国）、`0102001` 主编（泰国 + 大马，右上角能切换）、`0230888` 实习编辑（不能做深度）
- 总后台：`0000001` 管理员；用编辑的工号会提示「不是管理员」

连真后端：把 `.env.example` 复制成 `.env`，`VITE_MOCK=0`，`VITE_API_PROXY` 填后端地址，然后 `npm run dev` / `npm run dev:admin`。

打包：`npm run build`，产物在 `dist/app` 和 `dist/admin`。都是静态文件，前面用 Nginx 托管，`/api`、`/admin-api` 反向代理到后端。

## 页面

员工端（左侧菜单）

- **新闻** `#/news`：中文社 / 外站新闻列表（推荐关注、24 小时热门、一周热门、华人、社会、深度话题、最新），每页 20 条；列表上直接点「快讯」「深度」生成；原图少于 2 张的不能剪视频；贴链接点「打开」进工作台
- **工作台** `#/work/:id`：左边文章，右边「做视频」（快讯 / 深度解析、深度提示、制作选项）和「做图文」（来龙去脉、一键找图、分享文案）
- **生成中** `#/progress/:id`：进度、三个阶段、口播文案、「不做了」
- **深度稿审阅** `#/review/:id`：深度解析写好稿子后停下来等确认；改稿、和原稿对比、只重写一段、自动检查、时间线、来源、审阅链接和留言；「确认出片」后才配音剪辑
- **生成记录** `#/jobs`：今天 / 昨天，全部 / 进行中 / 失败；右边大预览、下载视频、复制标题、改口播、换画面（本地图片 / 一键找到的图 / 删掉）、分享图文
- **公众号剪辑** `#/wechat`、**智能剪辑** `#/smart`、**手动上传** `#/upload`、**我的** `#/me`

总后台（深紫色侧栏）

- **概览**：剪辑量、成功率、Token、AI 费用、剪辑机；近 14 天 Token 按用途堆叠（鼠标移上去看数字，可切表格）；平均每条；用得最多的人；失败和异常
- **剪辑记录**：日期、全部 / 快讯 / 深度解析、搜名字或标题、导出 CSV；右边每一步的用时和输入 / 输出 Token、费用怎么算的、日志
- **员工用量**：每个人本月快讯 · 深度、Token、费用、今天额度；单独设额度和允许的最高深度、停用
- **国家工作区**：泰国 / 大马 / 越南；越南版搬进来的 5 个步骤；越南写稿规则
- **员工账号**：开工号（完整工号只显示一次）、踢下线、停用 / 启用、角色默认额度、登录安全
- **深度与模型**：快讯 / 深度解析 / 深入查多深，预计每条 Token 和费用；每一步用哪个模型和单价；预算和提醒
- **剪辑机与队列**：每台在做什么、CPU / GPU / 硬盘；排队提前、取消；队列规则

## 后端要做的事（安全相关，前端挡不住）

1. **工号就是凭证，没有密码**。登录接口只在公司网络 / VPN 的 IP 段开放；连续输错 5 次锁这台电脑 15 分钟并通知管理员；同一个工号最多同时在 N 台电脑登录。
2. 员工端接口**不能返回**模型名、Token、费用、剪辑机名、日志、完整工号——这些只在 `/admin-api`。
3. `/admin-api` 每个接口都要再查一次是不是管理员，不能只靠前端菜单。总后台最好单独域名，并且只在内网开放。
4. 额度（每天快讯 / 深度条数、同时最多 5 条）、原图少于 2 张不能剪、深度稿确认后锁定，**都要后端再判断一次**，前端只是提前提示。
5. 模型和服务的 Key 只在服务器上配置，总后台也不显示。

## 接口一览

所有接口返回 JSON；出错时 HTTP 状态码 + `{ "message": "给人看的中文" }`，前端直接把 message 显示出来。401 会回到登录页。字段格式见 `app/types.ts`。

员工端 `/api`（请求头 `Authorization: Bearer <token>`）

| 方法 | 路径 | 说明 |
|---|---|---|
| POST | `/auth/login` | `{code: "0217345", remember}` → `{token, me}`；401 工号不对、423 已锁定 |
| POST | `/auth/logout` | |
| GET | `/me` | 名字、角色、`codeMask`、当前工作区、能切换的工作区 |
| POST | `/me/workspace` | `{id}` 切换工作区 |
| GET | `/queue` | 进行中 / 排队、上限、今天额度（左下角卡片，3 秒轮询） |
| GET / PUT | `/prefs` | 记住的制作选项 |
| GET | `/news?tab=&page=&source=site\|foreign` | 新闻列表，带 `images` 原图张数 |
| POST | `/news/resolve` | `{url}` → `{id}`，贴链接进工作台 |
| GET | `/articles/:id`、`/articles/:id/story` | 文章；来龙去脉、找图、时间线 |
| POST | `/jobs` | `{kind: quick\|deep, articleId, hint?, prefs}`；429 额度用完或同时 5 条已满 |
| GET | `/jobs?filter=all\|active\|failed`、`/jobs/:id` | |
| POST | `/jobs/:id/cancel`、`/retry`、`/regenerate` | regenerate 带 `{script, scenes}` 改动 |
| GET / PUT | `/jobs/:id/draft` | 深度稿：`{paras: {key: 文本}}`、`{canEdit}`、`{comment}` |
| POST | `/jobs/:id/rewrite`、`/jobs/:id/confirm` | 只重写一段；确认出片 |
| POST | `/wechat/extract` · GET `/wechat/recent` | 公众号文章，最多 5 条 |
| POST | `/smart/search`、`/smart/jobs` | 智能剪辑 |
| POST | `/uploads`（multipart）、`/upload/jobs` | 手动上传：先传素材拿 id，再提交 |

总后台 `/admin-api`：`/auth/login`、`/me`、`/overview?range=today|7d|30d|month`、`/jobs`、`/jobs/:id`、`/jobs.csv`、`/usage`、`/staff`（GET 列表 / POST 开工号）、`/staff/:id`（PUT 额度、工作区、角色）、`/staff/:id/kick|disable|enable`、`/security`、`/roles`、`/workspaces`、`/workspaces/vn/steps/:i`、`/depth`、`/nodes`、`/queue/rules`、`/queue/:id/up|cancel`。返回格式照 `admin/mock.ts`。

## 演示数据

`app/mock.ts`、`admin/mock.ts` 只在演示模式用，规则照真的来：工号 7 位、输错 5 次锁定、同时最多 5 条、原图少于 2 张不能剪、深度稿写好后停下来等确认、实习编辑不能做深度。任务进度按时间往前走（快讯 1 分钟、深度 2 分钟），方便看效果。正式打包（`VITE_MOCK=0`）时演示数据不会生效。

`node scripts/preview.mjs 输出目录` 会生成两个单文件预览页（`app.html`、`admin.html`，演示数据），不装依赖也能打开看。
