// 生成两个单文件预览页（演示数据），给没装依赖时看界面用：node scripts/preview.mjs 输出目录 [esbuild 路径] [react 所在 node_modules]
import { execFileSync } from 'node:child_process';
import { mkdirSync, readFileSync, writeFileSync } from 'node:fs';
import { join, resolve } from 'node:path';

const out = process.argv[2] || 'preview';
const esbuild = process.argv[3] || 'node_modules/.bin/esbuild';
const nm = resolve(process.argv[4] || 'node_modules');
mkdirSync(out, { recursive: true });
for (const e of ['app', 'admin']) {
  const tmp = join(out, '.' + e);
  execFileSync(esbuild, [`${e}/main.tsx`, '--bundle', `--outdir=${tmp}`, '--define:__MOCK__=true', '--loader:.jpg=dataurl', '--jsx=automatic', '--minify',
    `--alias:react=${nm}/react`, `--alias:react-dom=${nm}/react-dom`, '--log-level=warning'], { stdio: 'inherit' });
  const html = readFileSync(`${e}/index.html`, 'utf8')
    .replace('<script type="module" src="./main.tsx"></script>', () => `<script>${readFileSync(join(tmp, 'main.js'), 'utf8').replace(/<\/script/g, '<\\/script')}</script>`)
    .replace('</head>', () => `<style>${readFileSync(join(tmp, 'main.css'), 'utf8')}</style></head>`);
  writeFileSync(join(out, e + '.html'), html);
}
console.log('ok');
