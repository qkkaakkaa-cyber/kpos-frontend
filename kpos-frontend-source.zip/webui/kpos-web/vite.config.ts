import { defineConfig, loadEnv } from "vite";
import react from "@vitejs/plugin-react";

// 开发时把 /api 转到真实服务器（默认 https://kpos.com），避免跨域。
export default defineConfig(({ mode }) => {
  const env = loadEnv(mode, process.cwd(), "");
  const target = env.VITE_API_TARGET || "https://kpos.com";
  return {
    // 部署在子路径时（例如 https://kpos.com/pc/）设 VITE_BASE=/pc/
    base: env.VITE_BASE || "/",
    plugins: [react()],
    server: {
      port: 5173,
      proxy: { "/api": { target, changeOrigin: true, secure: true } },
    },
  };
});
