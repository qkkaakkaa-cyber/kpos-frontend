# KPOS 电脑版用到的接口

所有接口都需要在请求头带 `Authorization: Bearer <token>`，`/login` 除外。
出错时返回 `{"error": "中文提示"}`，HTTP 状态码表示错误类型。
前端会把 `error` 原样显示给用户，所以提示要写成用户看得懂的中文。

- ✅ = 已经有（`app/services/mobile_api.py` 和 `mobile_tuwen.py`，后者在「构建 8」的更新包里）
- 🆕 = 要新做；在新接口做好之前，前端用示例数据，页面顶部会提示

---

## 一、已经有的接口（/api/mobile/v1）

| 接口 | 用途 |
|---|---|
| ✅ `POST /login` `{employee_id}` | 工号登录，返回 `{token, user, expires_in}` |
| ✅ `POST /logout`、`GET /me`、`GET /options` | 退出、当前用户、配音 / 音乐 / 时长选项 |
| ✅ `GET /feeds`、`GET /tuwen/feed` | 新闻分栏；后者带封面图 `image` 和 `chinese` |
| ✅ `GET /article?url=` | 任何新闻链接取出标题、正文、配图（中文社、公众号、外站） |
| ✅ `GET /article/images/{key}` | 文章配图（要登录） |
| ✅ `POST /jobs` | 生成快讯 / 深度：`{url, deep, voice, music, bgm_volume, duration}` |
| ✅ `POST /uploads`（multipart `file`）、`POST /jobs/upload` | 手动上传 |
| ✅ `GET /jobs?limit=`、`GET /jobs/{id}`、`POST /jobs/{id}/cancel`、`POST /jobs/{id}/retry` | 生成记录 |
| ✅ `GET /jobs/{id}/script`、`POST /jobs/{id}/rescript` `{segments}` | 口播文案，改了重新生成 |
| ✅ `GET /jobs/{id}/video`、`GET /jobs/{id}/cover` | 成片、封面 |
| ✅ `GET /jobs/{id}/visuals`、`GET /jobs/{id}/visuals/{key}/{frame|photo}`、`POST /jobs/{id}/revisuals` `{changes, segments?}` | 深度视频换画面 |
| ✅ `GET /tuwen/images?url=`、`GET /tuwen/story?url=`、`GET /tuwen/copy?url=&format=platform|full` | 图文慢任务：返回 `{state, step, elapsed, result}`，前端每 2 秒问一次，直到 `done` |
| ✅ `GET /tuwen/files/{key}` | 一键找图找到的图 |

---

## 二、员工端要补的

### 1. 🆕 `GET /me/queue`：我同时在做的视频和今天额度

```json
{
  "limit": 5,
  "running": [ /* Job，和 GET /jobs 的一样，多一个 queue_position */ ],
  "quota": { "quick": [3, 10], "deep": [1, 3] }
}
```

- `running` 列出这个人状态为 processing 的任务，包括排队中的。
- `quota` 的格式是 `[今天已用, 今天上限]`；不限额度时上限填 0，前端就不显示这一行。

### 2. 🆕 Job 多一个字段 `queue_position`

- 排队中：填第几位（1、2、3…）。
- 已经在剪：填 0 或不填。
- `GET /jobs`、`GET /jobs/{id}` 都要带上。

### 3. 🆕 每人同时最多 5 条

`POST /jobs`、`/jobs/upload`、`/jobs/script`、`/rescript`、`/revisuals`、`/retry` 提交前检查：这个人剪辑中加排队已经满 5 条时，返回 `409 {"error": "你同时在做的视频已经有 5 条，等前面做完再提交。"}`。

### 4. 🆕 `POST /jobs` 多收几个参数

| 参数 | 说明 |
|---|---|
| `deep_hint`（字符串，≤300 字，可选） | 编辑写的深度提示，例如「重点讲对华人的影响」。写深度文案时加进提示词：只决定侧重哪些角度，资料里没有的不能写；同时存进 `script.json` 方便查。 |
| `voice_rate`（0.9 / 1.0 / 1.1 / 1.2，可选） | 语速。现在服务器用的是后台设置（`_voice_rate()`），有这个参数时用参数。 |
| `voice_volume`（50–200，百分比，可选） | 配音音量。现在服务器用的是后台设置（`_voice_volume()`），有这个参数时用参数。 |

`/jobs/upload` 也收 `voice_rate`、`voice_volume`。

### 5. 🆕 新闻列表补字段

- `GET /feeds`、`GET /tuwen/feed` 的每条新闻加 `photos`：文章里的原图张数。
  - 前端在缩略图右下角显示这个数字。
  - 少于 2 张时，快讯和深度按钮会变灰。
  - 没有这个字段时前端不显示数字，也不拦按钮。
- `GET /tuwen/feed` 加一个分栏 `{"id": "social", "name": "社会", ...}`：泰国中文社分类是「社会」的最新文章。没有的话，前端从其他分栏里挑出 `topic` 含「社会」的条目。

### 6. 🆕 智能剪辑（把网页后台「智能剪辑」的查找流程做成接口）

对应现在 `app/ui/news_script.py` 里的 `render_input` 和 `render_actions`。

**`POST /script/search`**

请求：

```json
{ "prompt": "事件提示或已有文案（≤2000字）", "video_links": ["最多3条"], "clues": "补充线索（≤1000字）", "event_date": "2026-11-10" }
```

返回：

```json
{ "id": "查找任务ID", "state": "running", "phase": "正在搜索相关报道…", "error": "",
  "candidates": [], "excluded": 0, "unreadable": 0, "script": "", "sources": [], "modes": [] }
```

**`GET /script/search/{id}`**：前端每 2 秒问一次。做完时返回 `state: "done"`，并带上：

```json
{
  "candidates": [ { "id": "c1", "kind": "video", "source": "Facebook 帖子", "thumb": "/script/search/{id}/thumbs/c1",
                    "length": "0:42", "ok": true, "reason": "" } ],
  "excluded": 1,          // 排除的广告、无关
  "unreadable": 2,        // 打不开或日期不符
  "script": "整理好的口播（90秒内）",
  "sources": [ { "title": "参考报道标题", "url": "https://…" } ],
  "modes": ["视频剪辑", "混合剪辑", "图文剪辑"]   // review.editing_modes(candidates)
}
```

`thumb` 要登录才能取，返回相对接口前缀的路径。

**`POST /jobs/script`**

```json
{ "search_id": "…", "script": "编辑改过的口播", "edit_mode": "混合剪辑",
  "voice": "…", "music": "…", "bgm_volume": 5, "duration": 90, "voice_rate": 1.0, "voice_volume": 100 }
```

返回 Job。口播改过的话，要按新内容重新核对，和网页版一样。

---

## 三、总后台（🆕 全部新做，`/api/admin/v1`，只有管理员和主编能用）

前端用 `user.role` 判断能不能进总后台，判断规则在 `src/components/session.tsx` 的 `canSeeAdmin`。
服务器也必须自己再检查一遍权限。

> 要算 Token 和费用，得先在每次调大模型、配音的地方记账：任务 ID、员工、步骤、模型、输入和输出 Token、配音字数、时间。
> 建议记进一张 `usage` 表，下面的统计接口都从这张表里算。

| 接口 | 返回（字段见 `src/api/types.ts`） |
|---|---|
| `GET /overview?range=today|7d|30d|month` | `AdminOverview`：剪辑条数、成功率、Token、费用、剪辑机、近 14 天每天各步骤的 Token（单位 M） |
| `GET /jobs?day=&kind=&q=` | `{jobs: AdminJob[], totals: {count, tokens, usd, voice_chars, minutes}}`；前端可以导出 CSV |
| `GET /users?role=&q=` | `{users: AdminUser[]}`：本月每个人的快讯数、深度数、Token、费用、今天额度 |
| `POST /users` `{name, department, role}` | 开工号：`{employee_id}`。工号只在这次完整返回，以后列表里只给前 4 位 |
| `POST /users/{employee_id}` | 改额度 `{quick, deep, monthly_usd, max_depth}`、停用或启用 `{status: "disabled"|"active"}`、踢下线 `{kick: true}` |
| `GET /depth`、`POST /depth` | `AdminDepth`：快讯和深度查多深、每步用哪个模型、单价、预算 |
| `GET /nodes` | `{nodes: AdminNode[], queue: AdminQueueItem[], rules: {per_node, alert_minutes, retries, keep_days, per_user}}` |

模型名请按实际接的填，现在是 Kimi（moonshot）和 Kimi 视觉，配音是 MiniMax 和 ElevenLabs。设计稿里写的 Claude 只是示意。
