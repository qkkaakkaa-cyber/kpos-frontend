# KPOS 电脑版前端

KPOS（kpos.com）员工剪辑工作台和总后台的网页前端，技术栈是 React 18、Vite 6 和 TypeScript，没用 UI 组件库，样式全在 `src/styles.css`。

- 员工端接现有的 `/api/mobile/v1`（App 用的同一套接口），登录、新闻、做视频、做图文、生成记录都能直接用。
- 有些接口服务器还没有，例如总后台、智能剪辑、排队位置。连真实服务器时，前端遇到这些接口返回 404，会自动改用示例数据，页面顶部显示黄色提示条「接口待开发」。
- 要后端补的接口全部写在 [docs/API.md](docs/API.md)。

## 运行

```bash
npm install
npm run dev:mock     # 不连服务器，全部用示例数据看界面（任意工号都能登录）
npm run dev          # 连真实服务器：/api 转发到 https://kpos.com（在 .env.local 里改 VITE_API_TARGET）
npm run build        # 打包到 dist/
```

需要 Node 18 以上。`.env.example` 里有可以配置的项，复制成 `.env.local` 再改。

## 页面

| 地址 | 页面 | 用到的接口 |
|---|---|---|
| `/login` | 工号登录 | `POST /login` |
| `/news` | 新闻：中文社模式列表，每页 20 条；直接点快讯 / 深度生成；分栏有推荐、24 小时热门、一周热门、华人、社会、深度话题、最新 | `/tuwen/feed`、`/feeds`、`POST /jobs` |
| `/work?url=…` | 工作台：左边文章，右边制作区。「做视频」可写深度提示、调制作选项；「做图文」有来龙去脉、一键找图、分享文案（平台版 950 字 / 完整版） | `/article`、`POST /jobs`、`/tuwen/story`、`/tuwen/images`、`/tuwen/copy` |
| `/wechat` | 公众号剪辑：一次贴最多 5 条链接，提取后做快讯、深度或图文；最近提取过的记在本机 7 天 | `/article`、`POST /jobs` |
| `/script` | 智能剪辑：写事件提示或贴文案，查资料、找素材，改口播，选剪辑方式生成 | 待开发：`/script/search`、`/jobs/script` |
| `/upload` | 手动上传：拖入图片和视频；按模板改写或原样配音 | `POST /uploads`、`POST /jobs/upload` |
| `/jobs`、`/jobs/:id` | 生成记录：进行中的显示进度和步骤；做好的有大预览、下载、复制标题，还有「发布标题 / 口播文案 / 换画面 / 分享图文」四个标签 | `/jobs`、`/jobs/:id`、`cancel`、`retry`、`script`、`rescript`、`visuals`、`revisuals`、`video`、`cover` |
| `/admin/*` | 总后台：概览、剪辑记录、员工用量、深度与模型、剪辑机与队列、员工账号 | 待开发：`/api/admin/v1/*` |

左下角显示「进行中 N 条 / 上限 5 条」，读 `/me/queue`；这个接口没有时，前端从 `/jobs` 里数状态是 processing 的条数。

## 代码结构

```
src/
  api/client.ts       请求、登录 token、带登录取图片和视频（blobUrl）、待开发接口改用示例数据
  api/endpoints.ts    所有接口函数，后端改接口只改这里
  api/types.ts        接口返回的数据结构（字段名和服务器一致）
  api/mock.ts         示例数据
  components/         布局（侧边栏、排队）、制作选项、图标、小部件
  hooks/useApi.ts     读接口、轮询、图文慢任务（每 2 秒问一次直到 done）、本机偏好
  pages/              每个页面一个文件；总后台在 pages/admin/Admin.tsx
```

图片和视频接口都要登录，所以 `<img>` / `<video>` 不能直接写接口地址。前端先用 `blobUrl()` 带上 `Authorization` 头取回来，再放进 `src`。

## 部署（和接口同域名，免跨域）

先 `npm run build`，把 `dist/` 放到服务器上。下面两种方式选一种。

**方式一：nginx**（推荐把电脑版放在 `/pc/`，原来的网页后台不受影响）

```bash
VITE_BASE=/pc/ npm run build
```

```nginx
location /pc/ {
    alias /srv/kpos-web/dist/;
    try_files $uri $uri/ /pc/index.html;   # 单页应用：刷新任何地址都回到 index.html
}
location /api/ {
    proxy_pass http://127.0.0.1:8501;       # 现在的 Streamlit 服务（端口按实际）
    proxy_set_header Host $host;
    client_max_body_size 220m;              # 上传视频最大 200MB
}
```

**方式二：直接挂在现在的 Starlette 服务上**（`webui/server.py`）

```python
from pathlib import Path
from starlette.responses import FileResponse
from starlette.routing import Mount, Route
from starlette.staticfiles import StaticFiles

DIST = Path("/srv/kpos-web/dist")

async def pc_index(_request):
    return FileResponse(DIST / "index.html")

pc_routes = [
    Mount("/pc/assets", StaticFiles(directory=DIST / "assets")),
    Route("/pc", pc_index), Route("/pc/{path:path}", pc_index),
]
app = App("Main.py", routes=[*mobile_routes, *tuwen_routes, *pc_routes])
```

## 注意

- 服务器要先装好「构建 8」的更新包（`thais-video-update.zip`），图文接口（`/tuwen/*`）和换画面接口（`/visuals`、`/revisuals`）才有。
- 现在登录接口收的是 7 位工号（`employee_id`）。设计稿里写的「MK + 6 位」只是示意，以服务器为准。
- 「平台」按钮会复制文案、下载选中的图，再打开该平台的网页发布页。浏览器不能直接替用户发布。
