import { StrictMode, type ReactNode } from "react";
import { createRoot } from "react-dom/client";
import { BrowserRouter, Navigate, Route, Routes, useLocation } from "react-router-dom";
import { AdminLayout, StaffLayout } from "./components/Layout";
import { SessionProvider, canSeeAdmin, useSession } from "./components/session";
import { Loading } from "./components/ui";
import Jobs from "./pages/Jobs";
import Login from "./pages/Login";
import News from "./pages/News";
import Script from "./pages/Script";
import Upload from "./pages/Upload";
import Wechat from "./pages/Wechat";
import Workbench from "./pages/Workbench";
import { AdminAccounts, AdminDepthPage, AdminJobs, AdminNodes, AdminUsers, Overview } from "./pages/admin/Admin";
import "./styles.css";

function RequireLogin({ children, admin }: { children: ReactNode; admin?: boolean }) {
  const { user, ready } = useSession();
  const location = useLocation();
  if (!ready) return <Loading text="正在打开 KPOS…" />;
  if (!user) return <Navigate to="/login" replace state={{ from: location.pathname + location.search }} />;
  if (admin && !canSeeAdmin(user)) return <Navigate to="/news" replace />;
  return <>{children}</>;
}

createRoot(document.getElementById("root")!).render(
  <StrictMode>
    <SessionProvider>
      <BrowserRouter basename={import.meta.env.BASE_URL.replace(/\/$/, "")}>
        <Routes>
          <Route path="/login" element={<Login />} />
          <Route element={<RequireLogin><StaffLayout /></RequireLogin>}>
            <Route path="/news" element={<News />} />
            <Route path="/work" element={<Workbench />} />
            <Route path="/wechat" element={<Wechat />} />
            <Route path="/script" element={<Script />} />
            <Route path="/upload" element={<Upload />} />
            <Route path="/jobs" element={<Jobs />} />
            <Route path="/jobs/:id" element={<Jobs />} />
          </Route>
          <Route element={<RequireLogin admin><AdminLayout /></RequireLogin>}>
            <Route path="/admin" element={<Overview />} />
            <Route path="/admin/jobs" element={<AdminJobs />} />
            <Route path="/admin/users" element={<AdminUsers />} />
            <Route path="/admin/depth" element={<AdminDepthPage />} />
            <Route path="/admin/nodes" element={<AdminNodes />} />
            <Route path="/admin/accounts" element={<AdminAccounts />} />
          </Route>
          <Route path="*" element={<Navigate to="/news" replace />} />
        </Routes>
      </BrowserRouter>
    </SessionProvider>
  </StrictMode>,
);
