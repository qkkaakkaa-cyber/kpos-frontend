// 接口客户端：/api/mobile/v1（员工端，已有）和 /api/admin/v1（总后台，待开发）。
// 登录后把 token 存在 localStorage，每次请求带 Authorization: Bearer。
// 图片、视频接口也要登录，所以 <img>/<video> 不能直接写 src，用 blobUrl() 先取回来。

import { mockRequest } from "./mock";

export const MOBILE = "/api/mobile/v1";
export const ADMIN = "/api/admin/v1";
export const MOCK = import.meta.env.VITE_MOCK === "1";

const TOKEN_KEY = "kpos_token";

export class ApiError extends Error {
  status: number;
  constructor(message: string, status: number) {
    super(message);
    this.status = status;
  }
}

export function getToken(): string {
  try {
    return localStorage.getItem(TOKEN_KEY) || "";
  } catch {
    return "";
  }
}

export function setToken(token: string) {
  try {
    if (token) localStorage.setItem(TOKEN_KEY, token);
    else localStorage.removeItem(TOKEN_KEY);
  } catch {
    /* 隐私模式下存不了，只在本页有效 */
  }
}

/** 登录失效时通知 App 回到登录页 */
let onUnauthorized: () => void = () => {};
export function handleUnauthorized(callback: () => void) {
  onUnauthorized = callback;
}

type Query = Record<string, string | number | boolean | undefined | null>;

interface RequestOptions {
  base?: string;
  query?: Query;
  json?: unknown;
  form?: FormData;
  /** 服务器还没有这个接口时（404/405/501）用模拟数据，并在页面上提示 */
  pending?: boolean;
}

function buildUrl(base: string, path: string, query?: Query) {
  const url = new URL(base + path, window.location.origin);
  for (const [key, value] of Object.entries(query || {})) {
    if (value !== undefined && value !== null && value !== "") url.searchParams.set(key, String(value));
  }
  return url.pathname + url.search;
}

/** 哪些待开发接口正在用模拟数据，页面据此显示提示条 */
export const pendingInUse = new Set<string>();
const listeners = new Set<() => void>();
export function onPendingChange(listener: () => void) {
  listeners.add(listener);
  return () => listeners.delete(listener);
}
function markPending(path: string) {
  const key = path.split("?")[0];
  if (!pendingInUse.has(key)) {
    pendingInUse.add(key);
    listeners.forEach((listener) => listener());
  }
}

export async function request<T>(method: string, path: string, options: RequestOptions = {}): Promise<T> {
  const base = options.base ?? MOBILE;
  const url = buildUrl(base, path, options.query);
  if (MOCK) {
    if (options.pending) markPending(base + path);
    return mockRequest<T>(method, base + path, options.query, options.json ?? options.form);
  }
  const headers: Record<string, string> = { Accept: "application/json" };
  const token = getToken();
  if (token) headers.Authorization = `Bearer ${token}`;
  let body: BodyInit | undefined;
  if (options.form) body = options.form;
  else if (options.json !== undefined) {
    headers["Content-Type"] = "application/json";
    body = JSON.stringify(options.json);
  }
  let response: Response;
  try {
    response = await fetch(url, { method, headers, body });
  } catch {
    throw new ApiError("连不上服务器，请检查网络。", 0);
  }
  if (options.pending && [404, 405, 501].includes(response.status)) {
    markPending(base + path);
    return mockRequest<T>(method, base + path, options.query, options.json ?? options.form);
  }
  const text = await response.text();
  let data: unknown = null;
  try {
    data = text ? JSON.parse(text) : null;
  } catch {
    data = null;
  }
  if (!response.ok) {
    const message = (data as { error?: string } | null)?.error || `服务器出错（${response.status}）`;
    if (response.status === 401 && !path.startsWith("/login")) {
      setToken("");
      onUnauthorized();
    }
    throw new ApiError(message, response.status);
  }
  return data as T;
}

export const get = <T>(path: string, query?: Query, extra: Omit<RequestOptions, "query"> = {}) =>
  request<T>("GET", path, { ...extra, query });
export const post = <T>(path: string, json?: unknown, extra: Omit<RequestOptions, "json"> = {}) =>
  request<T>("POST", path, { ...extra, json: json ?? {} });

// ---------------------------------------------------------------- 带登录的图片和视频

const blobCache = new Map<string, Promise<string>>();

/** 把需要登录的图片或视频取回来，返回可以放进 src 的 blob: 地址。path 是接口返回的相对路径。 */
export function blobUrl(path: string, base = MOBILE): Promise<string> {
  if (!path) return Promise.reject(new ApiError("没有图片", 404));
  if (/^(data:|blob:|https?:)/.test(path)) return Promise.resolve(path);
  if (MOCK) return Promise.resolve(mockImage(path));
  const key = base + path;
  let cached = blobCache.get(key);
  if (!cached) {
    cached = fetch(key, { headers: { Authorization: `Bearer ${getToken()}` } }).then(async (response) => {
      if (!response.ok) throw new ApiError(response.status === 404 ? "图片已过期" : "图片加载失败", response.status);
      return URL.createObjectURL(await response.blob());
    });
    cached.catch(() => blobCache.delete(key));
    if (blobCache.size > 400) blobCache.clear();
    blobCache.set(key, cached);
  }
  return cached;
}

/** 下载需要登录的文件（成片、封面、图片） */
export async function download(path: string, filename: string) {
  const url = await blobUrl(path);
  const link = document.createElement("a");
  link.href = url;
  link.download = filename;
  document.body.appendChild(link);
  link.click();
  link.remove();
}

/** 模拟数据用的占位图：按路径算一个颜色 */
function mockImage(path: string): string {
  const palette = ["#CFE6DE", "#DCD6EE", "#F3E2C8", "#3B2E66", "#2E2552", "#E2F1EC"];
  let hash = 0;
  for (const char of path) hash = (hash * 31 + char.charCodeAt(0)) >>> 0;
  const color = palette[hash % palette.length];
  const dark = color.startsWith("#2") || color.startsWith("#3");
  const svg = `<svg xmlns="http://www.w3.org/2000/svg" width="640" height="420"><rect width="640" height="420" fill="${color}"/><text x="320" y="220" font-size="28" text-anchor="middle" fill="${dark ? "#C9C0E6" : "#8A8F99"}" font-family="sans-serif">示例图片</text></svg>`;
  return "data:image/svg+xml;charset=utf-8," + encodeURIComponent(svg);
}
