// 模拟数据：npm run dev:mock 时所有接口都走这里；连真实服务器时，只有待开发的接口走这里。
// 里面的新闻标题来自泰国中文社的公开报道，人名、数字只是演示用。

/* eslint-disable @typescript-eslint/no-explicit-any */

const delay = (ms: number) => new Promise((resolve) => setTimeout(resolve, ms));
const now = Date.now();
const iso = (minutesAgo: number) => new Date(now - minutesAgo * 60000).toISOString();

const HOT: [string, string, number, number, string, boolean, number][] = [
  ["泰国惩教署：蓬潘达与丈夫入狱首夜无特殊待遇", "up", 1, 12, "社会", false, 4],
  ["玛诺车队抵达曼谷总理府，要求柴油每升下调10泰铢", "down", 1, 14, "时政", false, 5],
  ["素察会见俄籍受害者，称将全面核查自由海滩土地买卖投诉", "same", 0, 16, "社会", false, 3],
  ["曼谷警方逮捕两名中国籍电诈嫌疑人 一人涉非法入境", "new", 0, 4, "社会", true, 1],
  ["泰国气象厅更新南部强降雨预警至11月13日 北部降温3至5度", "same", 0, 14, "天气", false, 6],
  ["曼谷警方增关披耶泰路应对总理府集会 封闭路段增至5处", "up", 2, 11, "社会", false, 3],
  ["泰议长拒收废除6·6法令草案 人民党议员提三项建议", "down", 2, 9, "时政", false, 2],
  ["泰议员指责泰自豪党阻挠国会委员会紧急审议湄赛河砷污染", "up", 3, 9, "环境", false, 3],
  ["阿努廷假日召警察总长汇报案件，警方公告总理府周边50米禁集会", "same", 0, 7, "时政", false, 2],
  ["芭提雅警方追回中国游客失窃名表，两嫌疑人供认取走", "new", 0, 5, "社会", true, 0],
  ["警方持搜查令突查农普鲁豪宅，控制8名中国籍和2名缅甸籍人员", "down", 4, 8, "社会", true, 5],
  ["那空那育府时隔17年举行洗坟仪式 收殓1411具无主遗骸", "same", 0, 6, "社会", true, 6],
  ["曼谷联合行动逮捕两名涉跨国诈骗中国籍男子", "up", 1, 6, "社会", true, 2],
  ["泰国前选美冠军夫妇被羁押！家中查获32只名牌包", "down", 3, 6, "社会", false, 4],
  ["阿努廷否认操控上议院：只有政绩能保政府", "same", 0, 5, "时政", false, 2],
  ["马来西亚男子在泰国丽贝岛度假村内死亡 警方初步怀疑与服用助性药物有关", "new", 0, 5, "社会", false, 3],
  ["清迈出现今冬首场浓雾 素贴山观景台气温降至 12°C", "down", 1, 4, "天气", false, 6],
  ["泰国内阁批准“泰国人游泰国”第二期补贴", "up", 2, 4, "经济", false, 3],
  ["曼谷 BTS 金线明年起票价统一 15 铢", "same", 0, 3, "交通", false, 2],
  ["普吉岛下周起游客税正式征收", "new", 0, 3, "旅游", false, 1],
];

function feedItems(offset = 0, count = 20) {
  return Array.from({ length: count }, (_, index) => {
    const [title, move, by, media, topic, chinese, photos] = HOT[(index + offset) % HOT.length];
    return {
      title, url: `https://thais.com/news-${310000 + index + offset}/`, date: iso(20 + index * 37),
      media: `${media}家媒体`, topic, reason: "", tags: [], media_count: media, move, move_by: by,
      image: `/article/images/mock${index + offset}`, chinese, photos,
    };
  });
}

const sections = () => [
  { id: "recommended", name: "推荐关注", items: feedItems(3), error: "" },
  { id: "hot_day", name: "24小时热门", items: feedItems(0), error: "" },
  { id: "hot_week", name: "一周热门", items: feedItems(6), error: "" },
  { id: "huaren", name: "华人", items: feedItems(0).filter((item) => item.chinese), error: "" },
  { id: "social", name: "社会", items: feedItems(0).filter((item) => item.topic === "社会"), error: "" },
  { id: "deep", name: "深度话题", items: feedItems(9, 6).map((item) => ({ ...item, reason: "事情还在发展，多方说法和关键数字都有，适合讲清来龙去脉", tags: ["事件还在发展", "多方说法"] })), error: "" },
  { id: "latest", name: "最新", items: feedItems(11), error: "" },
];

const ARTICLE = {
  url: "https://thais.com/news-310007/",
  title: "泰议员指责泰自豪党阻挠国会委员会紧急审议湄赛河砷污染",
  source: "泰国中文社",
  date: "2026-11-08",
  chars: 864,
  paragraphs: [
    "泰国国会自然灾害与公共灾害防治委员会主席、清迈府人民党议员帕塔蓬·利拉帕11月8日在脸书发文称，该委员会无法将湄赛河砷污染问题列为紧急议程。",
    "他表示，众议院议长索蓬要求此类动议必须事先获得委员会决议，导致紧急事项至少需等待两周。",
    "（模拟数据：正文其余段落）",
  ],
  images: ["/article/images/a1", "/article/images/a2", "/article/images/a3"],
  foreign: false,
};

const STEPS_DEEP = [
  { key: "read", name: "读取原文", state: "done", detail: "" },
  { key: "search", name: "查来龙去脉", state: "done", detail: "找到 6 篇相关报道" },
  { key: "write", name: "写口播文案", state: "done", detail: "约 2 分 38 秒" },
  { key: "videos", name: "找现场视频", state: "running", detail: "正在检查第 2/5 条视频" },
  { key: "voice", name: "配音", state: "pending", detail: "" },
  { key: "render", name: "剪辑导出", state: "pending", detail: "" },
];

function makeJob(id: string, over: Record<string, any>) {
  return {
    id, state: "complete", progress: 100, phase: "", error: "", title: "", publication_title: "",
    source_url: "https://thais.com/news-310013/", uploaded: false, created_at: iso(60), has_video: true,
    has_cover: true, video_bytes: 38_000_000, server_video_deleted: false, video_expires_at: null,
    can_cancel: false, cancel_requested: false, deep: false, script_ready: true, steps: [], ...over,
  };
}

let JOBS: any[] = [
  makeJob("j-run-1", { state: "processing", progress: 46, title: "阿努廷否认操控上议院：只有政绩能保政府", deep: true, can_cancel: true, has_video: false, has_cover: false, steps: STEPS_DEEP, created_at: iso(14) }),
  makeJob("j-run-2", { state: "processing", progress: 12, title: "玛诺车队抵达曼谷总理府，要求柴油每升下调10泰铢", can_cancel: true, has_video: false, has_cover: false, phase: "写口播", created_at: iso(9) }),
  makeJob("j-q-1", { state: "processing", progress: 0, title: "泰铢兑人民币跌破 4.4 意味着什么", deep: true, can_cancel: true, has_video: false, has_cover: false, queue_position: 1, created_at: iso(7) }),
  makeJob("j-q-2", { state: "processing", progress: 0, title: "素察会见俄籍受害者，称将全面核查自由海滩土地买卖投诉", can_cancel: true, has_video: false, has_cover: false, queue_position: 2, created_at: iso(6) }),
  makeJob("j-q-3", { state: "processing", progress: 0, title: "清迈出现今冬首场浓雾 素贴山观景台气温降至 12°C", can_cancel: true, has_video: false, has_cover: false, queue_position: 3, created_at: iso(5) }),
  makeJob("j-ok-1", { title: "泰国前选美冠军夫妇被羁押！家中查获32只名牌包", publication_title: "前选美冠军夫妇被羁押，家中搜出 32 只名牌包，案情还在发酵 #泰国新闻 #泰国中文社", deep: true, created_at: iso(560) }),
  makeJob("j-ok-2", { title: "曼谷警方逮捕两名中国籍电诈嫌疑人 一人涉非法入境", publication_title: "曼谷警方逮捕两名中国籍电诈嫌疑人 #泰国新闻", created_at: iso(585) }),
  makeJob("j-bad-1", { state: "failed", progress: 0, title: "芭提雅海滩夜市现场（上传 3 段）", error: "素材太短，至少要 20 秒", uploaded: true, has_video: false, has_cover: false, source_url: "", created_at: iso(1220) }),
  makeJob("j-ok-3", { title: "泰国惩教署：蓬潘达与丈夫入狱首夜无特殊待遇", publication_title: "蓬潘达夫妇入狱首夜无特殊待遇 #泰国新闻", deep: true, created_at: iso(1490) }),
];

const tasks = new Map<string, number>();
function tuwenTask(key: string, steps: string[], result: () => any) {
  const polls = (tasks.get(key) || 0) + 1;
  tasks.set(key, polls);
  if (polls <= steps.length) {
    return { state: "running", step: steps[polls - 1], error: "", elapsed: polls * 9, result: null };
  }
  return { state: "done", step: "", error: "", elapsed: steps.length * 9, result: result() };
}

let scriptPolls = 0;

const handlers: [string, RegExp, (match: RegExpMatchArray, query: any, body: any) => any][] = [
  ["POST", /\/login$/, (_m, _q, body) => {
    if (!body?.employee_id) throw { status: 400, message: "请输入7位工号。" };
    return { token: "mock-token-0000000000000000", user: { employee_id: body.employee_id, name: "林晓雯", role: "admin" }, expires_in: 2592000 };
  }],
  ["POST", /\/logout$/, () => ({ ok: true })],
  ["GET", /\/me$/, () => ({ user: { employee_id: "0217345", name: "林晓雯", role: "admin" } })],
  ["GET", /\/me\/queue$/, () => ({
    limit: 5, running: JOBS.filter((job) => job.state === "processing"),
    quota: { quick: [3, 10], deep: [1, 3] },
  })],
  ["GET", /\/options$/, () => ({
    durations: [30, 45, 60], upload_durations: [30, 45, 60, 90], default_duration: 60,
    voices: [
      { id: "minimax:female-1", provider: "minimax", code: "1号", name: "欣怡女声", gender: "女", description: "新闻播报" },
      { id: "minimax:male-2", provider: "minimax", code: "2号", name: "子轩男声", gender: "男", description: "沉稳" },
      { id: "elevenlabs:v4-1", provider: "elevenlabs", code: "E1", name: "晴晴", gender: "女", description: "自然口语" },
    ],
    providers: [{ id: "minimax", name: "MiniMax", ready: true }, { id: "elevenlabs", name: "ElevenLabs", ready: true }],
    default_voice: "minimax:female-1",
    music: [{ id: "auto", name: "按新闻主题自动配乐" }, { id: "news-03.mp3", name: "新闻节奏 03" }, { id: "calm-01.mp3", name: "舒缓 01" }],
    default_music: "auto", bgm_volume: { default: 5, max: 5 }, source_volume: { default: 10, max: 400 },
    upload_limits: { files: 8, video_mb: 200, image_mb: 15, material_chars: 6000, script_chars: 800 },
  })],
  ["GET", /\/(tuwen\/)?feed(s)?$/, () => ({ fetched_at: iso(5), sections: sections() })],
  ["GET", /\/article$/, (_m, query) => {
    const url = String(query?.url || "");
    if (url.includes("mp.weixin.qq.com")) {
      return { ...ARTICLE, url, title: "[公众号文章标题]", source: "公众号", chars: 1860, paragraphs: ["[公众号正文第一段]", "[公众号正文第二段]"], images: ["/article/images/w1", "/article/images/w2", "/article/images/w3", "/article/images/w4", "/article/images/w5"] };
    }
    return { ...ARTICLE, url: url || ARTICLE.url };
  }],
  ["POST", /mobile\/v1\/jobs$/, (_m, _q, body) => {
    const created = makeJob(`j-new-${Date.now()}`, { state: "processing", progress: 0, title: "", deep: !!body?.deep, has_video: false, has_cover: false, can_cancel: true, source_url: body?.url, created_at: new Date().toISOString(), steps: body?.deep ? STEPS_DEEP.map((step) => ({ ...step, state: "pending", detail: "" })) : [] });
    JOBS = [created, ...JOBS];
    return created;
  }],
  ["POST", /\/jobs\/(upload|script)$/, () => {
    const created = makeJob(`j-new-${Date.now()}`, { state: "processing", progress: 0, uploaded: true, has_video: false, has_cover: false, can_cancel: true, source_url: "", created_at: new Date().toISOString() });
    JOBS = [created, ...JOBS];
    return created;
  }],
  ["GET", /mobile\/v1\/jobs$/, () => ({ jobs: JOBS })],
  ["GET", /\/jobs\/([^/]+)$/, (match) => JOBS.find((job) => job.id === match[1]) || JOBS[0]],
  ["POST", /\/jobs\/([^/]+)\/cancel$/, (match) => {
    JOBS = JOBS.map((job) => job.id === match[1] ? { ...job, state: "cancelled", can_cancel: false } : job);
    return JOBS.find((job) => job.id === match[1]);
  }],
  ["POST", /\/jobs\/([^/]+)\/(retry|rescript|revisuals)$/, () => {
    const created = makeJob(`j-new-${Date.now()}`, { state: "processing", progress: 0, has_video: false, has_cover: false, can_cancel: true, created_at: new Date().toISOString(), title: "（重新生成）" });
    JOBS = [created, ...JOBS];
    return created;
  }],
  ["GET", /\/jobs\/([^/]+)\/script$/, () => ({
    segments: [
      "泰国前选美冠军蓬潘达和丈夫阿提普，因涉嫌共同诈骗公众，被法院批准羁押。",
      "（模拟数据：口播第二段）",
      "（模拟数据：口播第三段）",
      "泰国中文社11月8日报道。",
    ], chars: 486, seconds: 110, editable: true, ready: true,
  })],
  ["GET", /\/jobs\/([^/]+)\/visuals$/, () => ({
    editable: true, reason: "",
    items: [["card", 10], ["photo", 42], ["photo", 31], ["video", 24], ["photo", 21], ["card", 15], ["photo", 18]].map(([kind, seconds], index) => ({
      key: `v${index}`, kind, uses: 1, seconds, frame: `/jobs/x/visuals/v${index}/frame`, photo: `/jobs/x/visuals/v${index}/photo`, exists: true,
    })),
  })],
  ["GET", /\/tuwen\/images$/, (_m, query) => tuwenTask(`images:${query?.url}`, ["读取原文和配图…", "在泰国媒体里找同一件事…", "下载 15 张图片…", "AI 检查广告、二维码和无关图片…"], () => ({
    title: ARTICLE.title,
    images: ["原文", "原文", "原文", "民意报", "The Standard", "原文"].map((source, index) => ({ path: `/tuwen/files/m${index}`, source, width: 1280, height: 720 })),
    checked: true, masked: 0, removed: { duplicates: 2, unsuitable: 3, reasons: { 广告: 1, 文字海报: 1, 无关: 1 } },
    media: ["民意报", "The Standard"],
    searches: [{ site: "Facebook", keyword: "แม่น้ำสาย สารหนู", url: "https://www.facebook.com/search/photos/?q=%E0%B9%81%E0%B8%A1%E0%B9%88%E0%B8%99%E0%B9%89%E0%B8%B3%E0%B8%AA%E0%B8%B2%E0%B8%A2" }],
  }))],
  ["GET", /\/tuwen\/story$/, (_m, query) => tuwenTask(`story:${query?.url}`, ["查找泰国中文社之前的报道…", "整理时间线…"], () => ({
    title: "湄赛河砷超标，国会紧急审议被卡住",
    summary: "清莱湄赛河变浑后，多个监测点检出砷超标，学者怀疑与缅甸上游开矿有关。议员想让委员会紧急审议，却卡在新的委员会规则上。",
    now: "（模拟数据：最新进展）",
    timeline: [
      { date: "10月25日", text: "缅甸大其力至少20家矿企获准开采，铅锰矿石经泰北口岸入境" },
      { date: "10月26日", text: "湄赛河变红浊，学者怀疑与上游采矿有关" },
      { date: "10月30日", text: "3个监测点砷超标；污染控制厅称泰国境内无跨境污染源" },
      { date: "11月1日", text: "污染控制厅通报自来水局加强监测" },
      { date: "11月8日", text: "议员称委员会无法紧急审议砷污染，指责新规则阻挠" },
    ],
    facts: [{ label: "实测砷 毫克/升", value: "0.25" }, { label: "标准 ≤0.01", value: "25倍" }, { label: "获准矿企", value: "20家" }],
    related: [{ title: "（模拟数据：之前的相关报道）", date: "2026-10-30" }],
  }))],
  ["GET", /\/tuwen\/copy$/, (_m, query) => tuwenTask(`copy:${query?.url}:${query?.format}`, ["读取原文…", "按编辑规范写稿…", "核对编辑规范…"], () => ({
    format: query?.format, title: "湄赛河砷超标 国会紧急审议被卡住",
    body: "泰国国会自然灾害与公共灾害防治委员会主席帕塔蓬·利拉帕11月8日表示，该委员会无法将湄赛河砷污染问题列为紧急议程。\n\n（模拟数据：正文其余段落）",
    signoff: "泰国中文社11月8日报道", chars: 486, limit: query?.format === "full" ? 2000 : 950, tags: ["泰国新闻", "清莱", "湄赛河"],
  }))],
  ["POST", /\/script\/search$/, () => {
    scriptPolls = 0;
    return { id: "s1", state: "running", phase: "正在搜索相关报道…", error: "", candidates: [], excluded: 0, unreadable: 0, script: "", sources: [], modes: [] };
  }],
  ["GET", /\/script\/search\/([^/]+)$/, () => {
    scriptPolls += 1;
    if (scriptPolls < 3) return { id: "s1", state: "running", phase: ["正在搜索相关报道…", "正在检查视频和图片…"][scriptPolls - 1], error: "", candidates: [], excluded: 0, unreadable: 0, script: "", sources: [], modes: [] };
    return {
      id: "s1", state: "done", phase: "", error: "", excluded: 1, unreadable: 2,
      candidates: [
        { id: "c1", kind: "video", source: "Facebook 帖子", thumb: "/x/c1", length: "0:42", ok: true },
        { id: "c2", kind: "video", source: "TikTok", thumb: "/x/c2", length: "0:28", ok: true },
        { id: "c3", kind: "video", source: "泰国电视台", thumb: "/x/c3", length: "1:05", ok: true },
        { id: "c4", kind: "image", source: "泰国媒体", thumb: "/x/c4", ok: true },
        { id: "c5", kind: "image", source: "泰国媒体", thumb: "/x/c5", ok: true },
        { id: "c6", kind: "image", source: "泰国媒体", thumb: "/x/c6", ok: false, reason: "广告" },
      ],
      script: "（模拟数据：系统查完资料后整理的口播文案，可以直接改）",
      sources: [{ title: "（模拟数据：查到的报道）", url: "https://thais.com/" }],
      modes: ["视频剪辑", "混合剪辑", "图文剪辑"],
    };
  }],
  // ---------------------------------------------------------------- 总后台
  ["GET", /\/overview$/, () => ({
    today: { jobs: 86, quick: 61, deep: 25, vs_yesterday: 12, success_rate: 94.2, failed: 4, cancelled: 1, running: 3 },
    tokens: { total: 2_400_000, input: 2_050_000, output: 350_000 },
    cost: { usd: 19.7, thb: 640, voice_usd: 8.9 },
    nodes: { online: 3, total: 3, queued: 4, clear_minutes: 6 },
    daily: Array.from({ length: 14 }, (_, index) => ({
      date: new Date(now - (13 - index) * 86400000).toISOString().slice(5, 10).replace("-", "/"),
      research: 0.8 + ((index * 37) % 7) / 10, script: 0.45 + ((index * 13) % 3) / 10, other: 0.17 + (index % 4) / 50,
    })),
  })],
  ["GET", /\/admin\/v1\/jobs$/, () => ({
    totals: { count: 89, tokens: 2_401_320, usd: 19.71, voice_chars: 31_450, minutes: "1 小时 52 分" },
    jobs: [
      ["17:01", "林晓雯", "阿努廷否认操控上议院：只有政绩能保政府", "深度", "6 篇 · 5 段", "生成中 46%", "—", "3:47", 58210, 0.31],
      ["16:52", "陈嘉豪", "玛诺车队抵达曼谷总理府，要求柴油每升下调10泰铢", "深度", "6 篇 · 5 段", "失败 · 重试中", "—", "9:10", 70480, 0.36],
      ["16:40", "王一凡", "曼谷 BTS 金线明年起票价统一 15 铢", "快讯", "—", "已完成", "0:56", "3:05", 9420, 0.11],
      ["16:31", "Somchai 苏", "清迈出现今冬首场浓雾", "快讯", "—", "已完成", "0:49", "2:58", 8960, 0.1],
      ["15:22", "李佳", "泰国内阁批准“泰国人游泰国”第二期补贴", "深度", "8 篇 · 5 段", "已完成", "2:58", "11:02", 91300, 0.63],
      ["14:18", "王一凡", "芭提雅海滩夜市现场", "上传素材", "3 段素材", "已完成", "0:44", "2:41", 5880, 0.08],
      ["08:15", "林晓雯", "泰国前选美冠军夫妇被羁押！家中查获32只名牌包", "深度", "6 篇 · 5 段", "已完成", "2:41", "8:52", 73040, 0.52],
    ].map(([at, user, title, kind, depth, state, length, took, tokens, usd], index) => ({ id: `J-${index}`, at, user, title, kind, depth, state, length, took, tokens, usd })),
  })],
  ["GET", /\/users$/, () => ({
    users: [
      ["0217345", "林晓雯", "编辑", "新闻部", "正常", 58, 21, 2_080_000, 17.4, "7/10 · 2/3", "刚刚"],
      ["0112093", "陈嘉豪", "主编", "新闻部", "正常", 71, 18, 1_980_000, 16.21, "不限", "10 分钟前"],
      ["0118842", "王一凡", "编辑", "社会部", "正常", 44, 12, 1_310_000, 10.66, "6/10 · 1/3", "25 分钟前"],
      ["0220481", "周敏", "编辑", "生活部", "额度用完", 30, 9, 940_000, 7.75, "10/10 · 3/3", "昨天"],
      ["0229107", "张伟", "实习编辑", "社会部", "正常", 6, 0, 60_000, 0.66, "3/5 · 0/0", "今天"],
      ["0003001", "阿明", "管理员", "技术部", "正常", 0, 0, 0, 0, "不限", "在线"],
      ["0119920", "吴可", "编辑", "生活部", "已停用", 3, 0, 30_000, 0.33, "—", "11-02"],
    ].map(([employee_id, name, role, department, status, quick, deep, tokens, usd, today, last_seen]) => ({ employee_id, name, role, department, status, quick, deep, tokens, usd, today, last_seen })),
  })],
  ["POST", /\/users(\/[^/]+)?$/, () => ({ ok: true, employee_id: "0230518" })],
  ["GET", /\/depth$/, () => ({
    quick: { seconds: 60, rewrite: "按原文改写", research: "不查", footage: "不找，用配图", check: "只查敏感词", tokens: 9800, usd: 0.11 },
    deep: { minutes: "2–3", reports: 6, days: 60, clips: 5, cross_check: 3, check: "全文核对", tokens: 72000, usd: 0.52 },
    models: [
      { step: "新闻排行 · 聚类", note: "每 15 分钟一轮", model: "Kimi（moonshot）", input: 0.6, output: 2.5 },
      { step: "查来龙去脉", note: "读得最多", model: "Kimi（moonshot）", input: 0.6, output: 2.5 },
      { step: "写口播文案", note: "", model: "Kimi（moonshot）", input: 0.6, output: 2.5 },
      { step: "看图（找图、换画面）", note: "", model: "Kimi 视觉", input: 0.6, output: 2.5 },
    ],
    budget: { daily: 30, monthly: 700, alert: 80, over: "只让主编做", voice_per_k: 0.3, thb_rate: 32.5 },
  })],
  ["POST", /\/depth$/, () => ({ ok: true })],
  ["GET", /\/nodes$/, () => ({
    nodes: [
      { name: "剪辑机-1", spec: "Mac Studio M2 Ultra · 办公室", state: "工作中", doing: "阿努廷否认操控上议院（深度 · 林晓雯）", cpu: 64, gpu: 71, disk: 58, done_today: 32, heartbeat: "3 秒前" },
      { name: "剪辑机-2", spec: "Mac Studio M2 Ultra · 办公室", state: "重试中", doing: "玛诺车队抵达曼谷总理府（深度 · 配音超时）", cpu: 38, gpu: 22, disk: 61, done_today: 29, heartbeat: "3 秒前" },
      { name: "剪辑机-3", spec: "Windows · RTX 4080 · 机房", state: "空闲", doing: "空闲，等下一条", cpu: 6, gpu: 3, disk: 88, done_today: 25, heartbeat: "3 秒前" },
    ],
    queue: [
      { position: 1, user: "陈嘉豪", title: "泰铢兑人民币跌破 4.4 意味着什么", kind: "深度", eta: "约 1 分钟后", node: "剪辑机-3" },
      { position: 2, user: "王一凡", title: "普吉岛下周起游客税正式征收", kind: "快讯", eta: "约 2 分钟后", node: "剪辑机-3" },
      { position: 3, user: "林晓雯", title: "素察会见俄籍受害者（重试）", kind: "深度", eta: "约 4 分钟后", node: "自动分配" },
    ],
    rules: { per_node: 2, alert_minutes: 10, retries: 1, keep_days: 30, per_user: 5 },
  })],
];

export async function mockRequest<T>(method: string, path: string, query: any, body: any): Promise<T> {
  await delay(160 + Math.random() * 200);
  for (const [verb, pattern, handler] of handlers) {
    const match = path.match(pattern);
    if (verb === method && match) {
      try {
        return JSON.parse(JSON.stringify(handler(match, query, body))) as T;
      } catch (error: any) {
        const { ApiError } = await import("./client");
        throw new ApiError(error?.message || "模拟出错", error?.status || 400);
      }
    }
  }
  const { ApiError } = await import("./client");
  throw new ApiError(`模拟数据里没有这个接口：${method} ${path}`, 404);
}
