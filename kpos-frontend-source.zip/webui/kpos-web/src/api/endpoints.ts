// 所有接口集中在这里。标了 pending 的是服务器还没有的接口（见 docs/API.md），
// 服务器返回 404 时自动用模拟数据，页面顶部会提示“接口待开发”。

import { ADMIN, get, post, request } from "./client";
import type {
  AdminDepth, AdminJob, AdminNode, AdminOverview, AdminQueueItem, AdminUser, ArticlePreview, Feeds,
  FoundImages, GenerateSettings, Job, JobScript, JobVisuals, LoginResult, MyQueue, Options, ScriptSearch,
  ShareCopy, Story, TuwenTask, UploadResult, User, VisualChange,
} from "./types";

// ---------------------------------------------------------------- 登录
export const login = (employeeId: string) => post<LoginResult>("/login", { employee_id: employeeId });
export const logout = () => post<{ ok: boolean }>("/logout");
export const me = () => get<{ user: User }>("/me");
export const options = () => get<Options>("/options");

// ---------------------------------------------------------------- 新闻
export const feeds = (refresh = false) => get<Feeds>("/feeds", { refresh: refresh ? 1 : undefined });
/** 带封面图的列表（华人、24小时热门、一周热门、推荐、最新） */
export const tuwenFeed = (refresh = false) => get<Feeds>("/tuwen/feed", { refresh: refresh ? 1 : undefined });
/** 取出任何新闻链接的标题、正文、配图：泰国中文社、公众号、外站都可以 */
export const article = (url: string) => get<ArticlePreview>("/article", { url });

// ---------------------------------------------------------------- 生成
export interface CreateJob extends GenerateSettings {
  url: string;
  deep: boolean;
  /** 深度的提示（待开发：服务器写深度文案时参考） */
  deep_hint?: string;
}
export const createJob = (body: CreateJob) => post<Job>("/jobs", body);

export interface CreateUploadJob extends GenerateSettings {
  upload_ids: string[];
  mode: "rewrite" | "verbatim";
  text: string;
  title?: string;
  date?: string;
  signoff?: boolean;
  source_volume: number;
}
export const createUploadJob = (body: CreateUploadJob) => post<Job>("/jobs/upload", body);

export function uploadFile(file: File, onProgress?: (fraction: number) => void): Promise<UploadResult> {
  // 用 XHR 才能拿到上传进度
  return new Promise((resolve, reject) => {
    if (import.meta.env.VITE_MOCK === "1") {
      setTimeout(() => resolve({ upload_id: crypto.randomUUID().replace(/-/g, ""), kind: file.type.startsWith("video") ? "video" : "image", name: file.name }), 400);
      return;
    }
    const form = new FormData();
    form.append("file", file, file.name);
    const xhr = new XMLHttpRequest();
    xhr.open("POST", "/api/mobile/v1/uploads");
    const token = localStorage.getItem("kpos_token");
    if (token) xhr.setRequestHeader("Authorization", `Bearer ${token}`);
    xhr.upload.onprogress = (event) => event.lengthComputable && onProgress?.(event.loaded / event.total);
    xhr.onload = () => {
      let data: { error?: string } & Partial<UploadResult> = {};
      try {
        data = JSON.parse(xhr.responseText);
      } catch {
        /* 非 JSON */
      }
      if (xhr.status >= 200 && xhr.status < 300) resolve(data as UploadResult);
      else reject(new Error(data.error || `上传失败（${xhr.status}）`));
    };
    xhr.onerror = () => reject(new Error("上传中断，请检查网络后重试。"));
    xhr.send(form);
  });
}

// ---------------------------------------------------------------- 生成记录
export const jobs = (limit = 60) => get<{ jobs: Job[] }>("/jobs", { limit });
export const job = (id: string, logs = false) => get<Job>(`/jobs/${id}`, { logs: logs ? 1 : undefined });
export const cancelJob = (id: string) => post<Job>(`/jobs/${id}/cancel`);
export const retryJob = (id: string) => post<Job>(`/jobs/${id}/retry`, { idempotency_key: crypto.randomUUID() });
export const jobScript = (id: string) => get<JobScript>(`/jobs/${id}/script`);
export const rescript = (id: string, segments: string[]) => post<Job>(`/jobs/${id}/rescript`, { segments });
export const jobVisuals = (id: string) => get<JobVisuals>(`/jobs/${id}/visuals`);
export const revisuals = (id: string, changes: VisualChange[], segments?: string[]) =>
  post<Job>(`/jobs/${id}/revisuals`, segments ? { changes, segments } : { changes });
export const videoPath = (id: string) => `/jobs/${id}/video`;
export const coverPath = (id: string) => `/jobs/${id}/cover`;

/** 我同时在做的视频和今天额度（待开发；没有时前端从 /jobs 里数“处理中”的） */
export const myQueue = () => get<MyQueue>("/me/queue", undefined, { pending: true });

// ---------------------------------------------------------------- 图文
export const findImages = (url: string) => get<TuwenTask<FoundImages>>("/tuwen/images", { url });
export const story = (url: string) => get<TuwenTask<Story>>("/tuwen/story", { url });
export const shareCopy = (url: string, format: "platform" | "full") =>
  get<TuwenTask<ShareCopy>>("/tuwen/copy", { url, format });

// ---------------------------------------------------------------- 智能剪辑（待开发，见 docs/API.md）
export interface ScriptSearchBody {
  prompt: string;
  video_links: string[];
  clues: string;
  event_date?: string;
}
export const startScriptSearch = (body: ScriptSearchBody) => post<ScriptSearch>("/script/search", body, { pending: true });
export const scriptSearch = (id: string) => get<ScriptSearch>(`/script/search/${id}`, undefined, { pending: true });
export const createScriptJob = (body: GenerateSettings & { search_id: string; script: string; edit_mode: string }) =>
  post<Job>("/jobs/script", body, { pending: true });

// ---------------------------------------------------------------- 总后台（待开发，见 docs/API.md）
const admin = { base: ADMIN, pending: true };
export const adminOverview = (range: string) => request<AdminOverview>("GET", "/overview", { ...admin, query: { range } });
export const adminJobs = (query: { day?: string; kind?: string; q?: string }) =>
  request<{ jobs: AdminJob[]; totals: { count: number; tokens: number; usd: number; voice_chars: number; minutes: string } }>(
    "GET", "/jobs", { ...admin, query });
export const adminUsers = (query: { role?: string; q?: string }) => request<{ users: AdminUser[] }>("GET", "/users", { ...admin, query });
export const adminSaveUser = (employeeId: string, body: Record<string, unknown>) =>
  request<{ ok: boolean }>("POST", `/users/${employeeId}`, { ...admin, json: body });
export const adminCreateUser = (body: { name: string; department: string; role: string }) =>
  request<{ employee_id: string }>("POST", "/users", { ...admin, json: body });
export const adminDepth = () => request<AdminDepth>("GET", "/depth", admin);
export const adminSaveDepth = (body: AdminDepth) => request<{ ok: boolean }>("POST", "/depth", { ...admin, json: body });
export const adminNodes = () => request<{ nodes: AdminNode[]; queue: AdminQueueItem[]; rules: { per_node: number; alert_minutes: number; retries: number; keep_days: number; per_user: number } }>(
  "GET", "/nodes", admin);
