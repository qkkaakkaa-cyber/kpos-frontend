// 和服务器 /api/mobile/v1 返回的字段一一对应（服务器用下划线命名，这里原样保留）。

export interface User {
  employee_id: string;
  name: string;
  role: string; // editor / chief / admin ...
}

export interface LoginResult {
  token: string;
  user: User;
  expires_in: number;
}

export interface Voice {
  id: string;
  provider: string;
  code: string;
  name: string;
  gender: string;
  description: string;
}

export interface Options {
  durations: number[];
  upload_durations: number[];
  default_duration: number;
  processing?: string;
  voices: Voice[];
  providers: { id: string; name: string; ready: boolean }[];
  default_voice: string;
  music: { id: string; name: string }[];
  default_music: string;
  bgm_volume: { default: number; max: number };
  source_volume: { default: number; max: number };
  upload_limits: { files: number; video_mb: number; image_mb: number; material_chars: number; script_chars: number };
}

export interface FeedItem {
  title: string;
  url: string;
  date: string;
  media: string;
  topic: string;
  reason: string;
  tags: string[];
  media_count: number;
  move: "" | "up" | "down" | "same" | "new";
  move_by: number;
  /** 只有 /tuwen/feed 有：封面图（相对接口前缀的路径）和是否华人新闻 */
  image?: string;
  chinese?: boolean;
  /** 原图张数（服务器待加，见 docs/API.md） */
  photos?: number;
}

export interface FeedSection {
  id: string;
  name: string;
  items: FeedItem[];
  error: string;
}

export interface Feeds {
  fetched_at: string;
  sections: FeedSection[];
}

export interface ArticlePreview {
  url: string;
  title: string;
  source: string;
  date: string;
  chars: number;
  paragraphs: string[];
  images: string[];
  foreign: boolean;
}

export interface JobStep {
  key: string;
  name: string;
  state: string; // done / running / pending / failed
  detail: string;
}

export interface Job {
  id: string;
  state: "processing" | "complete" | "failed" | "cancelled";
  progress: number;
  phase: string;
  error: string;
  title: string;
  publication_title: string;
  source_url: string;
  uploaded: boolean;
  created_at: string;
  has_video: boolean;
  has_cover: boolean;
  video_bytes: number;
  server_video_deleted: boolean;
  video_expires_at?: string | null;
  can_cancel: boolean;
  cancel_requested: boolean;
  deep: boolean;
  script_ready: boolean;
  steps: JobStep[];
  logs?: string[];
  /** 排队位置（服务器待加，见 docs/API.md）；0 或没有 = 正在剪 */
  queue_position?: number;
}

export interface JobScript {
  segments: string[];
  chars: number;
  seconds: number;
  editable: boolean;
  ready: boolean;
}

export interface TuwenTask<T> {
  state: "running" | "done" | "error";
  step: string;
  error: string;
  elapsed: number;
  result: T | null;
}

export interface FoundImages {
  title: string;
  images: { path: string; source: string; width: number; height: number }[];
  checked: boolean;
  masked: number;
  removed: { duplicates: number; unsuitable: number; reasons: Record<string, number> };
  media: string[];
  searches: { site: string; keyword: string; url: string }[];
}

export interface Story {
  title: string;
  summary: string;
  now: string;
  timeline: { date: string; text: string }[];
  facts: { label: string; value: string }[];
  related: { title: string; date: string }[];
}

export interface ShareCopy {
  format: "platform" | "full";
  title: string;
  body: string;
  signoff: string;
  chars: number;
  limit: number;
  tags: string[];
}

export interface JobVisual {
  key: string;
  kind: "photo" | "card" | "video";
  uses: number;
  seconds: number;
  frame: string;
  photo: string;
  exists: boolean;
}

export interface JobVisuals {
  editable: boolean;
  reason: string;
  items: JobVisual[];
}

export interface VisualChange {
  key: string;
  action: "remove" | "replace";
  upload?: string;
  picture?: string;
}

export interface UploadResult {
  upload_id: string;
  kind: "video" | "image";
  name: string;
}

/** 生成设置：POST /jobs 和 /jobs/upload 共用 */
export interface GenerateSettings {
  voice: string;
  music: string;
  bgm_volume: number;
  duration: number;
  /** 语速、配音音量：服务器目前读后台默认值，待加（见 docs/API.md） */
  voice_rate?: number;
  voice_volume?: number;
}

// ---------------------------------------------------------------- 待开发接口的数据（见 docs/API.md）

export interface MyQueue {
  limit: number;
  running: Job[];
  quota: { quick: [number, number]; deep: [number, number] };
}

export interface ScriptSearch {
  id: string;
  state: "running" | "done" | "error";
  phase: string;
  error: string;
  candidates: { id: string; kind: "video" | "image"; source: string; thumb: string; length?: string; ok: boolean; reason?: string }[];
  excluded: number;
  unreadable: number;
  script: string;
  sources: { title: string; url: string }[];
  modes: string[];
}

export interface AdminOverview {
  today: { jobs: number; quick: number; deep: number; vs_yesterday: number; success_rate: number; failed: number; cancelled: number; running: number };
  tokens: { total: number; input: number; output: number };
  cost: { usd: number; thb: number; voice_usd: number };
  nodes: { online: number; total: number; queued: number; clear_minutes: number };
  daily: { date: string; research: number; script: number; other: number }[];
}

export interface AdminJob {
  id: string;
  at: string;
  user: string;
  title: string;
  kind: "快讯" | "深度" | "上传素材" | "智能剪辑";
  depth: string;
  state: string;
  length: string;
  took: string;
  tokens: number;
  usd: number;
}

export interface AdminUser {
  employee_id: string;
  name: string;
  role: "实习编辑" | "编辑" | "主编" | "管理员";
  department: string;
  status: "正常" | "已停用" | "额度用完" | "还没登录过";
  quick: number;
  deep: number;
  tokens: number;
  usd: number;
  today: string;
  last_seen: string;
}

export interface AdminDepth {
  quick: { seconds: number; rewrite: string; research: string; footage: string; check: string; tokens: number; usd: number };
  deep: { minutes: string; reports: number; days: number; clips: number; cross_check: number; check: string; tokens: number; usd: number };
  models: { step: string; note: string; model: string; input: number; output: number }[];
  budget: { daily: number; monthly: number; alert: number; over: string; voice_per_k: number; thb_rate: number };
}

export interface AdminNode {
  name: string;
  spec: string;
  state: "工作中" | "重试中" | "空闲" | "离线";
  doing: string;
  cpu: number;
  gpu: number;
  disk: number;
  done_today: number;
  heartbeat: string;
}

export interface AdminQueueItem {
  position: number;
  user: string;
  title: string;
  kind: string;
  eta: string;
  node: string;
}
