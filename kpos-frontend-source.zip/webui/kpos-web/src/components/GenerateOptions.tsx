import { useEffect } from "react";
import type { GenerateSettings, Options } from "../api/types";
import { useLocal } from "../hooks/useApi";
import { Seg } from "./ui";

export interface Settings extends GenerateSettings {
  voice_rate: number;
  voice_volume: number;
}

/** 制作选项：配音、语速、音量、背景音乐、时长。改过的记在本机，下次默认。 */
export function useGenerateSettings(options: Options | null, scope: "news" | "upload" | "script") {
  const [settings, setSettings] = useLocal<Settings>(`settings-${scope}`, {
    voice: "", music: "", bgm_volume: 5, duration: scope === "script" ? 90 : scope === "upload" ? 45 : 60,
    voice_rate: 1.0, voice_volume: 100,
  });
  // 服务器给的默认值补进来；保存过的配音已经下架时换成默认配音
  useEffect(() => {
    if (!options) return;
    const voiceOk = options.voices.some((voice) => voice.id === settings.voice);
    const musicOk = options.music.some((music) => music.id === settings.music);
    if (!voiceOk || !musicOk) {
      setSettings({
        ...settings,
        voice: voiceOk ? settings.voice : options.default_voice,
        music: musicOk ? settings.music : options.default_music,
        bgm_volume: settings.bgm_volume ?? options.bgm_volume.default,
      });
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [options]);
  return [settings, setSettings] as const;
}

export function GenerateOptions({ options, settings, onChange, durations, durationNote }: {
  options: Options | null;
  settings: Settings;
  onChange: (settings: Settings) => void;
  durations: number[];
  durationNote?: string;
}) {
  const set = <K extends keyof Settings>(key: K, value: Settings[K]) => onChange({ ...settings, [key]: value });
  const voices = options?.voices || [];
  const readyProviders = new Set((options?.providers || []).filter((provider) => provider.ready).map((provider) => provider.id));
  const voice = voices.find((item) => item.id === settings.voice);
  return (
    <div className="opts">
      <div className="opt"><span className="bold">制作选项</span><span className="small muted right-auto">改了会记住，下次默认</span></div>
      <div className="opt">
        <span className="k">视频长度</span>
        {durations.length > 1
          ? <Seg value={settings.duration} options={durations.map((value) => ({ value, label: `${value}秒` }))} onChange={(value) => set("duration", value)} />
          : <span className="chip c-g">{durations[0]}秒以内</span>}
        {durationNote && <span className="small muted right-auto" style={{ maxWidth: 120 }}>{durationNote}</span>}
      </div>
      <div className="opt">
        <span className="k">配音</span>
        <select className="select grow" style={{ height: 34 }} value={settings.voice} onChange={(event) => set("voice", event.target.value)} aria-label="配音">
          {voices.map((item) => (
            <option key={item.id} value={item.id} disabled={!readyProviders.has(item.provider)}>
              {item.code} {item.name}{item.description ? ` · ${item.description}` : ""}{readyProviders.has(item.provider) ? "" : "（未配置）"}
            </option>
          ))}
        </select>
      </div>
      {voice && <div className="opt small muted" style={{ minHeight: 0, paddingTop: 0 }}><span className="k" />{voice.provider === "elevenlabs" ? "ElevenLabs" : "MiniMax"} · {voice.gender || "—"}</div>}
      <div className="opt">
        <span className="k">语速</span>
        <Seg value={settings.voice_rate} options={[0.9, 1.0, 1.1, 1.2].map((value) => ({ value, label: value.toFixed(1) }))} onChange={(value) => set("voice_rate", value)} />
      </div>
      <div className="opt">
        <span className="k">配音音量</span>
        <input type="range" min={50} max={200} step={10} value={settings.voice_volume} onChange={(event) => set("voice_volume", Number(event.target.value))} aria-label="配音音量" />
        <span className="small num muted" style={{ width: 40, textAlign: "right" }}>{settings.voice_volume}%</span>
      </div>
      <div className="opt">
        <span className="k">背景音乐</span>
        <select className="select grow" style={{ height: 34 }} value={settings.music} onChange={(event) => set("music", event.target.value)} aria-label="背景音乐">
          {(options?.music || []).map((item) => <option key={item.id} value={item.id}>{item.name}</option>)}
        </select>
      </div>
      <div className="opt">
        <span className="k">音乐音量</span>
        <input type="range" min={0} max={options?.bgm_volume.max ?? 5} step={1} value={settings.bgm_volume} onChange={(event) => set("bgm_volume", Number(event.target.value))} aria-label="背景音乐音量" />
        <span className="small num muted" style={{ width: 40, textAlign: "right" }}>{settings.bgm_volume}%</span>
      </div>
    </div>
  );
}
