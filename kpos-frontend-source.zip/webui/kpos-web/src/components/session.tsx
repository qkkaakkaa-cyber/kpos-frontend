import { createContext, useCallback, useContext, useEffect, useState, type ReactNode } from "react";
import { getToken, handleUnauthorized, setToken } from "../api/client";
import * as api from "../api/endpoints";
import type { Options, User } from "../api/types";

interface Session {
  user: User | null;
  options: Options | null;
  ready: boolean;
  signIn: (employeeId: string) => Promise<void>;
  signOut: () => Promise<void>;
}

const SessionContext = createContext<Session | null>(null);

export function SessionProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  const [options, setOptions] = useState<Options | null>(null);
  const [ready, setReady] = useState(false);

  const loadOptions = useCallback(() => {
    api.options().then(setOptions).catch(() => setOptions(null));
  }, []);

  useEffect(() => {
    handleUnauthorized(() => setUser(null));
    if (!getToken()) {
      setReady(true);
      return;
    }
    api.me()
      .then(({ user: current }) => {
        setUser(current);
        loadOptions();
      })
      .catch(() => setToken(""))
      .finally(() => setReady(true));
  }, [loadOptions]);

  const signIn = useCallback(async (employeeId: string) => {
    const result = await api.login(employeeId);
    setToken(result.token);
    setUser(result.user);
    loadOptions();
  }, [loadOptions]);

  const signOut = useCallback(async () => {
    try {
      await api.logout();
    } finally {
      setToken("");
      setUser(null);
    }
  }, []);

  return <SessionContext.Provider value={{ user, options, ready, signIn, signOut }}>{children}</SessionContext.Provider>;
}

export function useSession() {
  const session = useContext(SessionContext);
  if (!session) throw new Error("useSession 必须在 SessionProvider 里用");
  return session;
}

/** 管理员和主编能进总后台（服务器上的角色名按实际改） */
export const canSeeAdmin = (user: User | null) => !!user && ["admin", "管理员", "chief", "主编"].includes(user.role);
