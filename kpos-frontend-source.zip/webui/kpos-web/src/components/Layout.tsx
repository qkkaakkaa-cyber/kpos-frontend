import { useEffect, useState, type ReactNode } from "react";
import { Link, NavLink, Outlet, useNavigate } from "react-router-dom";
import { onPendingChange, pendingInUse } from "../api/client";
import * as api from "../api/endpoints";
import type { Job, MyQueue } from "../api/types";
import { usePolling } from "../hooks/useApi";
import { canSeeAdmin, useSession } from "./session";
import { Icon, Logo } from "./ui";

const STAFF_NAV = [
  { to: "/news", icon: "news", label: "新闻" },
  { to: "/wechat", icon: "wechat", label: "公众号剪辑" },
  { to: "/script", icon: "pen", label: "智能剪辑" },
  { to: "/upload", icon: "upload", label: "手动上传" },
  { to: "/jobs", icon: "list", label: "生成记录" },
];

const ADMIN_NAV = [
  { to: "/admin", icon: "chart", label: "概览", end: true },
  { to: "/admin/jobs", icon: "list", label: "剪辑记录" },
  { to: "/admin/users", icon: "user", label: "员工用量" },
  { to: "/admin/depth", icon: "sliders", label: "深度与模型" },
  { to: "/admin/nodes", icon: "cpu", label: "剪辑机与队列" },
  { to: "/admin/accounts", icon: "key", label: "员工账号" },
];

/** 我同时在做的视频：优先读 /me/queue，没有这个接口时从 /jobs 里数 */
function useMyQueue() {
  const [queue, setQueue] = useState<MyQueue | null>(null);
  const load = () => {
    api.myQueue().then(setQueue).catch(() =>
      api.jobs(30).then(({ jobs }) => setQueue({
        limit: 5, running: jobs.filter((job) => job.state === "processing"), quota: { quick: [0, 0], deep: [0, 0] },
      })).catch(() => undefined));
  };
  useEffect(load, []);
  usePolling(load, 8000);
  return queue;
}

function QueueWidget() {
  const queue = useMyQueue();
  if (!queue) return null;
  const running = queue.running.slice(0, 5);
  const line = (job: Job) => {
    const waiting = (job.queue_position || 0) > 0;
    return (
      <Link key={job.id} to={`/jobs/${job.id}`} style={{ display: "flex", flexDirection: "column", gap: 3, textDecoration: "none", color: "inherit" }}>
        <span className="row" style={{ gap: 6 }}>
          <span className="small bold ellipsis grow">{job.title || "新闻视频"}</span>
          {waiting ? <span className="small num muted bold">#{job.queue_position}</span>
            : <span className="small num bold" style={{ color: "var(--accent-ink)" }}>{job.progress}%</span>}
        </span>
        <span style={{ fontSize: 11, lineHeight: "14px", color: "var(--muted)" }}>
          {job.deep ? "深度" : "快讯"} · {waiting ? `排第 ${job.queue_position} 位` : "剪辑中"}
        </span>
        {!waiting && <span className="bar" style={{ height: 4 }}><i style={{ width: `${job.progress}%` }} /></span>}
      </Link>
    );
  };
  return (
    <div style={{ marginTop: "auto", padding: 12, borderRadius: 12, background: "var(--bg)", display: "flex", flexDirection: "column", gap: 9 }}>
      <span className="small bold row" style={{ gap: 6 }}>
        <span className="dot" style={{ background: running.length ? "var(--accent)" : "var(--faint)" }} />
        进行中 {running.length} 条
        <span className="muted right-auto" style={{ whiteSpace: "nowrap" }}>上限 {queue.limit} 条</span>
      </span>
      {running.length ? running.map(line) : <span className="small muted">现在没有在做的视频</span>}
      {queue.quota.quick[1] > 0 && (
        <span className="small muted">今天额度：快讯 {queue.quota.quick[0]}/{queue.quota.quick[1]} · 深度 {queue.quota.deep[0]}/{queue.quota.deep[1]}</span>
      )}
    </div>
  );
}

function PendingBanner() {
  const [, force] = useState(0);
  useEffect(() => {
    const stop = onPendingChange(() => force((value) => value + 1));
    return () => { stop(); };
  }, []);
  if (!pendingInUse.size) return null;
  return (
    <div className="pending-banner">
      接口待开发，下面是示例数据：{[...pendingInUse].join("、")}（见 docs/API.md）
    </div>
  );
}

function Who({ dark }: { dark?: boolean }) {
  const { user, signOut } = useSession();
  const navigate = useNavigate();
  if (!user) return null;
  return (
    <div className="row" style={{ padding: "12px 8px 0", gap: 8 }}>
      <span style={{ width: 32, height: 32, borderRadius: 9999, background: dark ? "rgba(255,255,255,.14)" : "var(--brand-soft)", color: dark ? "#fff" : "var(--brand-deep)", display: "flex", alignItems: "center", justifyContent: "center", fontWeight: 700, flex: "none" }}>
        {(user.name || "我").slice(0, 1)}
      </span>
      <span className="grow" style={{ display: "flex", flexDirection: "column", lineHeight: "18px", fontSize: 13, fontWeight: 600 }}>
        {user.name || "员工"}
        <span className="small" style={{ color: dark ? "#a89bd0" : "var(--muted)", fontWeight: 500 }}>工号 {user.employee_id.slice(0, 4)}••</span>
      </span>
      <button className="btn sm ghost" title="退出登录" aria-label="退出登录" onClick={async () => { await signOut(); navigate("/login"); }}>
        <Icon name="logout" size={14} />
      </button>
    </div>
  );
}

export function StaffLayout() {
  const { user } = useSession();
  return (
    <div className="app">
      <aside className="side">
        <div className="brand"><Logo /><span>KPOS<small>中文社传媒 · 剪辑工作台</small></span></div>
        {STAFF_NAV.map((item) => (
          <NavLink key={item.to} to={item.to} className={({ isActive }) => `nav${isActive ? " active" : ""}`}>
            <Icon name={item.icon} size={20} />{item.label}
          </NavLink>
        ))}
        {canSeeAdmin(user) && (
          <NavLink to="/admin" className="nav"><Icon name="shield" size={20} />总后台</NavLink>
        )}
        <QueueWidget />
        <Who />
      </aside>
      <div className="main">
        <PendingBanner />
        <Outlet />
      </div>
    </div>
  );
}

export function AdminLayout() {
  return (
    <div className="app">
      <aside className="side admin">
        <div className="brand"><Logo light /><span>KPOS<small>总后台</small></span></div>
        {ADMIN_NAV.map((item) => (
          <NavLink key={item.to} to={item.to} end={item.end} className={({ isActive }) => `nav${isActive ? " active" : ""}`}>
            <Icon name={item.icon} size={20} />{item.label}
          </NavLink>
        ))}
        <div className="navlabel">其他</div>
        <NavLink to="/news" className="nav"><Icon name="back" size={20} />回剪辑工作台</NavLink>
        <div style={{ marginTop: "auto" }} />
        <Who dark />
      </aside>
      <div className="main">
        <PendingBanner />
        <Outlet />
      </div>
    </div>
  );
}

export function TopBar({ title, sub, children, back }: { title?: ReactNode; sub?: ReactNode; children?: ReactNode; back?: { to: string; label: string } }) {
  return (
    <header className="top">
      {back && <Link to={back.to} className="row" style={{ gap: 2, textDecoration: "none", fontWeight: 600 }}><Icon name="back" size={20} />{back.label}</Link>}
      {back && title && <span style={{ width: 1, height: 20, background: "var(--line)" }} />}
      {title && <h1 style={back ? { fontSize: 17 } : undefined}>{title}</h1>}
      {sub && <span className="sub">{sub}</span>}
      {children && <div className="right">{children}</div>}
    </header>
  );
}
