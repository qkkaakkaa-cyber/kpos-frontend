import { useEffect, useState, type ReactNode } from "react";
import { blobUrl } from "../api/client";

// ---------------------------------------------------------------- 图标（线条图标，24 网格）
const PATHS: Record<string, string> = {
  news: '<path d="M4 5h13v14H6a2 2 0 0 1-2-2z"/><path d="M17 9h3v8a2 2 0 0 1-2 2"/><path d="M8 9h5M8 13h5"/>',
  wechat: '<path d="M9.5 5C5.4 5 2 7.7 2 11c0 1.9 1.1 3.6 2.9 4.7L4 18.5l3.2-1.6c.7.2 1.5.3 2.3.3"/><path d="M22 14.5c0-2.8-2.9-5-6.5-5S9 11.7 9 14.5 11.9 19.5 15.5 19.5c.7 0 1.3-.1 1.9-.3l2.6 1.3-.7-2.3c1.6-.9 2.7-2.3 2.7-3.7z"/>',
  pen: '<path d="M12 20h9"/><path d="M16.5 3.5a2.1 2.1 0 0 1 3 3L7 19l-4 1 1-4z"/>',
  upload: '<path d="M12 15V3M7 8l5-5 5 5"/><path d="M5 12v7a1 1 0 0 0 1 1h12a1 1 0 0 0 1-1v-7"/>',
  list: '<path d="M9 6h11M9 12h11M9 18h11"/><circle cx="4.5" cy="6" r="1"/><circle cx="4.5" cy="12" r="1"/><circle cx="4.5" cy="18" r="1"/>',
  user: '<circle cx="12" cy="8" r="4"/><path d="M4 21c1.5-4 4.5-6 8-6s6.5 2 8 6"/>',
  play: '<rect x="3" y="6" width="18" height="14" rx="2"/><path d="M10 10v6l5-3z"/>',
  image: '<rect x="3" y="4" width="18" height="16" rx="2"/><path d="M3 16l5-5 4 4 3-3 6 6"/><circle cx="15.5" cy="8.5" r="1.5"/>',
  bolt: '<path d="M13 2L4 14h7l-1 8 9-12h-7z"/>',
  search: '<circle cx="11" cy="11" r="7"/><path d="M21 21l-5-5"/>',
  link: '<path d="M10 14a4 4 0 0 0 5.7 0l3-3a4 4 0 0 0-5.7-5.7l-1 1"/><path d="M14 10a4 4 0 0 0-5.7 0l-3 3a4 4 0 0 0 5.7 5.7l1-1"/>',
  back: '<path d="M15 5l-7 7 7 7"/>',
  next: '<path d="M9 5l7 7-7 7"/>',
  down: '<path d="M6 9l6 6 6-6"/>',
  edit: '<path d="M4 20h4l10-10-4-4L4 16z"/><path d="M13 7l4 4"/>',
  download: '<path d="M12 4v11M7 10l5 5 5-5"/><path d="M5 20h14"/>',
  copy: '<rect x="9" y="9" width="11" height="11" rx="2"/><path d="M5 15V5a1 1 0 0 1 1-1h10"/>',
  clock: '<path d="M3 12a9 9 0 1 0 3-6.7"/><path d="M3 4v5h5"/><path d="M12 8v4l3 2"/>',
  check: '<path d="M5 12l5 5 9-10"/>',
  x: '<path d="M6 6l12 12M18 6L6 18"/>',
  ext: '<path d="M14 4h6v6"/><path d="M20 4l-9 9"/><path d="M19 14v5a1 1 0 0 1-1 1H5a1 1 0 0 1-1-1V6a1 1 0 0 1 1-1h5"/>',
  refresh: '<path d="M20 11a8 8 0 1 0-2.3 5.7"/><path d="M20 5v6h-6"/>',
  shield: '<path d="M12 3l8 3v6c0 4.5-3.5 8-8 9-4.5-1-8-4.5-8-9V6z"/><path d="M9 12l2 2 4-4"/>',
  hourglass: '<path d="M7 3h10M7 21h10M8 3c0 5 8 5 8 9s-8 4-8 9M16 3c0 5-8 5-8 9"/>',
  chart: '<path d="M4 20V10M10 20V4M16 20v-7M22 20H2"/>',
  cpu: '<rect x="6" y="6" width="12" height="12" rx="2"/><path d="M9 2v4M15 2v4M9 18v4M15 18v4M2 9h4M2 15h4M18 9h4M18 15h4"/>',
  sliders: '<path d="M4 6h10M18 6h2M4 12h4M12 12h8M4 18h12M20 18h0"/><circle cx="16" cy="6" r="2"/><circle cx="10" cy="12" r="2"/><circle cx="18" cy="18" r="2"/>',
  key: '<circle cx="8" cy="15" r="4"/><path d="M11 12l9-9M17 6l3 3"/>',
  logout: '<path d="M15 4h4a1 1 0 0 1 1 1v14a1 1 0 0 1-1 1h-4"/><path d="M10 17l-5-5 5-5M5 12h11"/>',
  trash: '<path d="M4 7h16M10 11v6M14 11v6M6 7l1 13h10l1-13M9 7V4h6v3"/>',
  undo: '<path d="M9 14L4 9l5-5"/><path d="M4 9h11a5 5 0 0 1 0 10h-3"/>',
  speaker: '<path d="M4 9v6h4l5 4V5L8 9z"/><path d="M16 9a4 4 0 0 1 0 6"/>',
  expand: '<path d="M4 9V4h5M20 9V4h-5M4 15v5h5M20 15v5h-5"/>',
};

export function Icon({ name, size = 18, color = "currentColor", width = 2 }: { name: string; size?: number; color?: string; width?: number }) {
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke={color} strokeWidth={width}
      strokeLinecap="round" strokeLinejoin="round" aria-hidden="true" style={{ flex: "none" }}
      dangerouslySetInnerHTML={{ __html: PATHS[name] || "" }} />
  );
}

export function Logo({ size = 34, light = false }: { size?: number; light?: boolean }) {
  return (
    <svg width={size} height={size} viewBox="0 0 40 40" role="img" aria-label="KPOS" style={{ flex: "none" }}>
      <rect width="40" height="40" rx="11" fill={light ? "#FFFFFF" : "#6A55A0"} />
      <path d="M12 10v20M12 21l10-11M15.5 17.5L23 30" stroke={light ? "#2E2552" : "#FFFFFF"} strokeWidth="4" strokeLinecap="round" strokeLinejoin="round" fill="none" />
      <path d="M26 22.5v9l7-4.5z" fill="#FFC93C" />
    </svg>
  );
}

// ---------------------------------------------------------------- 需要登录的图片
export function AuthImage({ path, alt = "", style, className }: { path?: string; alt?: string; style?: React.CSSProperties; className?: string }) {
  const [src, setSrc] = useState("");
  const [failed, setFailed] = useState(false);
  useEffect(() => {
    let alive = true;
    setSrc("");
    setFailed(false);
    if (!path) return;
    blobUrl(path).then((url) => alive && setSrc(url)).catch(() => alive && setFailed(true));
    return () => {
      alive = false;
    };
  }, [path]);
  if (!src) {
    return <span className={className} style={{ display: "block", width: "100%", height: "100%", background: failed ? "var(--line-2)" : "var(--brand-soft)", ...style }} aria-label={alt} />;
  }
  return <img src={src} alt={alt} className={className} style={{ width: "100%", height: "100%", objectFit: "cover", ...style }} />;
}

// ---------------------------------------------------------------- 小部件
export function Spinner() {
  return <span className="spinner" role="status" aria-label="加载中" />;
}

export function Loading({ text = "正在加载…" }: { text?: string }) {
  return <div className="row" style={{ justifyContent: "center", padding: "32px 0", color: "var(--muted)" }}><Spinner />{text}</div>;
}

export function ErrorBox({ message, onRetry }: { message: string; onRetry?: () => void }) {
  return (
    <div className="note row" role="alert">
      <span className="grow">{message}</span>
      {onRetry && <button className="btn sm ghost" onClick={onRetry}>重试</button>}
    </div>
  );
}

export function RankMove({ move, by }: { move?: string; by?: number }) {
  if (move === "up") return <span className="small rise num" title={`较上一轮上升${by}名`}>▲{by}</span>;
  if (move === "down") return <span className="small fall num" title={`较上一轮下降${by}名`}>▼{by}</span>;
  if (move === "new") return <span className="chip c-w" style={{ padding: "0 5px" }}>新</span>;
  if (move === "same") return <span className="small faint bold">–</span>;
  return null;
}

export function Heat({ value, top }: { value: number; top: number }) {
  if (!value || !top) return null;
  return (
    <span style={{ display: "inline-flex", alignItems: "center", gap: 6, color: "var(--brand-deep)", fontWeight: 600 }}>
      <span className="heat"><i style={{ width: `${Math.round((value / top) * 100)}%` }} /></span>{value}家媒体
    </span>
  );
}

export function Seg<T extends string | number>({ value, options, onChange, full }: {
  value: T; options: { value: T; label: ReactNode }[]; onChange: (value: T) => void; full?: boolean;
}) {
  return (
    <span className={`seg${full ? " full" : ""}`} role="radiogroup">
      {options.map((option) => (
        <button key={String(option.value)} type="button" role="radio" aria-checked={option.value === value}
          className={option.value === value ? "on" : ""} onClick={() => onChange(option.value)}>
          {option.label}
        </button>
      ))}
    </span>
  );
}

export function Tabs<T extends string>({ value, options, onChange, right }: {
  value: T; options: { value: T; label: ReactNode }[]; onChange: (value: T) => void; right?: ReactNode;
}) {
  return (
    <div className="tabs" role="tablist">
      {options.map((option) => (
        <button key={option.value} type="button" role="tab" aria-selected={option.value === value}
          className={`tab${option.value === value ? " on" : ""}`} onClick={() => onChange(option.value)}>
          {option.label}
        </button>
      ))}
      {right && <span className="right-auto">{right}</span>}
    </div>
  );
}

/** 页面底部的提示条，3 秒后消失 */
export function useToast(): [ReactNode, (text: string) => void] {
  const [text, setText] = useState("");
  useEffect(() => {
    if (!text) return;
    const timer = setTimeout(() => setText(""), 3200);
    return () => clearTimeout(timer);
  }, [text]);
  return [text ? <div className="toast" role="status">{text}</div> : null, setText];
}

export function Modal({ title, onClose, children }: { title: string; onClose: () => void; children: ReactNode }) {
  useEffect(() => {
    const handler = (event: KeyboardEvent) => event.key === "Escape" && onClose();
    window.addEventListener("keydown", handler);
    return () => window.removeEventListener("keydown", handler);
  }, [onClose]);
  return (
    <div className="modal-back" onClick={onClose}>
      <div className="modal" role="dialog" aria-label={title} onClick={(event) => event.stopPropagation()}>
        <div className="row"><span className="h2 grow">{title}</span><button className="btn sm ghost" onClick={onClose} aria-label="关闭"><Icon name="x" size={14} /></button></div>
        {children}
      </div>
    </div>
  );
}

export function formatTime(value: string) {
  const date = new Date(value);
  if (Number.isNaN(date.getTime())) return value;
  const now = new Date();
  const time = date.toLocaleTimeString("zh-CN", { hour: "2-digit", minute: "2-digit", hour12: false, timeZone: "Asia/Bangkok" });
  const day = (d: Date) => d.toLocaleDateString("zh-CN", { timeZone: "Asia/Bangkok" });
  if (day(date) === day(now)) return time;
  const yesterday = new Date(now.getTime() - 86400000);
  if (day(date) === day(yesterday)) return `昨天 ${time}`;
  return `${date.toLocaleDateString("zh-CN", { month: "numeric", day: "numeric", timeZone: "Asia/Bangkok" })} ${time}`;
}

export function relativeTime(value: string) {
  const minutes = Math.round((Date.now() - new Date(value).getTime()) / 60000);
  if (!Number.isFinite(minutes)) return "";
  if (minutes < 1) return "刚刚";
  if (minutes < 60) return `${minutes}分钟前`;
  if (minutes < 24 * 60) return `${Math.round(minutes / 60)}小时前`;
  return formatTime(value);
}
