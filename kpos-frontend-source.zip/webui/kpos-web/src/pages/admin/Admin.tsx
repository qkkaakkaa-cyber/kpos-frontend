// 总后台：这些接口服务器还没有（/api/admin/v1，见 docs/API.md），现在显示的是示例数据。
import { useMemo, useState } from "react";
import * as api from "../../api/endpoints";
import type { AdminDepth, AdminUser } from "../../api/types";
import { TopBar } from "../../components/Layout";
import { ErrorBox, Icon, Loading, Modal, Seg, useToast } from "../../components/ui";
import { useApi } from "../../hooks/useApi";

const money = (value: number) => `US$ ${value.toFixed(2)}`;
const tokens = (value: number) => (value >= 1_000_000 ? `${(value / 1_000_000).toFixed(2)}M` : value >= 1000 ? `${Math.round(value / 1000)}K` : String(value));

// ---------------------------------------------------------------- 概览
export function Overview() {
  const [range, setRange] = useState("today");
  const { data, error, loading, reload } = useApi(() => api.adminOverview(range), [range]);
  const max = Math.max(1, ...(data?.daily || []).map((day) => day.research + day.script + day.other));
  return (
    <>
      <TopBar title="概览" sub="每个人剪了什么、用了多少 Token、花了多少钱">
        <Seg value={range} onChange={setRange} options={[{ value: "today", label: "今天" }, { value: "7d", label: "7 天" }, { value: "30d", label: "30 天" }, { value: "month", label: "本月" }]} />
      </TopBar>
      <div className="page col">
        {loading && <Loading />}
        {error && <ErrorBox message={error} onRetry={reload} />}
        {data && (
          <>
            <div style={{ display: "grid", gridTemplateColumns: "repeat(5, minmax(0, 1fr))", gap: 16 }}>
              <div className="card kpi"><span className="lab">剪辑</span><span className="val">{data.today.jobs}<small>条</small></span><span className="foot">快讯 {data.today.quick} · 深度 {data.today.deep} · <span className="up">比昨天 {data.today.vs_yesterday >= 0 ? "+" : ""}{data.today.vs_yesterday}</span></span></div>
              <div className="card kpi"><span className="lab">成功率</span><span className="val">{data.today.success_rate}<small>%</small></span><span className="foot">失败 {data.today.failed} · 终止 {data.today.cancelled} · 生成中 {data.today.running}</span></div>
              <div className="card kpi"><span className="lab">Token 消耗</span><span className="val">{tokens(data.tokens.total)}</span><span className="foot">输入 {tokens(data.tokens.input)} · 输出 {tokens(data.tokens.output)}</span></div>
              <div className="card kpi"><span className="lab">AI 费用</span><span className="val">{money(data.cost.usd)}</span><span className="foot">≈ ฿ {data.cost.thb} · 其中配音 {money(data.cost.voice_usd)}</span></div>
              <div className="card kpi"><span className="lab">剪辑机</span><span className="val">{data.nodes.online} / {data.nodes.total}<small>在线</small></span><span className="foot">排队 {data.nodes.queued} 条 · 预计 {data.nodes.clear_minutes} 分钟清空</span></div>
            </div>
            <div className="card pad col">
              <div className="row"><span className="h2">近 14 天 Token 消耗</span>
                <span className="row small muted right-auto" style={{ gap: 14 }}>
                  <span className="row" style={{ gap: 5 }}><span className="dot" style={{ background: "var(--brand)" }} />查来龙去脉</span>
                  <span className="row" style={{ gap: 5 }}><span className="dot" style={{ background: "var(--accent)" }} />写口播文案</span>
                  <span className="row" style={{ gap: 5 }}><span className="dot" style={{ background: "var(--yellow)" }} />标题·翻译·排行</span>
                </span></div>
              <div style={{ display: "flex", alignItems: "flex-end", gap: 10, height: 220, paddingTop: 10 }}>
                {data.daily.map((day) => {
                  const total = day.research + day.script + day.other;
                  return (
                    <div key={day.date} style={{ flex: 1, display: "flex", flexDirection: "column", alignItems: "center", gap: 6 }} title={`${day.date}：查来龙去脉 ${day.research.toFixed(2)}M · 写口播 ${day.script.toFixed(2)}M · 其他 ${day.other.toFixed(2)}M`}>
                      <div style={{ width: "100%", maxWidth: 36, height: (total / max) * 180, display: "flex", flexDirection: "column-reverse", borderRadius: 6, overflow: "hidden", gap: 2 }}>
                        <i style={{ flex: day.research, background: "var(--brand)" }} /><i style={{ flex: day.script, background: "var(--accent)" }} /><i style={{ flex: day.other, background: "var(--yellow)" }} />
                      </div>
                      <span className="small muted num">{day.date}</span>
                    </div>
                  );
                })}
              </div>
              <span className="small muted">深度解析一条的 Token 是快讯的好几倍，大头在「查来龙去脉」。</span>
            </div>
          </>
        )}
      </div>
    </>
  );
}

// ---------------------------------------------------------------- 剪辑记录
export function AdminJobs() {
  const [kind, setKind] = useState("全部");
  const [q, setQ] = useState("");
  const { data, error, loading, reload } = useApi(() => api.adminJobs({ kind: kind === "全部" ? undefined : kind }), [kind]);
  const rows = (data?.jobs || []).filter((job) => !q || job.user.includes(q) || job.title.includes(q));
  const exportCsv = () => {
    const header = ["时间", "用户", "标题", "类型", "深度", "状态", "成片", "用时", "Token", "美元"];
    const lines = [header, ...rows.map((job) => [job.at, job.user, job.title, job.kind, job.depth, job.state, job.length, job.took, job.tokens, job.usd])]
      .map((row) => row.map((cell) => `"${String(cell).replace(/"/g, '""')}"`).join(","));
    const blob = new Blob(["﻿" + lines.join("\n")], { type: "text/csv" });
    const link = document.createElement("a");
    link.href = URL.createObjectURL(blob);
    link.download = "剪辑记录.csv";
    link.click();
  };
  return (
    <>
      <TopBar title="剪辑记录" sub="所有人生成的视频，每一条的 Token、费用和用时">
        <button className="btn ghost" onClick={exportCsv}><Icon name="download" size={15} />导出 CSV</button>
      </TopBar>
      <div className="page col">
        <div className="row">
          <Seg value={kind} onChange={setKind} options={["全部", "快讯", "深度", "智能剪辑", "上传素材"].map((value) => ({ value, label: value }))} />
          <input className="input" style={{ width: 240 }} placeholder="搜名字或标题" value={q} onChange={(event) => setQ(event.target.value)} />
          {data && <span className="small muted right-auto">共 {data.totals.count} 条 · Token {data.totals.tokens.toLocaleString()} · AI 费用 {money(data.totals.usd)} · 配音 {data.totals.voice_chars.toLocaleString()} 字 · 成片 {data.totals.minutes}</span>}
        </div>
        {loading && <Loading />}
        {error && <ErrorBox message={error} onRetry={reload} />}
        <div className="card" style={{ overflow: "auto" }}>
          <table className="t">
            <thead><tr><th>时间</th><th>用户</th><th>标题</th><th>类型</th><th>深度</th><th>状态</th><th>成片</th><th>用时</th><th className="r">Token</th><th className="r">US$</th></tr></thead>
            <tbody>
              {rows.map((job) => (
                <tr key={job.id}>
                  <td className="num">{job.at}</td><td>{job.user}</td><td className="ttl">{job.title}</td>
                  <td><span className={`chip ${job.kind === "深度" ? "c-p" : job.kind === "快讯" ? "c-m" : "c-g"}`}>{job.kind}</span></td>
                  <td className="muted">{job.depth}</td>
                  <td>{job.state.startsWith("失败") ? <span className="chip c-r">{job.state}</span> : job.state.startsWith("生成中") ? <span className="chip c-y">{job.state}</span> : job.state}</td>
                  <td className="num">{job.length}</td><td className="num">{job.took}</td>
                  <td className="r num">{job.tokens.toLocaleString()}</td><td className="r num">{job.usd.toFixed(2)}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </>
  );
}

// ---------------------------------------------------------------- 员工用量
export function AdminUsers() {
  const [role, setRole] = useState("全部");
  const [q, setQ] = useState("");
  const { data, error, loading, reload } = useApi(() => api.adminUsers({}), []);
  const [editing, setEditing] = useState<AdminUser | null>(null);
  const users = (data?.users || []).filter((user) => (role === "全部" || user.role === role) && (!q || user.name.includes(q) || user.employee_id.startsWith(q)));
  return (
    <>
      <TopBar title="员工用量" sub="本月每个人做了多少、花了多少" />
      <div className="page col">
        <div className="row">
          <Seg value={role} onChange={setRole} options={["全部", "编辑", "实习编辑", "主编", "管理员"].map((value) => ({ value, label: value }))} />
          <input className="input" style={{ width: 220 }} placeholder="名字或工号" value={q} onChange={(event) => setQ(event.target.value)} />
        </div>
        {loading && <Loading />}
        {error && <ErrorBox message={error} onRetry={reload} />}
        <div className="card" style={{ overflow: "auto" }}>
          <table className="t">
            <thead><tr><th>用户</th><th>身份</th><th>状态</th><th>快讯 · 深度</th><th className="r">本月 Token</th><th className="r">US$</th><th>今天额度</th><th>最近</th><th /></tr></thead>
            <tbody>
              {users.map((user) => (
                <tr key={user.employee_id} className="click" onClick={() => setEditing(user)}>
                  <td><b>{user.name}</b> <span className="small muted">工号 {user.employee_id.slice(0, 4)}••</span></td>
                  <td>{user.role}</td>
                  <td><span className={`chip ${user.status === "正常" ? "c-m" : user.status === "额度用完" ? "c-w" : "c-g"}`}>{user.status}</span></td>
                  <td className="num">{user.quick} · {user.deep}</td>
                  <td className="r num">{tokens(user.tokens)}</td><td className="r num">{user.usd.toFixed(2)}</td>
                  <td className="num">{user.today}</td><td className="muted">{user.last_seen}</td>
                  <td><button className="btn sm ghost">额度</button></td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
      {editing && <QuotaModal user={editing} onClose={() => setEditing(null)} />}
    </>
  );
}

function QuotaModal({ user, onClose }: { user: AdminUser; onClose: () => void }) {
  const [quick, setQuick] = useState("");
  const [deep, setDeep] = useState("");
  const [monthly, setMonthly] = useState("");
  const [depth, setDepth] = useState("标准");
  const [toast, showToast] = useToast();
  const save = async () => {
    await api.adminSaveUser(user.employee_id, { quick: quick || null, deep: deep || null, monthly_usd: monthly || null, max_depth: depth });
    showToast("已保存");
    setTimeout(onClose, 600);
  };
  return (
    <Modal title={`${user.name} 的额度`} onClose={onClose}>
      <span className="small muted">不填就用这个身份（{user.role}）的默认额度。本月 {user.quick + user.deep} 条视频 · {tokens(user.tokens)} Token · {money(user.usd)}</span>
      <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr 1fr", gap: 10 }}>
        <label className="label">每天快讯<input className="input" type="number" min={0} value={quick} onChange={(event) => setQuick(event.target.value)} placeholder="默认" /></label>
        <label className="label">每天深度解析<input className="input" type="number" min={0} value={deep} onChange={(event) => setDeep(event.target.value)} placeholder="默认" /></label>
        <label className="label">每月费用上限 US$<input className="input" type="number" min={0} value={monthly} onChange={(event) => setMonthly(event.target.value)} placeholder="不限" /></label>
      </div>
      <label className="label">允许的最高深度<Seg value={depth} onChange={setDepth} options={[{ value: "标准", label: "标准" }, { value: "深入", label: "深入" }]} /></label>
      <div className="row"><button className="btn warn" onClick={() => api.adminSaveUser(user.employee_id, { status: "disabled" }).then(() => showToast("已停用"))}>停用</button><button className="btn right-auto" onClick={save}>保存</button></div>
      {toast}
    </Modal>
  );
}

// ---------------------------------------------------------------- 深度与模型
export function AdminDepthPage() {
  const { data, error, loading, reload, setData } = useApi(() => api.adminDepth(), []);
  const [toast, showToast] = useToast();
  if (loading) return <><TopBar title="深度与模型" /><div className="page"><Loading /></div></>;
  if (error || !data) return <><TopBar title="深度与模型" /><div className="page"><ErrorBox message={error || "没有数据"} onRetry={reload} /></div></>;
  const set = (patch: Partial<AdminDepth>) => setData({ ...data, ...patch });
  const numberField = (label: string, value: number, onChange: (value: number) => void, unit: string) => (
    <label className="row" style={{ justifyContent: "space-between" }}><span>{label}</span><span className="row" style={{ gap: 6 }}><input className="input num" style={{ width: 80, height: 34 }} type="number" value={value} onChange={(event) => onChange(Number(event.target.value))} />{unit}</span></label>
  );
  return (
    <>
      <TopBar title="深度与模型" sub="每种视频查多少、用哪个模型、一条大概花多少钱">
        <button className="btn" onClick={() => api.adminSaveDepth(data).then(() => showToast("已保存"), (err) => showToast(err.message))}>保存修改</button>
      </TopBar>
      <div className="page col">
        <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 16 }}>
          <div className="card pad col" style={{ gap: 12 }}>
            <span className="h2">快讯 <span className="small muted">1 分钟内</span></span>
            {numberField("成片长度", data.quick.seconds, (seconds) => set({ quick: { ...data.quick, seconds } }), "秒以内")}
            <label className="row" style={{ justifyContent: "space-between" }}>改写方式<Seg value={data.quick.rewrite} onChange={(rewrite) => set({ quick: { ...data.quick, rewrite } })} options={["按原文改写", "加一句背景"].map((value) => ({ value, label: value }))} /></label>
            <label className="row" style={{ justifyContent: "space-between" }}>核对事实<Seg value={data.quick.check} onChange={(check) => set({ quick: { ...data.quick, check } })} options={["只查敏感词", "全文核对"].map((value) => ({ value, label: value }))} /></label>
            <div className="info">预计每条 {data.quick.tokens.toLocaleString()} Token · 约 {money(data.quick.usd)}</div>
          </div>
          <div className="card pad col" style={{ gap: 12 }}>
            <span className="h2">深度解析 <span className="small muted">{data.deep.minutes} 分钟</span></span>
            {numberField("查来龙去脉", data.deep.reports, (reports) => set({ deep: { ...data.deep, reports } }), "篇相关报道")}
            {numberField("往前查多久", data.deep.days, (days) => set({ deep: { ...data.deep, days } }), "天")}
            {numberField("现场视频", data.deep.clips, (clips) => set({ deep: { ...data.deep, clips } }), "段")}
            {numberField("交叉核对", data.deep.cross_check, (cross_check) => set({ deep: { ...data.deep, cross_check } }), "家媒体以上")}
            <div className="info">预计每条 {data.deep.tokens.toLocaleString()} Token · 约 {money(data.deep.usd)}；每多查 1 篇约 +6,000 Token</div>
          </div>
        </div>
        <div className="card">
          <div className="pad"><span className="h2">每一步用哪个模型</span> <span className="small muted">单价：美元 / 每百万 Token，按合同价填</span></div>
          <table className="t">
            <thead><tr><th>步骤</th><th>模型</th><th className="r">输入</th><th className="r">输出</th></tr></thead>
            <tbody>
              {data.models.map((row, index) => (
                <tr key={row.step}>
                  <td><b>{row.step}</b> <span className="small muted">{row.note}</span></td>
                  <td><input className="input" style={{ height: 32 }} value={row.model} onChange={(event) => set({ models: data.models.map((item, i) => (i === index ? { ...item, model: event.target.value } : item)) })} /></td>
                  <td className="r"><input className="input num" style={{ width: 80, height: 32 }} type="number" step="0.01" value={row.input} onChange={(event) => set({ models: data.models.map((item, i) => (i === index ? { ...item, input: Number(event.target.value) } : item)) })} /></td>
                  <td className="r"><input className="input num" style={{ width: 80, height: 32 }} type="number" step="0.01" value={row.output} onChange={(event) => set({ models: data.models.map((item, i) => (i === index ? { ...item, output: Number(event.target.value) } : item)) })} /></td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
        <div className="card pad col" style={{ gap: 12, maxWidth: 640 }}>
          <span className="h2">预算和提醒</span>
          {numberField("每天 AI 费用预算", data.budget.daily, (daily) => set({ budget: { ...data.budget, daily } }), "US$")}
          {numberField("每月预算", data.budget.monthly, (monthly) => set({ budget: { ...data.budget, monthly } }), "US$")}
          {numberField("用到多少提醒管理员", data.budget.alert, (alert) => set({ budget: { ...data.budget, alert } }), "%")}
          <label className="row" style={{ justifyContent: "space-between" }}>超过预算后<Seg value={data.budget.over} onChange={(over) => set({ budget: { ...data.budget, over } })} options={["只让主编做", "全部暂停"].map((value) => ({ value, label: value }))} /></label>
          {numberField("配音单价", data.budget.voice_per_k, (voice_per_k) => set({ budget: { ...data.budget, voice_per_k } }), "US$/千字")}
          {numberField("汇率", data.budget.thb_rate, (thb_rate) => set({ budget: { ...data.budget, thb_rate } }), "฿ / US$")}
        </div>
      </div>
      {toast}
    </>
  );
}

// ---------------------------------------------------------------- 剪辑机与队列
export function AdminNodes() {
  const { data, error, loading, reload } = useApi(() => api.adminNodes(), []);
  return (
    <>
      <TopBar title="剪辑机与队列" sub="视频在自己的剪辑机上合成；AI 只负责文案和查资料"><button className="btn ghost" onClick={reload}><Icon name="refresh" size={15} />刷新</button></TopBar>
      <div className="page col">
        {loading && <Loading />}
        {error && <ErrorBox message={error} onRetry={reload} />}
        {data && (
          <>
            <div style={{ display: "grid", gridTemplateColumns: "repeat(3, minmax(0, 1fr))", gap: 16 }}>
              {data.nodes.map((node) => (
                <div key={node.name} className="card pad col" style={{ gap: 10 }}>
                  <div className="row"><b className="grow">{node.name}</b><span className={`chip ${node.state === "工作中" ? "c-m" : node.state === "重试中" ? "c-w" : node.state === "离线" ? "c-r" : "c-g"}`}>{node.state}</span></div>
                  <span className="small muted">{node.spec}</span>
                  <span className="small">{node.doing}</span>
                  {([["CPU", node.cpu], ["GPU", node.gpu], ["硬盘", node.disk]] as [string, number][]).map(([label, value]) => (
                    <div key={label} className="row small"><span style={{ width: 36 }}>{label}</span><span className="bar grow"><i style={{ width: `${value}%`, background: value > 85 ? "var(--rise)" : undefined }} /></span><span className="num" style={{ width: 36, textAlign: "right" }}>{value}%</span></div>
                  ))}
                  <span className="small muted">今天完成 {node.done_today} 条 · 心跳 {node.heartbeat}</span>
                </div>
              ))}
            </div>
            <div className="card">
              <div className="pad row"><span className="h2">排队中 · {data.queue.length} 条</span><span className="small muted">主编优先；同一个人同时最多 {data.rules.per_user} 条（剪辑中 + 排队）</span></div>
              <table className="t">
                <thead><tr><th>#</th><th>用户</th><th>标题</th><th>类型</th><th>预计开始</th><th>剪辑机</th><th /></tr></thead>
                <tbody>{data.queue.map((item) => (
                  <tr key={item.position}><td className="num">{item.position}</td><td>{item.user}</td><td className="ttl">{item.title}</td><td>{item.kind}</td><td>{item.eta}</td><td>{item.node}</td>
                    <td className="r"><button className="btn sm ghost">提前</button> <button className="btn sm warn">取消</button></td></tr>
                ))}</tbody>
              </table>
            </div>
            <div className="card pad row wrap" style={{ gap: 24 }}>
              <span className="h2">队列规则</span>
              <span>每台同时剪 <b>{data.rules.per_node}</b> 条</span>
              <span>排队超过 <b>{data.rules.alert_minutes}</b> 分钟提醒</span>
              <span>失败自动重试 <b>{data.rules.retries}</b> 次</span>
              <span>成片保留 <b>{data.rules.keep_days}</b> 天</span>
              <span>每人同时最多 <b>{data.rules.per_user}</b> 条</span>
            </div>
          </>
        )}
      </div>
    </>
  );
}

// ---------------------------------------------------------------- 员工账号
export function AdminAccounts() {
  const { data, error, loading, reload } = useApi(() => api.adminUsers({}), []);
  const [status, setStatus] = useState("全部");
  const [creating, setCreating] = useState(false);
  const users = useMemo(() => (data?.users || []).filter((user) => status === "全部" || (status === "已停用" ? user.status === "已停用" : user.status !== "已停用")), [data, status]);
  return (
    <>
      <TopBar title="员工账号" sub="只有这里开的工号能登录电脑版，输工号就能进"><button className="btn" onClick={() => setCreating(true)}>新开工号</button></TopBar>
      <div className="page col">
        <Seg value={status} onChange={setStatus} options={["全部", "正常", "已停用"].map((value) => ({ value, label: value }))} />
        {loading && <Loading />}
        {error && <ErrorBox message={error} onRetry={reload} />}
        <div className="card" style={{ overflow: "auto" }}>
          <table className="t">
            <thead><tr><th>工号</th><th>名字</th><th>角色</th><th>部门</th><th>状态</th><th>最近登录</th><th /></tr></thead>
            <tbody>{users.map((user) => (
              <tr key={user.employee_id}>
                <td className="num">{user.employee_id.slice(0, 4)}••</td><td><b>{user.name}</b></td><td>{user.role}</td><td>{user.department}</td>
                <td><span className={`chip ${user.status === "已停用" ? "c-g" : "c-m"}`}>{user.status === "已停用" ? "已停用" : "正常"}</span></td>
                <td className="muted">{user.last_seen}</td>
                <td className="r"><button className="btn sm ghost" onClick={() => api.adminSaveUser(user.employee_id, { kick: true })}>踢下线</button> <button className="btn sm warn" onClick={() => api.adminSaveUser(user.employee_id, { status: user.status === "已停用" ? "active" : "disabled" }).then(reload)}>{user.status === "已停用" ? "启用" : "停用"}</button></td>
              </tr>
            ))}</tbody>
          </table>
        </div>
        <div className="note">工号就是登录凭证，没有另外的密码。工号只在开通时完整显示一次，当面告诉对方；离职当天记得停用。</div>
      </div>
      {creating && <CreateUser onClose={() => { setCreating(false); reload(); }} />}
    </>
  );
}

function CreateUser({ onClose }: { onClose: () => void }) {
  const [name, setName] = useState("");
  const [department, setDepartment] = useState("新闻部");
  const [role, setRole] = useState("编辑");
  const [created, setCreated] = useState("");
  return (
    <Modal title="新开工号" onClose={onClose}>
      {created ? (
        <>
          <span>工号已开通，只显示这一次，请当面告诉对方：</span>
          <span className="num" style={{ fontSize: 32, fontWeight: 700, letterSpacing: ".2em", textAlign: "center", padding: 12, background: "var(--brand-tint)", borderRadius: 12 }}>{created}</span>
          <button className="btn" onClick={onClose}>记下了</button>
        </>
      ) : (
        <>
          <label className="label">名字<input className="input" value={name} onChange={(event) => setName(event.target.value)} /></label>
          <label className="label">部门<input className="input" value={department} onChange={(event) => setDepartment(event.target.value)} /></label>
          <label className="label">角色<Seg value={role} onChange={setRole} options={["实习编辑", "编辑", "主编", "管理员"].map((value) => ({ value, label: value }))} /></label>
          <button className="btn" disabled={!name.trim()} onClick={async () => setCreated((await api.adminCreateUser({ name: name.trim(), department, role })).employee_id)}>开通</button>
        </>
      )}
    </Modal>
  );
}
