import { useMemo, useState } from "react";
import { useNavigate, useSearchParams } from "react-router-dom";
import { download } from "../api/client";
import * as api from "../api/endpoints";
import type { ArticlePreview, FoundImages, ShareCopy, Story } from "../api/types";
import { GenerateOptions, useGenerateSettings } from "../components/GenerateOptions";
import { TopBar } from "../components/Layout";
import { useSession } from "../components/session";
import { AuthImage, ErrorBox, Icon, Loading, Seg, Spinner, useToast } from "../components/ui";
import { useApi, useTuwenTask } from "../hooks/useApi";

const HINTS = ["讲清楚时间线", "对华人、游客有什么影响", "各方怎么说", "和以前类似的事对比", "多用官方数字", "接下来会怎样"];

export default function Workbench() {
  const [params, setParams] = useSearchParams();
  const url = params.get("url") || "";
  const tab = params.get("tab") === "tuwen" ? "tuwen" : "video";
  const setTab = (next: "video" | "tuwen") => setParams((old) => { old.set("tab", next); return old; }, { replace: true });
  const { data: article, error, loading, reload } = useApi(() => api.article(url), [url]);

  if (!url) return <><TopBar back={{ to: "/news", label: "新闻" }} title="工作台" /><div className="page"><div className="empty">没有选新闻。回到新闻页点标题，或贴一个链接。</div></div></>;

  return (
    <>
      <TopBar back={{ to: "/news", label: "新闻" }} title="工作台" sub="一篇文章在这里做视频、做图文">
        <a className="btn ghost" href={article?.url || url} target="_blank" rel="noreferrer"><Icon name="ext" size={15} color="var(--brand)" />原网页</a>
      </TopBar>
      <div className="page">
        <div className="split">
          <section className="card col" style={{ flex: "1 1 0", maxWidth: 720, gap: 0, overflow: "hidden" }}>
            {loading && <Loading text="正在取出标题、正文和配图…" />}
            {error && <div className="pad"><ErrorBox message={error} onRetry={reload} /></div>}
            {article && <ArticleView article={article} />}
          </section>
          <aside className="card panel">
            <div className="panel-head">
              <span className="h2">制作区</span>
              <div className="ptabs" role="tablist">
                <button role="tab" aria-selected={tab === "video"} className={`ptab${tab === "video" ? " on" : ""}`} onClick={() => setTab("video")}><Icon name="play" size={17} />做视频</button>
                <button role="tab" aria-selected={tab === "tuwen"} className={`ptab${tab === "tuwen" ? " on" : ""}`} onClick={() => setTab("tuwen")}><Icon name="image" size={17} />做图文</button>
              </div>
            </div>
            {tab === "video" ? <VideoPanel url={article?.url || url} article={article} /> : <TuwenPanel url={article?.url || url} article={article} />}
          </aside>
        </div>
      </div>
    </>
  );
}

function ArticleView({ article }: { article: ArticlePreview }) {
  return (
    <>
      {article.images[0] && <div style={{ height: 240 }}><AuthImage path={article.images[0]} alt="文章配图" /></div>}
      <div style={{ padding: "20px 26px 24px", display: "flex", flexDirection: "column", gap: 12 }}>
        <span className="row small muted" style={{ gap: 8 }}>
          <span className="chip c-p">{article.source}</span>{article.date} · {article.chars} 字 · {article.images.length} 张原图
        </span>
        <h2 style={{ margin: 0, fontSize: 24, lineHeight: "34px" }}>{article.title}</h2>
        {article.foreign && <div className="note">原文不是中文：做视频和图文时会先翻译成中文，再按泰国中文社格式写。</div>}
        {article.paragraphs.map((paragraph, index) => <p key={index} style={{ margin: 0, fontSize: 15, lineHeight: "27px" }}>{paragraph}</p>)}
        {article.images.length > 0 && (
          <div style={{ display: "flex", flexDirection: "column", gap: 8, paddingTop: 4 }}>
            <span className="small bold">文章里的原图 · {article.images.length} 张</span>
            <div className="row wrap" style={{ gap: 8 }}>
              {article.images.map((path) => <span key={path} style={{ width: 96, height: 64, borderRadius: 8, overflow: "hidden" }}><AuthImage path={path} /></span>)}
            </div>
          </div>
        )}
      </div>
    </>
  );
}

// ---------------------------------------------------------------- 做视频
function VideoPanel({ url, article }: { url: string; article: ArticlePreview | null }) {
  const navigate = useNavigate();
  const { options } = useSession();
  const [settings, setSettings] = useGenerateSettings(options, "news");
  const [deep, setDeep] = useState(true);
  const [hint, setHint] = useState("");
  const [busy, setBusy] = useState(false);
  const [toast, showToast] = useToast();
  const tooFew = !!article && article.images.length < 2;

  const submit = async () => {
    setBusy(true);
    try {
      const job = await api.createJob({ ...settings, url, deep, deep_hint: deep && hint.trim() ? hint.trim() : undefined });
      navigate(`/jobs/${job.id}`);
    } catch (err) {
      showToast(err instanceof Error ? err.message : "提交失败");
      setBusy(false);
    }
  };

  return (
    <>
      <div className="panel-body">
        <div className="col" style={{ gap: 10 }}>
          <button className={`choice${!deep ? " on" : ""}`} onClick={() => setDeep(false)}>
            <span className="radio" /><span className="grow" style={{ display: "flex", flexDirection: "column" }}><b style={{ fontSize: 16 }}>快讯</b><span className="small muted">按原文改写 · 约 3 分钟做好</span></span>
          </button>
          <button className={`choice${deep ? " on" : ""}`} onClick={() => setDeep(true)}>
            <span className="radio" /><span className="grow" style={{ display: "flex", flexDirection: "column" }}><b style={{ fontSize: 16, color: deep ? "var(--brand-deep)" : undefined }}>深度解析</b><span className="small muted">2 到 3 分钟，自动查来龙去脉、配现场画面 · 约 9 分钟做好</span></span>
          </button>
        </div>
        {deep && (
          <div className="hintbox">
            <span className="row" style={{ gap: 6 }}><b>给深度的提示</b><span className="small muted">（可选）想让这条深度重点讲什么</span></span>
            <textarea className="textarea" style={{ minHeight: 64 }} value={hint} maxLength={300} onChange={(event) => setHint(event.target.value)}
              placeholder="例如：重点讲对清莱华人和游客的影响，交代清楚污染从哪来" aria-label="给深度的提示" />
            <span className="small muted">点一下加到提示里：</span>
            <div className="row wrap" style={{ gap: 6 }}>
              {HINTS.map((text) => (
                <button key={text} className="chipbtn" onClick={() => setHint(hint.includes(text) ? hint : (hint ? `${hint}；${text}` : text))}>＋ {text}</button>
              ))}
            </div>
            <span className="small muted">提示只决定讲哪些角度；资料里查不到的不会编进文案。</span>
          </div>
        )}
        <GenerateOptions options={options} settings={settings} onChange={setSettings} durations={options?.durations || [30, 45, 60]}
          durationNote={deep ? "深度解析自动 2–3 分钟" : undefined} />
        {tooFew && <div className="note">这篇原图不到 2 张，做视频可能失败。先到「做图文 › 一键找图」找图，或换一条。</div>}
      </div>
      <div className="panel-foot">
        <button className="btn lg block" disabled={busy || !article} onClick={submit}>
          <Icon name="play" size={18} />{busy ? "正在提交…" : deep ? "一键生成深度视频" : "一键生成快讯"}
        </button>
        <span className="small muted" style={{ textAlign: "center" }}>提交后可以先做别的，做好了在「生成记录」里</span>
      </div>
      {toast}
    </>
  );
}

// ---------------------------------------------------------------- 做图文
type Sub = "story" | "images" | "copy";

function TuwenPanel({ url, article }: { url: string; article: ArticlePreview | null }) {
  const [sub, setSub] = useState<Sub>("story");
  const [visited, setVisited] = useState<Set<Sub>>(new Set(["story"]));
  const [chosen, setChosen] = useState<string[] | null>(null);
  const go = (next: Sub) => {
    setSub(next);
    setVisited((old) => new Set(old).add(next));
  };
  const pictures = chosen ?? article?.images ?? [];
  return (
    <>
      <div style={{ padding: "8px 18px 0", borderBottom: "1px solid var(--line-2)" }}>
        <div className="row" style={{ gap: 18 }}>
          {([["story", "来龙去脉"], ["images", "一键找图"], ["copy", "分享文案"]] as [Sub, string][]).map(([key, label]) => (
            <button key={key} className={`tab${sub === key ? " on" : ""}`} onClick={() => go(key)}>{label}</button>
          ))}
        </div>
      </div>
      {/* 访问过的分页保持挂着，切走以后服务器任务继续跑 */}
      {visited.has("story") && <div style={{ display: sub === "story" ? "contents" : "none" }}><StoryPane url={url} onShare={() => go("copy")} /></div>}
      {visited.has("images") && <div style={{ display: sub === "images" ? "contents" : "none" }}><ImagesPane url={url} onUse={(paths) => { setChosen(paths); go("copy"); }} /></div>}
      {visited.has("copy") && <div style={{ display: sub === "copy" ? "contents" : "none" }}><CopyPane url={url} pictures={pictures} onFind={() => go("images")} /></div>}
    </>
  );
}

function Working({ step, elapsed, hint }: { step: string; elapsed: number; hint: string }) {
  return (
    <div className="card pad col" style={{ gap: 8 }}>
      <div className="row"><Spinner /><b className="grow">{step}</b>{elapsed > 0 && <span className="small num muted">{elapsed}秒</span>}</div>
      <span className="small muted">{hint}</span>
    </div>
  );
}

function StoryPane({ url, onShare }: { url: string; onShare: () => void }) {
  const task = useTuwenTask<Story>(() => api.story(url), `story:${url}`);
  const [toast, showToast] = useToast();
  const story = task.result;
  const copyText = () => {
    if (!story) return;
    const text = [`【来龙去脉】${story.title}`, story.summary, "", ...story.timeline.map((event) => `${event.date}  ${event.text}`), "", story.now ? `最新进展：${story.now}` : ""].join("\n").trim();
    navigator.clipboard.writeText(text).then(() => showToast("已复制来龙去脉"), () => showToast("复制失败，请手动选中复制"));
  };
  return (
    <>
      <div className="panel-body">
        {!story && !task.error && <Working step={task.step} elapsed={task.elapsed} hint="AI 会找出泰国中文社之前报道过的同一件事，按时间排好，大约半分钟。" />}
        {task.error && <ErrorBox message={task.error} onRetry={task.retry} />}
        {story && (
          <>
            <div style={{ padding: "14px 16px", borderRadius: 12, background: "var(--brand-tint)", display: "flex", flexDirection: "column", gap: 6 }}>
              <b style={{ fontSize: 15 }}>{story.title}</b>
              <span style={{ fontSize: 13, lineHeight: "21px", color: "var(--ink-2)" }}>{story.summary}</span>
            </div>
            {story.facts.length > 0 && (
              <div style={{ display: "grid", gridTemplateColumns: `repeat(${story.facts.length}, 1fr)`, gap: 8 }}>
                {story.facts.map((fact) => (
                  <span key={fact.label} style={{ padding: "10px 12px", borderRadius: 10, background: "var(--brand-soft)", display: "flex", flexDirection: "column" }}>
                    <span className="num ellipsis" style={{ fontSize: 18, lineHeight: "24px", fontWeight: 700, color: "var(--brand-deep)" }}>{fact.value}</span>
                    <span className="small muted">{fact.label}</span>
                  </span>
                ))}
              </div>
            )}
            <div className="col" style={{ gap: 12 }}>
              <div className="row" style={{ gap: 8 }}><Icon name="clock" color="var(--brand)" /><b className="grow">时间线</b><button className="btn sm ghost" onClick={copyText}><Icon name="copy" size={13} />复制</button></div>
              <div>
                {story.timeline.map((event, index) => {
                  const last = index === story.timeline.length - 1;
                  return (
                    <div key={index} className={`tl${last ? " last" : ""}`}>
                      <span className="rail"><span className="pt" />{!last && <span className="ln" />}</span>
                      <span className="txt"><span className="small num bold" style={{ color: "var(--brand)" }}>{event.date}</span><span>{event.text}</span></span>
                    </div>
                  );
                })}
              </div>
            </div>
            {story.now && (
              <div style={{ padding: "12px 14px", borderRadius: 12, background: "var(--accent-soft)", display: "flex", flexDirection: "column", gap: 4 }}>
                <span className="small bold" style={{ color: "var(--accent-ink)" }}>最新进展</span><span>{story.now}</span>
              </div>
            )}
            {story.related.length > 0 && (
              <div className="col" style={{ gap: 4 }}>
                <span className="small muted bold">根据泰国中文社之前的报道</span>
                {story.related.map((item) => <span key={item.title} className="small muted">{item.date}  {item.title}</span>)}
              </div>
            )}
          </>
        )}
      </div>
      <div className="panel-foot">
        <div className="row">
          <button className="btn ghost grow" style={{ height: 46 }} disabled={!story} onClick={copyText}><Icon name="copy" size={16} color="var(--brand)" />复制来龙去脉</button>
          <button className="btn grow" style={{ height: 46 }} disabled={!story} onClick={onShare}><Icon name="edit" size={16} />编辑后分享图文</button>
        </div>
      </div>
      {toast}
    </>
  );
}

function ImagesPane({ url, onUse }: { url: string; onUse: (paths: string[]) => void }) {
  const task = useTuwenTask<FoundImages>(() => api.findImages(url), `images:${url}`);
  const [selected, setSelected] = useState<Set<string> | null>(null);
  const found = task.result;
  const picked = selected ?? new Set(found?.images.map((image) => image.path) || []);
  const toggle = (path: string) => {
    const next = new Set(picked);
    if (next.has(path)) next.delete(path);
    else next.add(path);
    setSelected(next);
  };
  const removed = useMemo(() => {
    if (!found) return "";
    if (!found.checked) return "AI 看图暂时不可用，这次没有筛掉广告，请自己留意。";
    const parts = [];
    if (found.removed.duplicates) parts.push(`${found.removed.duplicates} 张重复`);
    if (found.removed.unsuitable) parts.push(`${found.removed.unsuitable} 张不能用（${Object.entries(found.removed.reasons).map(([reason, count]) => reason + count).join("、")}）`);
    return parts.length ? `AI 已去掉 ${parts.join("，")}。` : "AI 检查过，没有广告、二维码和重复的图。";
  }, [found]);
  const downloadPicked = async () => {
    let index = 0;
    for (const path of picked) await download(path, `配图-${++index}.jpg`);
  };
  return (
    <>
      <div className="panel-body">
        {!found && !task.error && <Working step={task.step} elapsed={task.elapsed} hint="通常要 1 到 2 分钟：要读泰国媒体的报道，再让 AI 一张张看图。" />}
        {task.error && <ErrorBox message={task.error} onRetry={task.retry} />}
        {found && (
          <>
            <div className="info" style={{ background: "var(--brand-tint)", color: "var(--brand-deep)" }}>
              <b>找到 {found.images.length} 张可用的图</b><br />{removed}
              {found.media.length > 0 && <><br />来源：原文、{found.media.join("、")}。分享时请注意图片版权。</>}
              {found.masked > 0 && <><br />涉案新闻：{found.masked} 张图已给人脸眼部打码。</>}
            </div>
            <div className="grid-pics">
              {found.images.map((image) => (
                <button key={image.path} className={`pic${picked.has(image.path) ? " on" : ""}`} onClick={() => toggle(image.path)} aria-pressed={picked.has(image.path)}>
                  <AuthImage path={image.path} />
                  <span className="tick">{picked.has(image.path) && <Icon name="check" size={12} color="#fff" width={3} />}</span>
                  {image.source && <span className="tag">{image.source}</span>}
                </button>
              ))}
            </div>
            {found.searches.length > 0 && (
              <div className="col" style={{ gap: 6 }}>
                <b>还想要更多现场图</b>
                <span className="small muted">Facebook 上的图 AI 搜不到，点下面打开搜索，看到合适的另存下来。</span>
                {found.searches.map((search) => (
                  <a key={search.url} className="btn soft" style={{ justifyContent: "flex-start" }} href={search.url} target="_blank" rel="noreferrer">
                    <Icon name="search" size={15} />在 {search.site} 搜「{search.keyword}」<Icon name="ext" size={14} />
                  </a>
                ))}
              </div>
            )}
          </>
        )}
      </div>
      <div className="panel-foot">
        <div className="row">
          <button className="btn ghost grow" style={{ height: 46 }} disabled={!picked.size} onClick={downloadPicked}><Icon name="download" size={16} color="var(--brand)" />下载选中的 {picked.size} 张</button>
          <button className="btn grow" style={{ height: 46 }} disabled={!picked.size} onClick={() => onUse([...picked])}>用这些图分享</button>
        </div>
      </div>
    </>
  );
}

const PLATFORMS = [
  { id: "xhs", name: "小红书", tags: true, url: "https://creator.xiaohongshu.com/publish/publish" },
  { id: "channels", name: "视频号", tags: false, url: "https://channels.weixin.qq.com/platform/post/finderNewLifeCreate" },
  { id: "douyin", name: "抖音图文", tags: true, url: "https://creator.douyin.com/creator-micro/content/upload?default-tab=3" },
  { id: "facebook", name: "Facebook", tags: false, url: "https://www.facebook.com/" },
];

function CopyPane({ url, pictures, onFind }: { url: string; pictures: string[]; onFind: () => void }) {
  const [format, setFormat] = useState<"platform" | "full">("platform");
  const platform = useTuwenTask<ShareCopy>(format === "platform" ? () => api.shareCopy(url, "platform") : null, `copy:${url}:platform`);
  const full = useTuwenTask<ShareCopy>(format === "full" ? () => api.shareCopy(url, "full") : null, `copy:${url}:full`);
  const task = format === "platform" ? platform : full;
  const copy = task.result;
  const [edits, setEdits] = useState<Record<string, { title: string; body: string }>>({});
  const [selected, setSelected] = useState<Set<string> | null>(null);
  const [toast, showToast] = useToast();
  const picked = selected ?? new Set(pictures.slice(0, 9));
  const title = edits[format]?.title ?? copy?.title ?? "";
  const body = edits[format]?.body ?? copy?.body ?? "";
  const chars = body.replace(/\s/g, "").length + (copy?.signoff.length || 0);
  const edit = (patch: Partial<{ title: string; body: string }>) => setEdits({ ...edits, [format]: { title, body, ...patch } });
  const textFor = (withTags: boolean) =>
    [title, body, copy?.signoff, withTags && copy?.tags.length ? copy.tags.map((tag) => `#${tag}`).join(" ") : ""].filter(Boolean).join("\n\n");

  const share = async (target: (typeof PLATFORMS)[number]) => {
    try {
      await navigator.clipboard.writeText(textFor(target.tags));
    } catch {
      showToast("复制失败，请手动选中文案复制");
      return;
    }
    let index = 0;
    for (const path of picked) await download(path, `${target.name}-配图-${++index}.jpg`).catch(() => undefined);
    window.open(target.url, "_blank", "noopener");
    showToast(`文案已复制，${picked.size} 张图已下载；在${target.name}里上传图片、粘贴文案`);
  };

  return (
    <>
      <div className="panel-body">
        <Seg full value={format} onChange={setFormat} options={[{ value: "platform", label: "平台版 · 950字内" }, { value: "full", label: "完整版" }]} />
        <div className="col" style={{ gap: 8 }}>
          <div className="row"><b className="grow">配图（已选 {picked.size} 张）</b><button className="btn sm ghost" onClick={onFind}>一键找图换图</button></div>
          {pictures.length ? (
            <div className="row" style={{ gap: 6, overflowX: "auto", paddingBottom: 2 }}>
              {pictures.map((path) => {
                const on = picked.has(path);
                return (
                  <button key={path} className={`pic${on ? " on" : ""}`} style={{ width: 70, flex: "none", aspectRatio: "1" }} aria-pressed={on}
                    onClick={() => { const next = new Set(picked); if (on) next.delete(path); else next.add(path); setSelected(next); }}>
                    <AuthImage path={path} /><span className="tick">{on && <Icon name="check" size={12} color="#fff" width={3} />}</span>
                  </button>
                );
              })}
            </div>
          ) : <span className="small muted">这篇没有配图，先去「一键找图」。</span>}
        </div>
        {!copy && !task.error && <Working step={task.step} elapsed={task.elapsed} hint={format === "platform" ? "按泰国中文社编辑规范写平台版：视频号、小红书 950 字以内，大约半分钟。" : "完整版会把之前的相关报道也写进去，大约一分钟。"} />}
        {task.error && <ErrorBox message={task.error} onRetry={task.retry} />}
        {copy && (
          <div className="col" style={{ gap: 8 }}>
            <div className="row"><b className="grow">文案</b><span className="small num bold" style={{ color: chars > copy.limit ? "var(--rise)" : "var(--accent-ink)" }}>{chars} / {copy.limit} 字</span></div>
            <input className="input" value={title} onChange={(event) => edit({ title: event.target.value })} aria-label="标题" style={{ fontWeight: 700 }} />
            <textarea className="textarea" style={{ minHeight: format === "platform" ? 260 : 380 }} value={body} onChange={(event) => edit({ body: event.target.value })} aria-label="正文" />
            <span className="small muted bold" style={{ textAlign: "right" }}>{copy.signoff}</span>
            {copy.tags.length > 0 && <div className="row wrap" style={{ gap: 6 }}>{copy.tags.map((tag) => <span key={tag} className="chip c-g">#{tag}</span>)}</div>}
            <span className="small muted">按《泰国中文社新闻稿编辑规范》写：不出现其他媒体名称，结尾固定署名。可以直接改，改完再分享。</span>
          </div>
        )}
      </div>
      <div className="panel-foot">
        <div style={{ display: "grid", gridTemplateColumns: "repeat(4, 1fr)", gap: 6 }}>
          {PLATFORMS.map((target) => (
            <button key={target.id} className="btn ghost" style={{ height: 44, padding: 0 }} disabled={!copy} onClick={() => share(target)}>{target.name}</button>
          ))}
        </div>
        <button className="btn" disabled={!copy} onClick={() => navigator.clipboard.writeText(textFor(false)).then(() => showToast("文案已复制"))}><Icon name="copy" size={16} />只复制文案</button>
        <span className="small muted" style={{ textAlign: "center" }}>点平台：复制文案、下载选中的图、打开该平台的发布页</span>
      </div>
      {toast}
    </>
  );
}
