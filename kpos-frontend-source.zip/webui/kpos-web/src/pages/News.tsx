import { useMemo, useState } from "react";
import { useNavigate } from "react-router-dom";
import * as api from "../api/endpoints";
import type { FeedItem, FeedSection } from "../api/types";
import { useGenerateSettings } from "../components/GenerateOptions";
import { TopBar } from "../components/Layout";
import { useSession } from "../components/session";
import { AuthImage, ErrorBox, Heat, Icon, Loading, RankMove, Tabs, relativeTime, useToast } from "../components/ui";
import { useApi } from "../hooks/useApi";

const PAGE_SIZE = 20;
const TABS = [
  { value: "recommended", label: "推荐关注" },
  { value: "hot_day", label: "24小时热门" },
  { value: "hot_week", label: "一周热门" },
  { value: "huaren", label: "华人" },
  { value: "social", label: "社会" },
  { value: "deep", label: <>深度话题<span className="dot" style={{ background: "var(--accent)" }} /></> },
  { value: "latest", label: "最新" },
] as const;
type TabId = (typeof TABS)[number]["value"];

/** 新闻列表：/tuwen/feed 带封面图；深度话题来自 /feeds；“社会”没有单独分栏时从各栏里挑分类是社会的 */
async function loadSections(refresh = false): Promise<Record<string, FeedSection>> {
  const [pictures, plain] = await Promise.all([api.tuwenFeed(refresh), api.feeds(refresh).catch(() => null)]);
  const byId: Record<string, FeedSection> = {};
  for (const section of plain?.sections || []) byId[section.id] = section;
  for (const section of pictures.sections) byId[section.id] = section;
  if (!byId.social) {
    const seen = new Set<string>();
    const items = Object.values(byId).flatMap((section) => section.items)
      .filter((item) => item.topic.includes("社会") && !seen.has(item.url) && seen.add(item.url));
    byId.social = { id: "social", name: "社会", items, error: "" };
  }
  return byId;
}

export default function News() {
  const navigate = useNavigate();
  const { options } = useSession();
  const [settings] = useGenerateSettings(options, "news");
  const { data, error, loading, reload, setData } = useApi(() => loadSections(), []);
  const [tab, setTab] = useState<TabId>("hot_day");
  const [page, setPage] = useState(1);
  const [link, setLink] = useState("");
  const [busy, setBusy] = useState("");
  const [toast, showToast] = useToast();

  const section = data?.[tab];
  const items = section?.items || [];
  const pages = Math.max(1, Math.ceil(items.length / PAGE_SIZE));
  const shown = items.slice((page - 1) * PAGE_SIZE, page * PAGE_SIZE);
  const topHeat = useMemo(() => Math.max(0, ...items.map((item) => item.media_count || 0)), [items]);
  const ranked = tab.startsWith("hot");

  const generate = async (item: FeedItem, deep: boolean) => {
    setBusy(item.url + deep);
    try {
      await api.createJob({ ...settings, url: item.url, deep });
      showToast(deep ? "深度解析已提交，约 9 分钟做好，在「生成记录」里看" : "快讯已提交，约 3 分钟做好");
    } catch (err) {
      showToast(err instanceof Error ? err.message : "提交失败");
    } finally {
      setBusy("");
    }
  };

  const openLink = () => {
    const url = link.trim();
    if (!/^https?:\/\//i.test(url)) return showToast("请贴完整的新闻链接（http 开头）");
    navigate(`/work?url=${encodeURIComponent(url)}`);
  };

  return (
    <>
      <TopBar title="新闻" sub="点「快讯」「深度」直接生成；点标题进工作台，可以改设置、写深度提示、做图文">
        <button className="btn ghost" onClick={async () => { setData(null); setData(await loadSections(true).catch(() => null)); }}>
          <Icon name="refresh" size={16} color="var(--brand)" />刷新
        </button>
      </TopBar>
      <div className="page">
        <div className="center">
          <div className="row">
            <span className="seg" style={{ flex: "none" }}>
              <button className="on">中文社模式</button>
              <button onClick={() => navigate("/wechat")}>公众号模式</button>
              <button onClick={() => setLink("")} title="贴泰文、英文等网站链接">外站新闻</button>
              <button onClick={() => navigate("/script")}>智能剪辑</button>
              <button onClick={() => navigate("/upload")}>手动上传</button>
            </span>
            <span className="row grow" style={{ height: 40, border: "1px solid var(--field-line)", borderRadius: 10, padding: "0 12px", background: "#fff", gap: 8 }}>
              <Icon name="link" size={16} color="var(--faint)" />
              <input value={link} onChange={(event) => setLink(event.target.value)} onKeyDown={(event) => event.key === "Enter" && openLink()}
                placeholder="粘贴新闻链接：泰国中文社、公众号、泰文或英文网站都可以" aria-label="新闻链接"
                style={{ flex: 1, minWidth: 0, border: 0, outline: 0, fontSize: 14, background: "transparent" }} />
            </span>
            <button className="btn" style={{ height: 40 }} onClick={openLink}>打开</button>
          </div>
          <div className="small muted" style={{ marginTop: -4 }}>
            外站新闻（泰文、英文等）会先翻译成中文再写口播。公众号文章可以在「公众号剪辑」里一次贴多条。
          </div>
          <Tabs value={tab} onChange={(value) => { setTab(value); setPage(1); }}
            options={TABS.map((item) => ({ value: item.value, label: item.label }))}
            right={ranked && <span className="small muted">和上一轮比 · <span className="rise">▲上升</span> <span className="fall">▼下降</span></span>} />
          {loading && <Loading />}
          {error && <ErrorBox message={error} onRetry={reload} />}
          {section?.error && <ErrorBox message={section.error} />}
          {!loading && !error && !shown.length && <div className="empty">这一栏暂时没有新闻</div>}
          {shown.map((item, index) => {
            const rank = (page - 1) * PAGE_SIZE + index + 1;
            const photos = item.photos;
            const enough = photos === undefined || photos >= 2;
            return (
              <div key={item.url} className="card news-row">
                {ranked && (
                  <span className="rank">
                    <b className="num" style={{ color: rank <= 3 ? "var(--brand)" : "var(--faint)" }}>{rank}</b>
                    <RankMove move={item.move} by={item.move_by} />
                  </span>
                )}
                <span className="thumb">
                  {item.image && <AuthImage path={item.image} />}
                  {photos !== undefined && (
                    <span className={`count${enough ? "" : " few"}`} title={`文章里有 ${photos} 张原图`}><Icon name="image" size={11} color="#fff" width={2.5} />{photos}</span>
                  )}
                </span>
                <span className="grow" style={{ display: "flex", flexDirection: "column", gap: 6 }}>
                  <button className="title-link" onClick={() => navigate(`/work?url=${encodeURIComponent(item.url)}`)}>{item.title}</button>
                  <span className="row wrap small muted" style={{ gap: 8 }}>
                    {item.chinese && <span className="chip c-p">华人</span>}
                    {!enough && <span className="chip c-w">{photos ? `原图只有 ${photos} 张，不够剪视频` : "没有原图，点「图文」去一键找图"}</span>}
                    <Heat value={item.media_count} top={topHeat} />
                    <span>{[item.topic, relativeTime(item.date)].filter(Boolean).join(" · ")}</span>
                    {item.reason && <span style={{ color: "var(--brand)" }}>{item.reason}</span>}
                  </span>
                </span>
                <button className="btn ghost" style={{ padding: "0 12px" }} onClick={() => navigate(`/work?url=${encodeURIComponent(item.url)}&tab=tuwen`)}>
                  <Icon name="image" size={15} color="var(--brand)" />图文
                </button>
                <button className="btn soft" style={{ width: 84 }} disabled={!enough || !!busy} onClick={() => generate(item, false)}>
                  <Icon name="bolt" size={15} />{busy === item.url + false ? "提交中" : "快讯"}
                </button>
                <button className="btn" style={{ width: 84 }} disabled={!enough || !!busy} onClick={() => generate(item, true)}>
                  <Icon name="play" size={15} />{busy === item.url + true ? "提交中" : "深度"}
                </button>
              </div>
            );
          })}
          {items.length > 0 && (
            <div className="row" style={{ paddingTop: 4 }}>
              <span className="small muted">共 {items.length} 条 · 每页 {PAGE_SIZE} 条</span>
              <span className="row right-auto" style={{ gap: 6 }}>
                <button className="btn ghost" style={{ width: 38, padding: 0 }} disabled={page <= 1} onClick={() => setPage(page - 1)} aria-label="上一页">‹</button>
                {Array.from({ length: pages }, (_, index) => (
                  <button key={index} className={`btn${index + 1 === page ? "" : " ghost"}`} style={{ width: 38, padding: 0 }} onClick={() => setPage(index + 1)}>{index + 1}</button>
                ))}
                <button className="btn ghost" style={{ width: 38, padding: 0 }} disabled={page >= pages} onClick={() => setPage(page + 1)} aria-label="下一页">›</button>
              </span>
            </div>
          )}
        </div>
      </div>
      {toast}
    </>
  );
}
