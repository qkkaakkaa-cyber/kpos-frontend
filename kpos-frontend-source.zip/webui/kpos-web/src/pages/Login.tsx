import { useState, type FormEvent } from "react";
import { Navigate, useLocation, useNavigate } from "react-router-dom";
import { useSession } from "../components/session";
import { Icon, Logo } from "../components/ui";

export default function Login() {
  const { user, signIn } = useSession();
  const navigate = useNavigate();
  const location = useLocation();
  const [code, setCode] = useState("");
  const [show, setShow] = useState(false);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");
  const back = (location.state as { from?: string } | null)?.from || "/news";
  if (user) return <Navigate to={back} replace />;

  const submit = async (event: FormEvent) => {
    event.preventDefault();
    setBusy(true);
    setError("");
    try {
      await signIn(code.trim());
      navigate(back, { replace: true });
    } catch (err) {
      setError(err instanceof Error ? err.message : "登录失败");
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="app" style={{ minHeight: "100vh" }}>
      <section style={{ flex: "1 1 55%", minWidth: 0, background: "var(--admin)", color: "#fff", display: "flex", flexDirection: "column", justifyContent: "space-between", padding: "40px 56px" }}>
        <div className="row" style={{ gap: 12 }}>
          <Logo size={46} light />
          <span style={{ display: "flex", flexDirection: "column", lineHeight: "24px" }}>
            <span style={{ fontSize: 24, fontWeight: 700, letterSpacing: ".06em" }}>KPOS</span>
            <span className="small" style={{ color: "#c9c0e6" }}>中文社传媒</span>
          </span>
        </div>
        <div style={{ display: "flex", flexDirection: "column", gap: 18, maxWidth: 560 }}>
          <h1 style={{ margin: 0, fontSize: 44, lineHeight: "56px", fontWeight: 700 }}>贴一条新闻链接<br />几分钟后拿到能发的竖屏视频</h1>
          <p style={{ margin: 0, fontSize: 16, lineHeight: "28px", color: "#dcd6ee" }}>自动写口播、配音、找现场画面、加字幕，自动合成成片。快讯 1 分钟内，深度解析 2 到 3 分钟。</p>
        </div>
        <span className="small" style={{ color: "#c9c0e6" }}>kpos.com · 中文社传媒内部系统</span>
      </section>
      <section style={{ flex: "1 1 45%", display: "flex", alignItems: "center", justifyContent: "center", background: "#fff", padding: 40 }}>
        <form onSubmit={submit} style={{ width: 380, display: "flex", flexDirection: "column", gap: 20 }}>
          <div style={{ display: "flex", flexDirection: "column", gap: 6 }}>
            <span className="chip c-p" style={{ alignSelf: "flex-start" }}><Icon name="shield" size={12} />内部系统</span>
            <h2 style={{ margin: 0, fontSize: 26, lineHeight: "34px" }}>登录 KPOS</h2>
            <span className="muted">输入你的工号</span>
          </div>
          <label className="label">工号
            <span className="row" style={{ height: 52, border: "2px solid var(--brand)", borderRadius: 10, padding: "0 6px 0 14px", gap: 10 }}>
              <input autoFocus type={show ? "text" : "password"} inputMode="numeric" autoComplete="off" value={code}
                onChange={(event) => setCode(event.target.value.replace(/\s/g, ""))} aria-label="工号"
                style={{ flex: 1, minWidth: 0, border: 0, outline: 0, fontSize: 20, letterSpacing: ".3em", background: "transparent" }} />
              <button type="button" className="btn sm ghost" style={{ border: 0 }} onClick={() => setShow(!show)} aria-label={show ? "隐藏工号" : "显示工号"}>
                <Icon name={show ? "x" : "search"} size={16} />
              </button>
            </span>
            <span className="small muted" style={{ fontWeight: 500 }}>输入时显示成圆点；工号就是登录凭证，别告诉别人</span>
          </label>
          {error && <div className="note" role="alert">{error}</div>}
          <button className="btn lg" disabled={busy || !code}>{busy ? "正在登录…" : "进入"}</button>
          <div className="info">输错多次会被暂时封禁（由服务器控制）。没有工号找管理员开。</div>
        </form>
      </section>
    </div>
  );
}
