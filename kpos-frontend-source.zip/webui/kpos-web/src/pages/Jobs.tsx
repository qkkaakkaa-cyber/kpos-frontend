import { useEffect, useMemo, useRef, useState } from "react";
import { Link, useNavigate, useParams } from "react-router-dom";
import { blobUrl, download } from "../api/client";
import * as api from "../api/endpoints";
import type { Job, JobVisual } from "../api/types";
import { TopBar } from "../components/Layout";
import { AuthImage, ErrorBox, Icon, Loading, Seg, Spinner, Tabs, formatTime, useToast } from "../components/ui";
import { useApi, usePolling } from "../hooks/useApi";

type Filter = "all" | "running" | "failed";

const stateText = (job: Job) => {
  if (job.state === "processing") return (job.queue_position || 0) > 0 ? `排队 · 第 ${job.queue_position} 位` : `剪辑中 · ${job.progress}%${job.phase ? ` · ${job.phase}` : ""}`;
  if (job.state === "failed") return `失败 · ${job.error || "原因见日志"}`;
  if (job.state === "cancelled") return "已终止";
  return `${job.uploaded ? "上传素材" : job.deep ? "深度" : "快讯"}${job.has_video ? "" : job.server_video_deleted ? " · 服务器成片已清理" : ""}`;
};

function StateIcon({ job }: { job: Job }) {
  const waiting = job.state === "processing" && (job.queue_position || 0) > 0;
  const [bg, icon, color] = job.state === "complete" ? ["var(--accent-soft)", "check", "var(--accent-ink)"]
    : job.state === "failed" ? ["var(--rise-soft)", "x", "var(--rise)"]
    : job.state === "cancelled" ? ["var(--line-2)", "x", "var(--faint)"]
    : waiting ? ["var(--yellow-soft)", "hourglass", "var(--yellow-ink)"] : ["var(--brand-soft)", "clock", "var(--brand)"];
  return <span style={{ width: 34, height: 34, flex: "none", borderRadius: 10, background: bg, display: "flex", alignItems: "center", justifyContent: "center" }}><Icon name={icon} size={18} color={color} width={2.5} /></span>;
}

export default function Jobs() {
  const { id } = useParams();
  const navigate = useNavigate();
  const [filter, setFilter] = useState<Filter>("all");
  const { data, error, loading, reload, setData } = useApi(() => api.jobs(80), []);
  const jobs = data?.jobs || [];
  const running = jobs.filter((job) => job.state === "processing");
  usePolling(() => api.jobs(80).then(setData).catch(() => undefined), 5000, running.length > 0);
  const shown = jobs.filter((job) => filter === "all" || (filter === "running" ? job.state === "processing" : job.state === "failed"));
  const selected = id || shown.find((job) => job.state === "complete")?.id || shown[0]?.id;

  const groups = useMemo(() => {
    const map = new Map<string, Job[]>();
    for (const job of shown) {
      const day = new Date(job.created_at).toLocaleDateString("zh-CN", { timeZone: "Asia/Bangkok" });
      const label = day === new Date().toLocaleDateString("zh-CN", { timeZone: "Asia/Bangkok" }) ? "今天"
        : day === new Date(Date.now() - 86400000).toLocaleDateString("zh-CN", { timeZone: "Asia/Bangkok" }) ? "昨天" : day;
      map.set(label, [...(map.get(label) || []), job]);
    }
    return [...map.entries()];
  }, [shown]);

  const quickAction = async (event: React.MouseEvent, job: Job, action: "cancel" | "retry") => {
    event.preventDefault();
    try {
      const result = action === "cancel" ? await api.cancelJob(job.id) : await api.retryJob(job.id);
      await reload();
      if (action === "retry") navigate(`/jobs/${result.id}`);
    } catch (err) {
      alert(err instanceof Error ? err.message : "操作失败");
    }
  };

  return (
    <>
      <TopBar title="生成记录" sub="做好的视频保留 30 天">
        <span className="small muted">同时最多 5 条（剪辑中 + 排队），满了要等前面做完</span>
        <Seg value={filter} onChange={setFilter} options={[{ value: "all", label: "全部" }, { value: "running", label: `进行中 ${running.length}` }, { value: "failed", label: "失败" }]} />
      </TopBar>
      <div className="page" style={{ display: "flex", gap: 20, alignItems: "flex-start" }}>
        <section className="card col" style={{ flex: "0 0 340px", gap: 2, padding: 10, position: "sticky", top: 84, maxHeight: "calc(100vh - 104px)", overflow: "auto" }}>
          {loading && <Loading />}
          {error && <ErrorBox message={error} onRetry={reload} />}
          {!loading && !shown.length && <div className="empty">还没有记录</div>}
          {groups.map(([label, items]) => (
            <div key={label} className="col" style={{ gap: 2 }}>
              <span className="small muted bold" style={{ padding: "8px 12px 2px" }}>{label}</span>
              {items.map((job) => (
                <Link key={job.id} to={`/jobs/${job.id}`} className="row" style={{ gap: 12, padding: "10px 12px", borderRadius: 12, textDecoration: "none", color: "inherit", background: job.id === selected ? "var(--brand-tint)" : undefined, boxShadow: job.id === selected ? "inset 0 0 0 2px var(--brand)" : undefined }}>
                  <StateIcon job={job} />
                  <span className="grow" style={{ display: "flex", flexDirection: "column" }}>
                    <span className="bold ellipsis">{job.title || "新闻视频"}</span>
                    <span className="small muted ellipsis">{stateText(job)}</span>
                  </span>
                  {job.state === "failed" && <button className="btn sm ghost" onClick={(event) => quickAction(event, job, "retry")}>重试</button>}
                  {job.state === "processing" && (job.queue_position || 0) > 0 && job.can_cancel && <button className="btn sm warn" onClick={(event) => quickAction(event, job, "cancel")}>取消</button>}
                  <span className="small muted num">{formatTime(job.created_at).replace(/^昨天 /, "")}</span>
                </Link>
              ))}
            </div>
          ))}
        </section>
        <section className="card" style={{ flex: "1 1 0", minWidth: 0, padding: "18px 20px" }}>
          {selected ? <JobDetail key={selected} id={selected} onChanged={reload} /> : <div className="empty">选左边一条记录</div>}
        </section>
      </div>
    </>
  );
}

// ---------------------------------------------------------------- 详情
type DetailTab = "title" | "script" | "visuals" | "share";

function JobDetail({ id, onChanged }: { id: string; onChanged: () => void }) {
  const navigate = useNavigate();
  const { data: job, error, loading, reload, setData } = useApi(() => api.job(id), [id]);
  usePolling(() => api.job(id).then(setData).catch(() => undefined), 3000, job?.state === "processing");
  const [tab, setTab] = useState<DetailTab>("title");
  const [toast, showToast] = useToast();
  useEffect(() => { if (job && job.state !== "processing") onChanged(); /* 状态变了刷新列表 */ }, [job?.state]); // eslint-disable-line react-hooks/exhaustive-deps

  if (loading && !job) return <Loading />;
  if (error) return <ErrorBox message={error} onRetry={reload} />;
  if (!job) return null;

  const created = (next: Job) => {
    onChanged();
    navigate(`/jobs/${next.id}`);
  };

  if (job.state !== "complete") return <Progress job={job} onAction={async (action) => {
    try {
      if (action === "cancel") setData(await api.cancelJob(job.id));
      else created(await api.retryJob(job.id));
    } catch (err) {
      showToast(err instanceof Error ? err.message : "操作失败");
    }
  }} toast={toast} />;

  const tabs: { value: DetailTab; label: string }[] = [
    { value: "title", label: "发布标题" },
    { value: "script", label: "口播文案" },
    ...(job.deep ? [{ value: "visuals" as DetailTab, label: "换画面" }] : []),
    { value: "share", label: "分享图文" },
  ];
  return (
    <div style={{ display: "flex", gap: 22, alignItems: "flex-start" }}>
      <div className="col" style={{ width: 300, flex: "none", gap: 10 }}>
        <Player job={job} />
        <span className="small muted" style={{ textAlign: "center" }}>竖屏 1080×1920</span>
      </div>
      <div className="col grow" style={{ gap: 14 }}>
        <span className="row" style={{ gap: 6 }}><span className="chip c-m"><Icon name="check" size={10} width={3} />做好了</span><span className="chip c-p">{job.uploaded ? "上传素材" : job.deep ? "深度解析" : "快讯"}</span></span>
        <span style={{ fontSize: 20, lineHeight: "29px", fontWeight: 700 }}>{job.title || "新闻视频"}</span>
        <span className="small muted">{formatTime(job.created_at)}{job.source_url && <> · <a href={job.source_url} target="_blank" rel="noreferrer">原文 ↗</a></>}</span>
        <div className="row">
          <button className="btn lg grow" disabled={!job.has_video} onClick={() => download(api.videoPath(job.id), `${job.title || "新闻视频"}.mp4`).catch((err) => showToast(err.message))}><Icon name="download" />下载视频</button>
          <button className="btn lg soft grow" onClick={() => navigator.clipboard.writeText(job.publication_title || job.title).then(() => showToast("标题已复制"))}><Icon name="copy" />复制标题</button>
          {job.has_cover && <button className="btn lg ghost" onClick={() => download(api.coverPath(job.id), "封面.jpg")}>下载封面</button>}
        </div>
        <Tabs value={tab} onChange={setTab} options={tabs} />
        {tab === "title" && <TitleTab job={job} notify={showToast} />}
        {tab === "script" && <ScriptTab job={job} onCreated={created} notify={showToast} />}
        {tab === "visuals" && <VisualsTab job={job} onCreated={created} notify={showToast} />}
        {tab === "share" && <ShareTab job={job} notify={showToast} />}
      </div>
      {toast}
    </div>
  );
}

function Progress({ job, onAction, toast }: { job: Job; onAction: (action: "cancel" | "retry") => void; toast: React.ReactNode }) {
  const waiting = job.state === "processing" && (job.queue_position || 0) > 0;
  return (
    <div className="col" style={{ maxWidth: 720, gap: 18 }}>
      <span className="row" style={{ gap: 6 }}><span className="chip c-p">{job.uploaded ? "上传素材" : job.deep ? "深度解析" : "快讯"}</span>
        {job.state === "failed" && <span className="chip c-r">失败</span>}{job.state === "cancelled" && <span className="chip c-g">已终止</span>}</span>
      <h2 style={{ margin: 0, fontSize: 22, lineHeight: "31px" }}>{job.title || "新闻视频"}</h2>
      {job.state === "processing" && (
        <div className="card pad col" style={{ gap: 14 }}>
          <div className="row" style={{ alignItems: "baseline", gap: 12 }}>
            <span className="num" style={{ fontSize: 40, lineHeight: "48px", fontWeight: 700 }}>{waiting ? `#${job.queue_position}` : `${job.progress}%`}</span>
            <span className="muted">{waiting ? `排队中，前面还有 ${(job.queue_position || 1) - 1} 条` : job.phase || "处理中"}</span>
          </div>
          {!waiting && <div className="bar" style={{ height: 8 }}><i style={{ width: `${job.progress}%` }} /></div>}
          <span className="small muted">可以关掉这个页面，做好了在这里看。</span>
        </div>
      )}
      {job.state === "failed" && <div className="note">{job.error || "生成失败"}</div>}
      {job.steps.length > 0 && (
        <div className="card pad col" style={{ gap: 2 }}>
          <b style={{ marginBottom: 6 }}>步骤</b>
          {job.steps.map((step) => (
            <div key={step.key} className="row" style={{ alignItems: "flex-start", padding: "6px 0" }}>
              <span style={{ width: 20, height: 20, flex: "none", borderRadius: 9999, marginTop: 1, display: "flex", alignItems: "center", justifyContent: "center", ...(step.state === "done" ? { background: "var(--accent)" } : step.state === "running" ? { border: "4px solid var(--accent)" } : step.state === "failed" ? { background: "var(--rise)" } : { border: "2px solid var(--field-line)" }) }}>
                {step.state === "done" && <Icon name="check" size={12} color="#fff" width={3} />}
              </span>
              <span className="grow" style={{ display: "flex", flexDirection: "column" }}>
                <span style={{ fontWeight: step.state === "running" ? 700 : 600, color: step.state === "pending" ? "var(--faint)" : undefined }}>{step.name}</span>
                {step.detail && <span className="small muted">{step.detail}</span>}
              </span>
            </div>
          ))}
        </div>
      )}
      {job.logs && job.logs.length > 0 && <details><summary className="small muted">日志</summary><pre style={{ whiteSpace: "pre-wrap", fontSize: 12, background: "var(--bg)", padding: 12, borderRadius: 10 }}>{job.logs.join("\n")}</pre></details>}
      <div className="row">
        {job.state === "processing" && job.can_cancel && <button className="btn warn" onClick={() => onAction("cancel")}>{waiting ? "取消排队" : "不做了"}</button>}
        {job.state === "failed" && <button className="btn" onClick={() => onAction("retry")}>重试</button>}
        {job.script_ready && <span className="small muted">口播文案已经写好，做完后可以在「口播文案」里看和改。</span>}
      </div>
      {toast}
    </div>
  );
}

function Player({ job }: { job: Job }) {
  const [src, setSrc] = useState("");
  const [state, setState] = useState<"idle" | "loading" | "error">("idle");
  const load = () => {
    setState("loading");
    blobUrl(api.videoPath(job.id)).then((url) => { setSrc(url); setState("idle"); }).catch(() => setState("error"));
  };
  // 自动取视频；服务器成片已清理时只显示封面
  useEffect(() => { if (job.has_video) load(); }, [job.id]); // eslint-disable-line react-hooks/exhaustive-deps
  return (
    <div className="player">
      {src && !src.startsWith("data:") ? <video src={src} controls playsInline poster={undefined} />
        : job.has_cover ? <AuthImage path={api.coverPath(job.id)} style={{ objectFit: "contain" }} /> : null}
      {state === "loading" && <span style={{ position: "absolute" }} className="row"><Spinner />正在加载视频…</span>}
      {state === "error" && <span style={{ position: "absolute", padding: 20, textAlign: "center" }}>视频加载失败<br /><button className="btn sm ghost" onClick={load}>重试</button></span>}
      {!job.has_video && <span style={{ position: "absolute", padding: 20, textAlign: "center" }}>{job.server_video_deleted ? "服务器上的成片已按保留期清理" : "没有成片"}</span>}
    </div>
  );
}

function TitleTab({ job, notify }: { job: Job; notify: (text: string) => void }) {
  const [title, setTitle] = useState(job.publication_title || job.title);
  return (
    <div className="col" style={{ gap: 10 }}>
      <textarea className="textarea" style={{ minHeight: 90 }} value={title} onChange={(event) => setTitle(event.target.value)} aria-label="发布标题" />
      <div className="row">
        <button className="btn soft" onClick={() => navigator.clipboard.writeText(title).then(() => notify("标题已复制"))}><Icon name="copy" size={15} />复制</button>
        <span className="small muted">下载视频、复制标题后，到抖音、视频号、小红书等直接上传。</span>
      </div>
    </div>
  );
}

function ScriptTab({ job, onCreated, notify }: { job: Job; onCreated: (job: Job) => void; notify: (text: string) => void }) {
  const { data, error, loading, reload } = useApi(() => api.jobScript(job.id), [job.id]);
  const [segments, setSegments] = useState<string[] | null>(null);
  const [busy, setBusy] = useState(false);
  const current = segments ?? data?.segments ?? [];
  const chars = current.join("").replace(/\s/g, "").length;
  if (loading) return <Loading />;
  if (error) return <ErrorBox message={error} onRetry={reload} />;
  const changed = segments !== null && segments.join("") !== data?.segments.join("");
  const submit = async () => {
    setBusy(true);
    try {
      onCreated(await api.rescript(job.id, current));
    } catch (err) {
      notify(err instanceof Error ? err.message : "提交失败");
      setBusy(false);
    }
  };
  return (
    <div className="col" style={{ gap: 10 }}>
      <span className="small muted">共 {chars} 字，约 {Math.round(chars / 4.4)} 秒。{data?.editable ? "改完点「按新文案重新生成」，画面不变。" : "这条视频的画面素材已清理，不能改文案重新生成。"}</span>
      {current.map((segment, index) => (
        <textarea key={index} className="textarea" style={{ minHeight: 70 }} value={segment} disabled={!data?.editable}
          onChange={(event) => setSegments(current.map((value, i) => (i === index ? event.target.value : value)))} aria-label={`第 ${index + 1} 段`} />
      ))}
      <div className="row">
        <button className="btn ghost" onClick={() => navigator.clipboard.writeText(current.join("\n")).then(() => notify("口播文案已复制"))}><Icon name="copy" size={15} />复制全文</button>
        {data?.editable && <button className="btn right-auto" disabled={!changed || busy} onClick={submit}>{busy ? "正在提交…" : "按新文案重新生成"}</button>}
      </div>
    </div>
  );
}

type Pending = { action: "remove" } | { action: "replace"; file: File; preview: string };

function VisualsTab({ job, onCreated, notify }: { job: Job; onCreated: (job: Job) => void; notify: (text: string) => void }) {
  const { data, error, loading, reload } = useApi(() => api.jobVisuals(job.id), [job.id]);
  const [pending, setPending] = useState<Record<string, Pending>>({});
  const [target, setTarget] = useState<JobVisual | null>(null);
  const [busy, setBusy] = useState("");
  const input = useRef<HTMLInputElement>(null);
  if (loading) return <Loading />;
  if (error) return <ErrorBox message={error} onRetry={reload} />;
  if (!data) return null;
  const count = Object.keys(pending).length;
  const kindName = (kind: string) => (kind === "video" ? "视频片段" : kind === "card" ? "图表卡" : "照片");

  const submit = async () => {
    const remaining = data.items.filter((item) => pending[item.key]?.action !== "remove");
    if (!remaining.length) return notify("至少要留一个画面");
    setBusy("准备中…");
    try {
      const changes = [];
      let index = 0;
      for (const [key, change] of Object.entries(pending)) {
        if (change.action === "remove") changes.push({ key, action: "remove" as const });
        else {
          setBusy(`正在上传第 ${++index} 张图…`);
          const uploaded = await api.uploadFile(change.file);
          changes.push({ key, action: "replace" as const, upload: uploaded.upload_id });
        }
      }
      setBusy("正在重新画画面、提交生成…");
      onCreated(await api.revisuals(job.id, changes));
    } catch (err) {
      notify(err instanceof Error ? err.message : "提交失败");
      setBusy("");
    }
  };

  return (
    <div className="col" style={{ gap: 12 }}>
      <div className="col" style={{ gap: 4 }}>
        <b>视频里的 {data.items.length} 个画面</b>
        <span className="small muted">{data.editable ? "点画面：换成本地图片，或删掉。删掉的画面时间给前一个画面。" : data.reason}</span>
      </div>
      <div className="frames">
        {data.items.map((item) => {
          const change = pending[item.key];
          return (
            <span key={item.key} className="col" style={{ gap: 3 }}>
              <button className={`frame${change ? " changed" : ""}`} disabled={!data.editable} onClick={() => setTarget(item)} aria-label={`${kindName(item.kind)}，约${item.seconds}秒`}>
                {change?.action === "replace" ? <img src={change.preview} alt="" /> : <AuthImage path={item.frame} style={{ opacity: change?.action === "remove" ? 0.3 : 1 }} />}
                {change && <span className={`flag${change.action === "remove" ? " del" : ""}`}>{change.action === "remove" ? "删掉" : "换图"}</span>}
              </button>
              <span style={{ fontSize: 10, lineHeight: "14px", color: "var(--muted)" }}>{kindName(item.kind)}<br />{item.seconds}秒</span>
            </span>
          );
        })}
      </div>
      {target && (
        <div className="card pad row" style={{ background: "var(--brand-tint)" }}>
          <b className="grow">第 {data.items.indexOf(target) + 1} 个画面（{kindName(target.kind)} · {target.seconds}秒）</b>
          <button className="btn soft" onClick={() => input.current?.click()}><Icon name="image" size={15} />换成本地图片</button>
          <button className="btn warn" onClick={() => { setPending({ ...pending, [target.key]: { action: "remove" } }); setTarget(null); }}><Icon name="trash" size={15} />删掉</button>
          {pending[target.key] && <button className="btn ghost" onClick={() => { const next = { ...pending }; delete next[target.key]; setPending(next); setTarget(null); }}><Icon name="undo" size={15} />恢复</button>}
          <button className="btn sm ghost" onClick={() => setTarget(null)} aria-label="关闭"><Icon name="x" size={13} /></button>
          <input ref={input} type="file" accept="image/*" hidden onChange={(event) => {
            const file = event.target.files?.[0];
            if (file && target) setPending({ ...pending, [target.key]: { action: "replace", file, preview: URL.createObjectURL(file) } });
            event.target.value = "";
            setTarget(null);
          }} />
        </div>
      )}
      {count > 0 && (
        <div className="row" style={{ padding: "10px 14px", borderRadius: 10, background: "var(--brand-tint)" }}>
          <span className="small grow" style={{ color: "var(--brand-deep)" }}><b>{count} 处改动</b>。口播不变，所有画面按同一个标题重新画。</span>
          <button className="btn ghost" disabled={!!busy} onClick={() => setPending({})}>撤销</button>
          <button className="btn" disabled={!!busy} onClick={submit}>{busy || "按改动重新生成"}</button>
        </div>
      )}
    </div>
  );
}

function ShareTab({ job, notify }: { job: Job; notify: (text: string) => void }) {
  const navigate = useNavigate();
  const visuals = useApi(() => (job.deep ? api.jobVisuals(job.id) : Promise.resolve(null)), [job.id]);
  const script = useApi(() => api.jobScript(job.id), [job.id]);
  const pictures = (visuals.data?.items || []).filter((item) => item.exists && item.kind !== "video").map((item) => item.photo);
  const narration = (script.data?.segments || []).join("\n\n");
  return (
    <div className="col" style={{ gap: 12 }}>
      <span className="small muted">用视频里的配图（不带标题框）加文案发图文。要按编辑规范写平台版 / 完整版文案，去工作台的「做图文」。</span>
      {pictures.length > 0 && (
        <div className="row wrap" style={{ gap: 6 }}>
          {pictures.map((path) => <span key={path} style={{ width: 84, height: 84, borderRadius: 8, overflow: "hidden" }}><AuthImage path={path} /></span>)}
        </div>
      )}
      <textarea className="textarea" style={{ minHeight: 160 }} defaultValue={narration} key={narration} aria-label="口播稿" />
      <div className="row wrap">
        <button className="btn soft" onClick={() => navigator.clipboard.writeText(narration).then(() => notify("口播稿已复制"))}><Icon name="copy" size={15} />复制口播稿</button>
        {pictures.length > 0 && <button className="btn ghost" onClick={async () => { let i = 0; for (const path of pictures) await download(path, `配图-${++i}.jpg`); }}><Icon name="download" size={15} />下载 {pictures.length} 张配图</button>}
        {job.source_url && <button className="btn right-auto" onClick={() => navigate(`/work?url=${encodeURIComponent(job.source_url)}&tab=tuwen`)}>按编辑规范写分享文案</button>}
      </div>
    </div>
  );
}
