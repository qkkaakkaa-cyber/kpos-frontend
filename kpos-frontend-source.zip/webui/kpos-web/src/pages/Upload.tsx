import { useEffect, useMemo, useRef, useState } from "react";
import { useNavigate } from "react-router-dom";
import * as api from "../api/endpoints";
import { GenerateOptions, useGenerateSettings } from "../components/GenerateOptions";
import { TopBar } from "../components/Layout";
import { useSession } from "../components/session";
import { Icon, Seg, useToast } from "../components/ui";

interface Material {
  id: string;
  file: File;
  preview: string;
  kind: "video" | "image";
  seconds?: number;
}

const today = () => new Date().toLocaleDateString("en-CA", { timeZone: "Asia/Bangkok" });

/** 手动上传：自己的图片、视频 + 资料（按模板改写）或文案（原样配音） → POST /uploads 逐个上传 → POST /jobs/upload */
export default function Upload() {
  const navigate = useNavigate();
  const { options } = useSession();
  const [settings, setSettings] = useGenerateSettings(options, "upload");
  const limits = options?.upload_limits || { files: 8, video_mb: 200, image_mb: 15, material_chars: 6000, script_chars: 800 };
  const [materials, setMaterials] = useState<Material[]>([]);
  const [mode, setMode] = useState<"rewrite" | "verbatim">("rewrite");
  const [text, setText] = useState("");
  const [title, setTitle] = useState("");
  const [date, setDate] = useState(today());
  const [signoff, setSignoff] = useState(true);
  const [sourceVolume, setSourceVolume] = useState(options?.source_volume.default ?? 10);
  const [over, setOver] = useState(false);
  const [busy, setBusy] = useState(false);
  const [status, setStatus] = useState("");
  const [toast, showToast] = useToast();
  const input = useRef<HTMLInputElement>(null);

  useEffect(() => () => materials.forEach((item) => URL.revokeObjectURL(item.preview)), [materials]);
  const [minChars, maxChars] = mode === "rewrite" ? [40, limits.material_chars] : [10, limits.script_chars];
  const problem = useMemo(() => {
    if (!materials.length) return "先放进图片或视频";
    if (text.trim().length < minChars) return mode === "rewrite" ? `资料至少 ${minChars} 字` : `文案至少 ${minChars} 字`;
    if (text.trim().length > maxChars) return `最多 ${maxChars} 字`;
    return "";
  }, [materials, text, mode, minChars, maxChars]);

  const add = (files: FileList | File[]) => {
    const next: Material[] = [];
    for (const file of Array.from(files)) {
      const kind = file.type.startsWith("video") ? "video" : file.type.startsWith("image") ? "image" : null;
      if (!kind) { showToast(`${file.name} 不是图片或视频`); continue; }
      const mb = file.size / 1048576;
      if (kind === "image" && mb > limits.image_mb) { showToast(`${file.name} 超过 ${limits.image_mb}MB`); continue; }
      if (kind === "video" && mb > limits.video_mb) { showToast(`${file.name} 超过 ${limits.video_mb}MB，先压缩一下`); continue; }
      next.push({ id: crypto.randomUUID(), file, kind, preview: URL.createObjectURL(file) });
    }
    setMaterials((old) => [...old, ...next].slice(0, limits.files));
  };

  const submit = async () => {
    if (problem) return showToast(problem);
    setBusy(true);
    try {
      const ids: string[] = [];
      for (const [index, material] of materials.entries()) {
        setStatus(`正在上传第 ${index + 1}/${materials.length} 个素材…`);
        const result = await api.uploadFile(material.file, (fraction) => setStatus(`正在上传第 ${index + 1}/${materials.length} 个素材 ${Math.round(fraction * 100)}%`));
        ids.push(result.upload_id);
      }
      setStatus("正在提交生成任务…");
      const job = await api.createUploadJob({ ...settings, upload_ids: ids, mode, text: text.trim(), title: title.trim() || undefined, date, signoff, source_volume: sourceVolume });
      navigate(`/jobs/${job.id}`);
    } catch (err) {
      showToast(err instanceof Error ? err.message : "提交失败");
      setBusy(false);
      setStatus("");
    }
  };

  return (
    <>
      <TopBar title="手动上传" sub="用自己拍的图片、视频做新闻视频" />
      <div className="page">
        <div className="split">
          <section className="card pad col" style={{ flex: "1 1 0", maxWidth: 720 }}>
            <div className="row"><span className="h2">素材</span><span className="small muted">已选 {materials.length} 个 · 最多 {limits.files} 个，视频和图片都可以</span></div>
            <div className={`dropzone${over ? " over" : ""}`}
              onDragOver={(event) => { event.preventDefault(); setOver(true); }} onDragLeave={() => setOver(false)}
              onDrop={(event) => { event.preventDefault(); setOver(false); add(event.dataTransfer.files); }}>
              <Icon name="upload" size={28} color="var(--brand)" />
              <b>把图片、视频拖到这里，或 <button className="title-link" style={{ color: "var(--brand)", fontSize: 14, textDecoration: "underline" }} onClick={() => input.current?.click()}>选择文件</button></b>
              <span className="small muted">视频不超过 {limits.video_mb}MB，图片不超过 {limits.image_mb}MB；素材加起来至少 20 秒</span>
              <input ref={input} type="file" accept="image/*,video/*" multiple hidden onChange={(event) => { if (event.target.files) add(event.target.files); event.target.value = ""; }} />
            </div>
            {materials.length > 0 && (
              <div style={{ display: "grid", gridTemplateColumns: "repeat(4, 1fr)", gap: 10 }}>
                {materials.map((item) => (
                  <span key={item.id} className="pic" style={{ background: "#1f2430" }}>
                    {item.kind === "image" ? <img src={item.preview} alt={item.file.name} />
                      : <video src={item.preview} muted onLoadedMetadata={(event) => { const seconds = (event.target as HTMLVideoElement).duration; setMaterials((old) => old.map((m) => m.id === item.id ? { ...m, seconds } : m)); }} style={{ width: "100%", height: "100%", objectFit: "cover" }} />}
                    <span className="tag"><Icon name={item.kind === "video" ? "play" : "image"} size={11} color="#fff" width={2.5} />{item.kind === "video" ? (item.seconds ? `0:${String(Math.round(item.seconds)).padStart(2, "0")}` : "视频") : "图片"}</span>
                    <button className="tick" aria-label="移除" style={{ borderRadius: 9999, cursor: "pointer" }} onClick={() => setMaterials((old) => old.filter((m) => m.id !== item.id))}><Icon name="x" size={11} /></button>
                  </span>
                ))}
              </div>
            )}
            {materials.some((item) => item.kind === "video") && (
              <div className="row" style={{ padding: "12px 14px", borderRadius: 12, background: "var(--bg)" }}>
                <b style={{ flex: "none" }}>视频原声音量</b>
                <input type="range" min={0} max={options?.source_volume.max ?? 400} step={5} value={sourceVolume} onChange={(event) => setSourceVolume(Number(event.target.value))} aria-label="视频原声音量" />
                <span className="small num muted" style={{ width: 40, textAlign: "right" }}>{sourceVolume}%</span>
              </div>
            )}
          </section>
          <aside className="card panel" style={{ flex: "0 0 440px" }}>
            <div className="panel-head"><span className="h2">制作区</span></div>
            <div className="panel-body">
              <div className="col" style={{ gap: 8 }}>
                <b>文案怎么来</b>
                <Seg full value={mode} onChange={setMode} options={[{ value: "rewrite", label: "按模板改写" }, { value: "verbatim", label: "原样配音" }]} />
                <span className="small muted">按模板改写：贴新闻资料或文稿（40–{limits.material_chars} 字），系统按泰国中文社格式写口播。原样配音：文案一字不改（10–{limits.script_chars} 字）。</span>
              </div>
              <label className="label">{mode === "rewrite" ? "新闻资料或文稿" : "口播文案"}
                <textarea className="textarea" style={{ minHeight: 150 }} value={text} onChange={(event) => setText(event.target.value)}
                  placeholder={mode === "rewrite" ? "把现场情况、警方通报、采访内容贴在这里……" : "按这段文字原样配音并生成字幕，系统不改写、不压缩。"} />
                <span className="small muted" style={{ textAlign: "right", fontWeight: 400 }}>{text.trim().length} / {maxChars} 字</span>
              </label>
              <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 10 }}>
                <label className="label">标题（可不填）<input className="input" value={title} maxLength={40} onChange={(event) => setTitle(event.target.value)} placeholder="不填就自动起" /></label>
                <label className="label">报道日期<input className="input" type="date" value={date} onChange={(event) => setDate(event.target.value)} /></label>
              </div>
              <label className="row small"><input type="checkbox" checked={signoff} onChange={(event) => setSignoff(event.target.checked)} />结尾加“泰国中文社X月X日报道”</label>
              <GenerateOptions options={options} settings={settings} onChange={setSettings} durations={options?.upload_durations || [30, 45, 60, 90]} />
            </div>
            <div className="panel-foot">
              <button className="btn lg block" disabled={busy} onClick={submit}><Icon name="play" size={18} />{busy ? status || "正在提交…" : "一键生成视频"}</button>
              <span className="small muted" style={{ textAlign: "center" }}>{problem || "先上传素材，再写口播、配音、剪辑"}</span>
            </div>
          </aside>
        </div>
      </div>
      {toast}
    </>
  );
}
