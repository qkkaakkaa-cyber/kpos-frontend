import { useState } from "react";
import { useNavigate } from "react-router-dom";
import * as api from "../api/endpoints";
import type { ArticlePreview } from "../api/types";
import { useGenerateSettings } from "../components/GenerateOptions";
import { TopBar } from "../components/Layout";
import { useSession } from "../components/session";
import { AuthImage, Icon, Spinner, useToast } from "../components/ui";
import { useLocal } from "../hooks/useApi";

interface Recent {
  url: string;
  title: string;
  source: string;
  images: number;
  cover: string;
  at: string;
  done?: string;
}

const MAX_LINKS = 5;
const KEEP_DAYS = 7;

/** 公众号剪辑：一次贴最多 5 条公众号链接，取出图文后做快讯、深度或图文。最近提取过的记在本机 7 天。 */
export default function Wechat() {
  const navigate = useNavigate();
  const { options } = useSession();
  const [settings] = useGenerateSettings(options, "news");
  const [text, setText] = useState("");
  const [extracting, setExtracting] = useState(false);
  const [results, setResults] = useState<{ url: string; article?: ArticlePreview; error?: string }[]>([]);
  const [store, setStore] = useLocal<{ items: Recent[] }>("wechat-recent", { items: [] });
  const [busy, setBusy] = useState("");
  const [toast, showToast] = useToast();
  const recent = store.items.filter((item) => Date.now() - new Date(item.at).getTime() < KEEP_DAYS * 86400000);

  const remember = (article: ArticlePreview, done?: string) => {
    const others = recent.filter((item) => item.url !== article.url);
    const old = recent.find((item) => item.url === article.url);
    setStore({ items: [{ url: article.url, title: article.title, source: article.source, images: article.images.length, cover: article.images[0] || "", at: new Date().toISOString(), done: done || old?.done }, ...others].slice(0, 50) });
  };

  const extract = async () => {
    const links = text.split(/\s+/).map((line) => line.trim()).filter((line) => /^https?:\/\//i.test(line));
    if (!links.length) return showToast("请贴 mp.weixin.qq.com 开头的公众号文章链接");
    if (links.length > MAX_LINKS) showToast(`一次最多 ${MAX_LINKS} 条，只取前 ${MAX_LINKS} 条`);
    setExtracting(true);
    const output = await Promise.all(links.slice(0, MAX_LINKS).map(async (url) => {
      try {
        const article = await api.article(url);
        remember(article);
        return { url, article };
      } catch (err) {
        return { url, error: err instanceof Error ? err.message : "提取失败" };
      }
    }));
    setResults(output);
    setExtracting(false);
  };

  const generate = async (url: string, deep: boolean, article?: ArticlePreview) => {
    setBusy(url + deep);
    try {
      await api.createJob({ ...settings, url, deep });
      if (article) remember(article, deep ? "已做深度" : "已做快讯");
      else setStore({ items: recent.map((item) => item.url === url ? { ...item, done: deep ? "已做深度" : "已做快讯" } : item) });
      showToast(deep ? "深度解析已提交，在「生成记录」里看" : "快讯已提交，约 3 分钟做好");
    } catch (err) {
      showToast(err instanceof Error ? err.message : "提交失败");
    } finally {
      setBusy("");
    }
  };

  const open = (url: string, tab = "video") => navigate(`/work?url=${encodeURIComponent(url)}&tab=${tab}`);
  const actions = (url: string, images: number, article?: ArticlePreview) => {
    const enough = images >= 2;
    return (
      <>
        <button className="btn ghost" style={{ padding: "0 12px" }} onClick={() => open(url, "tuwen")}><Icon name="image" size={15} color="var(--brand)" />图文</button>
        <button className="btn soft" style={{ width: 80 }} disabled={!enough || !!busy} onClick={() => generate(url, false, article)}><Icon name="bolt" size={15} />快讯</button>
        <button className="btn" style={{ width: 80 }} disabled={!enough || !!busy} onClick={() => generate(url, true, article)}><Icon name="play" size={15} />深度</button>
      </>
    );
  };

  return (
    <>
      <TopBar title="公众号剪辑" sub="贴公众号文章链接，取出标题、正文和配图，再做快讯、深度或图文" />
      <div className="page">
        <div className="center" style={{ gap: 14 }}>
          <div className="card pad col" style={{ gap: 12 }}>
            <span className="h2">贴公众号文章链接</span>
            <div className="row" style={{ alignItems: "stretch" }}>
              <textarea className="textarea grow" style={{ minHeight: 46, height: 46 + Math.min(4, Math.max(0, text.split("\n").length - 1)) * 23 }} value={text}
                onChange={(event) => setText(event.target.value)} placeholder="https://mp.weixin.qq.com/s/……（一行一条，最多 5 条）" aria-label="公众号文章链接" />
              <button className="btn" style={{ height: 46, alignSelf: "flex-start" }} disabled={extracting} onClick={extract}>{extracting ? "提取中…" : "提取"}</button>
            </div>
            <span className="small muted">公众号文章已经是中文，会按泰国中文社格式改写口播。想写深度提示、改配音，就点标题进工作台。</span>
          </div>

          {extracting && <div className="row muted"><Spinner />正在提取标题、正文和配图…</div>}
          {results.map((result) => result.article ? (
            <div key={result.url} className="card" style={{ padding: "18px 20px", display: "flex", gap: 18, border: "2px solid var(--brand)" }}>
              <span className="thumb" style={{ width: 200, height: 130, borderRadius: 12 }}>
                {result.article.images[0] && <AuthImage path={result.article.images[0]} />}
                <span className={`count${result.article.images.length >= 2 ? "" : " few"}`}><Icon name="image" size={12} color="#fff" width={2.5} />{result.article.images.length} 张</span>
              </span>
              <span className="grow col" style={{ gap: 8 }}>
                <span className="row small muted" style={{ gap: 8 }}><span className="chip c-m">刚提取</span>{result.article.source} · {result.article.date} · {result.article.chars} 字</span>
                <button className="title-link" style={{ fontSize: 18, lineHeight: "26px", fontWeight: 700 }} onClick={() => open(result.url)}>{result.article.title}</button>
                <span className="small muted ellipsis">{result.article.paragraphs[0]}</span>
                {result.article.images.length < 2 && <span className="chip c-w" style={{ alignSelf: "flex-start" }}>原图不够 2 张，进工作台用「一键找图」补</span>}
                <span className="row" style={{ marginTop: 4 }}>{actions(result.url, result.article.images.length, result.article)}<button className="btn ghost" onClick={() => open(result.url)}>打开工作台</button></span>
              </span>
            </div>
          ) : (
            <div key={result.url} className="note">{result.url}：{result.error}</div>
          ))}

          <div className="row" style={{ paddingTop: 6 }}><span className="h2">最近提取过的公众号文章</span><span className="small muted">保留 {KEEP_DAYS} 天，记在这台电脑上</span></div>
          {!recent.length && <div className="empty card">还没有提取过公众号文章</div>}
          {recent.map((item) => (
            <div key={item.url} className="card news-row">
              <span className="thumb">
                {item.cover && <AuthImage path={item.cover} />}
                <span className={`count${item.images >= 2 ? "" : " few"}`}><Icon name="image" size={11} color="#fff" width={2.5} />{item.images}</span>
              </span>
              <span className="grow col" style={{ gap: 6 }}>
                <button className="title-link" onClick={() => open(item.url)}>{item.title}</button>
                <span className="row small muted" style={{ gap: 8 }}>
                  <span className="chip c-m">公众号</span>{item.source} · {new Date(item.at).toLocaleString("zh-CN", { month: "numeric", day: "numeric", hour: "2-digit", minute: "2-digit" })}
                  {item.done && <span className="chip c-m"><Icon name="check" size={10} width={3} />{item.done}</span>}
                </span>
              </span>
              {actions(item.url, item.images)}
            </div>
          ))}
        </div>
      </div>
      {toast}
    </>
  );
}
