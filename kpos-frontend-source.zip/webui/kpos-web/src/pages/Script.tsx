import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import * as api from "../api/endpoints";
import type { ScriptSearch } from "../api/types";
import { GenerateOptions, useGenerateSettings } from "../components/GenerateOptions";
import { TopBar } from "../components/Layout";
import { useSession } from "../components/session";
import { AuthImage, ErrorBox, Icon, Seg, Spinner, useToast } from "../components/ui";

const MODE_NOTE: Record<string, string> = {
  视频剪辑: "只用视频",
  混合剪辑: "视频为主、图片补空",
  图文剪辑: "没有合适视频时只用图片",
};

/** 智能剪辑：写一句事件提示或贴文案 → 服务器查资料、找视频和图片、整理口播 → 选剪辑方式生成。 */
export default function Script() {
  const navigate = useNavigate();
  const { options } = useSession();
  const [settings, setSettings] = useGenerateSettings(options, "script");
  const [prompt, setPrompt] = useState("");
  const [links, setLinks] = useState("");
  const [clues, setClues] = useState("");
  const [eventDate, setEventDate] = useState("");
  const [search, setSearch] = useState<ScriptSearch | null>(null);
  const [error, setError] = useState("");
  const [script, setScript] = useState("");
  const [mode, setMode] = useState("混合剪辑");
  const [busy, setBusy] = useState(false);
  const [toast, showToast] = useToast();

  // 查找在后台跑，每 2 秒问一次
  useEffect(() => {
    if (!search || search.state !== "running") return;
    const timer = setTimeout(async () => {
      try {
        const next = await api.scriptSearch(search.id);
        setSearch(next);
        if (next.state === "done") {
          setScript(next.script);
          if (next.modes.length && !next.modes.includes(mode)) setMode(next.modes.includes("混合剪辑") ? "混合剪辑" : next.modes[0]);
        }
        if (next.state === "error") setError(next.error || "查找失败");
      } catch (err) {
        setError(err instanceof Error ? err.message : "查找失败");
      }
    }, 2000);
    return () => clearTimeout(timer);
  }, [search, mode]);

  const videoLinks = links.split(/\s+/).filter((line) => /^https?:\/\//i.test(line)).slice(0, 3);
  const start = async () => {
    if (!prompt.trim() && !videoLinks.length) return showToast("写一句事件提示，或至少贴一条视频链接");
    setError("");
    setSearch(null);
    try {
      setSearch(await api.startScriptSearch({ prompt: prompt.trim(), video_links: videoLinks, clues: clues.trim(), event_date: eventDate || undefined }));
    } catch (err) {
      setError(err instanceof Error ? err.message : "查找失败");
    }
  };

  const generate = async () => {
    if (!search || search.state !== "done") return;
    setBusy(true);
    try {
      const job = await api.createScriptJob({ ...settings, duration: 90, search_id: search.id, script: script.trim(), edit_mode: mode });
      navigate(`/jobs/${job.id}`);
    } catch (err) {
      showToast(err instanceof Error ? err.message : "提交失败");
      setBusy(false);
    }
  };

  const usable = search?.candidates.filter((item) => item.ok) || [];
  return (
    <>
      <TopBar title="智能剪辑" sub="写一句事件提示或贴文案，系统查资料、核对前因后果、找视频和图片，整理 90 秒内口播" />
      <div className="page">
        <div className="split">
          <section className="col" style={{ flex: "1 1 0", maxWidth: 760 }}>
            <div className="card pad col" style={{ gap: 12 }}>
              <div className="row"><span className="h2">① 写事件提示或贴文案</span><span className="small muted">一句话提示也行，完整资料也行</span></div>
              <textarea className="textarea" value={prompt} maxLength={2000} onChange={(event) => setPrompt(event.target.value)} aria-label="事件提示或已有文案"
                placeholder="例如：拉廊府山洪，祖母与3名儿童遇险，查找事故经过及官方救援进展。也可粘贴完整资料；只提供视频时可留空。" />
              <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 10 }}>
                <label className="label">视频链接（可选）
                  <textarea className="textarea" style={{ minHeight: 70 }} value={links} onChange={(event) => setLinks(event.target.value)} placeholder="X、Facebook、TikTok 具体视频帖子链接，每行一条，最多 3 条" />
                </label>
                <label className="label">补充线索（可选）
                  <textarea className="textarea" style={{ minHeight: 70 }} value={clues} maxLength={1000} onChange={(event) => setClues(event.target.value)} placeholder="涉事人姓名、地点、关键词、想查清的后续、参考报道链接…" />
                </label>
              </div>
              <div className="row">
                <label className="row small" style={{ gap: 8 }}>事件日期（可选）<input type="date" className="input" style={{ width: 160, height: 36 }} value={eventDate} onChange={(event) => setEventDate(event.target.value)} /></label>
                <span className="small muted">填了能减少旧闻混入</span>
                <button className="btn right-auto" onClick={start} disabled={search?.state === "running"}><Icon name="search" size={15} />{search?.state === "running" ? "查找中…" : "查资料、找素材"}</button>
              </div>
              <span className="small muted">线索帮助定位报道，没经过来源核实的内容不会写成事实；视频帖子的说法按发布者说法核对。</span>
            </div>

            {error && <ErrorBox message={error} onRetry={start} />}
            {search?.state === "running" && <div className="card pad row"><Spinner /><b>{search.phase || "正在查找…"}</b><span className="small muted right-auto">通常 1 到 3 分钟，可以先去做别的</span></div>}

            {search?.state === "done" && (
              <>
                <div className="card pad col" style={{ gap: 12 }}>
                  <div className="row"><span className="h2">② 查到的素材</span>
                    <span className="small muted">{usable.filter((item) => item.kind === "video").length} 条视频 · {usable.filter((item) => item.kind === "image").length} 张图片可用；排除广告、无关 {search.excluded} 条，打不开或日期不符 {search.unreadable} 条</span></div>
                  <div style={{ display: "grid", gridTemplateColumns: "repeat(6, 1fr)", gap: 8 }}>
                    {search.candidates.map((item) => (
                      <span key={item.id} className="col" style={{ gap: 4 }}>
                        <span className="pic" style={{ opacity: item.ok ? 1 : 0.5 }}>
                          <AuthImage path={item.thumb} />
                          <span className="tag"><Icon name={item.kind === "video" ? "play" : "image"} size={11} color="#fff" width={2.5} />{item.kind === "video" ? item.length : "图片"}</span>
                          {!item.ok && <span className="chip c-w" style={{ position: "absolute", left: 5, top: 5 }}>{item.reason || "不用"}</span>}
                        </span>
                        <span className="small muted ellipsis">{item.source}</span>
                      </span>
                    ))}
                  </div>
                </div>
                <div className="card pad col" style={{ gap: 10 }}>
                  <div className="row"><span className="h2">③ 口播文案</span><span className="small muted">可以改 · 90 秒以内，资料不够就短一点，不凑时长</span><span className="small num muted right-auto">{script.length} / 2000 字</span></div>
                  <textarea className="textarea" style={{ minHeight: 160 }} value={script} maxLength={2000} onChange={(event) => setScript(event.target.value)} aria-label="口播文案" />
                  {search.sources.length > 0 && (
                    <span className="small muted">参考来源：{search.sources.map((source, index) => <span key={source.url}>{index ? "、" : ""}<a href={source.url} target="_blank" rel="noreferrer">{source.title}</a></span>)}</span>
                  )}
                </div>
              </>
            )}
          </section>
          <aside className="card panel">
            <div className="panel-head"><span className="h2">制作区</span></div>
            <div className="panel-body">
              <div className="col" style={{ gap: 8 }}>
                <b>剪辑方式</b>
                <Seg full value={mode} onChange={setMode} options={(search?.modes.length ? search.modes : ["视频剪辑", "混合剪辑", "图文剪辑"]).map((value) => ({ value, label: value }))} />
                <span className="small muted">{MODE_NOTE[mode]}</span>
              </div>
              <GenerateOptions options={options} settings={{ ...settings, duration: 90 }} onChange={setSettings} durations={[90]} />
              <div className="info">做之前会再终审一次素材。文案改过的话，生成时会按新内容重新核对。</div>
            </div>
            <div className="panel-foot">
              <button className="btn lg block" disabled={busy || search?.state !== "done" || !script.trim()} onClick={generate}><Icon name="play" size={18} />{busy ? "正在提交…" : "一键生成"}</button>
              <span className="small muted" style={{ textAlign: "center" }}>先查资料、找素材，查好后才能生成</span>
            </div>
          </aside>
        </div>
      </div>
      {toast}
    </>
  );
}
