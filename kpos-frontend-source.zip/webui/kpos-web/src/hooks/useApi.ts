import { useCallback, useEffect, useRef, useState } from "react";
import type { TuwenTask } from "../api/types";

/** 读一个接口：data / error / loading / reload */
export function useApi<T>(loader: () => Promise<T>, deps: unknown[] = []) {
  const [data, setData] = useState<T | null>(null);
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(true);
  const loaderRef = useRef(loader);
  loaderRef.current = loader;
  const reload = useCallback(async () => {
    setLoading(true);
    setError("");
    try {
      setData(await loaderRef.current());
    } catch (err) {
      setError(err instanceof Error ? err.message : "加载失败");
    } finally {
      setLoading(false);
    }
  }, []);
  useEffect(() => {
    reload();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, deps);
  return { data, setData, error, loading, reload };
}

/** 每隔一段时间重新读，页面隐藏时暂停 */
export function usePolling(callback: () => void, intervalMs: number, active = true) {
  const saved = useRef(callback);
  saved.current = callback;
  useEffect(() => {
    if (!active) return;
    const timer = setInterval(() => {
      if (document.visibilityState === "visible") saved.current();
    }, intervalMs);
    return () => clearInterval(timer);
  }, [intervalMs, active]);
}

/**
 * 图文的慢任务（找图、来龙去脉、分享文案）：服务器在后台做，前端每 2 秒问一次，直到 done。
 * key 变了就重新开始；返回进度文字、用时、结果和错误。
 */
export function useTuwenTask<T>(start: (() => Promise<TuwenTask<T>>) | null, key: string) {
  const [step, setStep] = useState("排队中…");
  const [elapsed, setElapsed] = useState(0);
  const [result, setResult] = useState<T | null>(null);
  const [error, setError] = useState("");
  const [attempt, setAttempt] = useState(0);
  useEffect(() => {
    if (!start) return;
    let alive = true;
    let timer: ReturnType<typeof setTimeout>;
    setResult(null);
    setError("");
    setStep("排队中…");
    setElapsed(0);
    const tick = async () => {
      try {
        const task = await start();
        if (!alive) return;
        if (task.state === "done" && task.result) {
          setResult(task.result);
          return;
        }
        if (task.state === "error") {
          setError(task.error || "处理失败，请稍后重试。");
          return;
        }
        if (task.step) setStep(task.step);
        setElapsed(task.elapsed);
        timer = setTimeout(tick, 2000);
      } catch (err) {
        if (alive) setError(err instanceof Error ? err.message : "处理失败");
      }
    };
    tick();
    return () => {
      alive = false;
      clearTimeout(timer);
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [key, attempt]);
  return { step, elapsed, result, error, retry: () => setAttempt((value) => value + 1) };
}

/** 存在本机的小偏好（制作选项、每页条数等）；读写失败时只在内存里 */
export function useLocal<T>(key: string, initial: T): [T, (value: T) => void] {
  const [value, setValue] = useState<T>(() => {
    try {
      const raw = localStorage.getItem(`kpos:${key}`);
      return raw ? { ...initial, ...JSON.parse(raw) } : initial;
    } catch {
      return initial;
    }
  });
  const save = useCallback((next: T) => {
    setValue(next);
    try {
      localStorage.setItem(`kpos:${key}`, JSON.stringify(next));
    } catch {
      /* 存不了就算了 */
    }
  }, [key]);
  return [value, save];
}
